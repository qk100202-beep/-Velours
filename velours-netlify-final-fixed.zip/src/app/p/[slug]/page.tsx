import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PageHero } from "@/components/ui";

export const dynamic = "force-dynamic";

const POLICIES: Record<
  string,
  { title: string; eyebrow: string; intro: string; sections: { heading: string; body: string[] }[] }
> = {
  shipping: {
    title: "Shipping Policy",
    eyebrow: "Policy 01",
    intro:
      "Everything you need to know about how VELOURS gets your order from our studio in Karachi to your door.",
    sections: [
      {
        heading: "Delivery times",
        body: [
          "Karachi, Lahore and Islamabad: 2 to 4 working days from dispatch.",
          "Rest of Pakistan: 4 to 7 working days from dispatch.",
          "Remote and northern areas may take up to 9 working days during winter.",
        ],
      },
      {
        heading: "Shipping charges",
        body: [
          "Flat Rs. 250 on orders below Rs. 8,000.",
          "Free shipping on all orders of Rs. 8,000 and above, anywhere in Pakistan.",
          "Shipping charges are shown at checkout before you place the order.",
        ],
      },
      {
        heading: "Dispatch & tracking",
        body: [
          "Orders are dispatched Monday to Saturday, excluding public holidays.",
          "Orders placed before 2:00 PM PKT are usually dispatched the same working day.",
          "You receive an order number immediately and can track it any time from the Track Order page using that number and your email or phone.",
        ],
      },
      {
        heading: "Cash on delivery",
        body: [
          "Cash on delivery is available nationwide. Please keep the exact amount ready where possible.",
          "If a parcel is refused on delivery twice, we may ask for advance payment on the next order.",
        ],
      },
    ],
  },
  returns: {
    title: "Return & Exchange Policy",
    eyebrow: "Policy 02",
    intro:
      "If the fit is not right or something is wrong with your piece, we will make it right within seven days.",
    sections: [
      {
        heading: "Eligibility",
        body: [
          "You have 7 days from the delivery date to request a return or exchange.",
          "Items must be unworn, unwashed, unworn-laundered and returned with all original tags and packaging.",
          "Items that show signs of wear, perfume, stains or alteration cannot be accepted.",
        ],
      },
      {
        heading: "Exchange",
        body: [
          "Size exchanges are free once per order, subject to stock availability.",
          "If the replacement size is out of stock we will issue store credit or a full refund.",
        ],
      },
      {
        heading: "Refunds",
        body: [
          "Approved refunds are processed within 5 to 7 working days to your original payment method or bank account.",
          "Cash on delivery orders are refunded via bank transfer or JazzCash / Easypaisa.",
          "Original shipping charges are non-refundable unless the item was faulty.",
        ],
      },
      {
        heading: "Sale items",
        body: [
          "Products bought on sale are exchange-only and are not eligible for a cash refund unless faulty.",
          "Final-sale clearance items are not returnable. This is stated on the product page before purchase.",
        ],
      },
    ],
  },
  privacy: {
    title: "Privacy Policy",
    eyebrow: "Policy 03",
    intro:
      "We collect only what we need to deliver your order and improve the store. We never sell your data.",
    sections: [
      {
        heading: "What we collect",
        body: [
          "Name, email address, phone number and delivery address when you place an order or create an account.",
          "Order history and account preferences so you can track and manage your purchases.",
          "Basic device and usage information (browser, pages viewed) to keep the store working properly.",
        ],
      },
      {
        heading: "How we use it",
        body: [
          "To process, deliver and support your order.",
          "To send transactional messages — order confirmation, status updates and returns.",
          "To send marketing only if you have opted in. You can unsubscribe at any time.",
        ],
      },
      {
        heading: "Security",
        body: [
          "Passwords are stored only as salted cryptographic hashes. Nobody at VELOURS can read your password.",
          "Administrative access is role-restricted and verified server-side on every request.",
          "Payment card details are never stored on our servers.",
        ],
      },
      {
        heading: "Your rights",
        body: [
          "You can view and edit your account details at any time from My Account.",
          "You can request deletion of your account and personal data by emailing care@velours.pk.",
        ],
      },
    ],
  },
  terms: {
    title: "Terms & Conditions",
    eyebrow: "Policy 04",
    intro:
      "By shopping at VELOURS you agree to these terms. They exist to keep the transaction fair for both of us.",
    sections: [
      {
        heading: "General",
        body: [
          "VELOURS (Pvt) Ltd operates this store from Karachi, Pakistan. All prices are in Pakistani Rupees (PKR) and include applicable taxes.",
          "We may update these terms at any time. The version published on this page at the time of your order applies to that order.",
        ],
      },
      {
        heading: "Orders & pricing",
        body: [
          "An order is confirmed once it appears as Confirmed in your account or tracking page.",
          "In the rare case a product is out of stock after an order is placed, we will contact you and issue a full refund for that item.",
          "We reserve the right to cancel orders that appear fraudulent or that use an incorrect pricing error.",
        ],
      },
      {
        heading: "Product representation",
        body: [
          "We photograph every product ourselves. Colours may vary slightly between screens; this is not a defect.",
          "Measurements listed in the size guide are approximate and may vary by up to one inch.",
        ],
      },
      {
        heading: "Liability",
        body: [
          "VELOLOURS is not liable for indirect or consequential losses arising from use of this website.",
          "Nothing in these terms limits your statutory consumer rights under Pakistani law.",
        ],
      },
    ],
  },
};

export function generateStaticParams() {
  return Object.keys(POLICIES).map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const policy = POLICIES[slug];
  return { title: policy?.title ?? "Policy" };
}

export default async function PolicyPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const policy = POLICIES[slug];
  if (!policy) notFound();

  return (
    <>
      <PageHero eyebrow={policy.eyebrow} title={policy.title} description={policy.intro} />
      <div className="mx-auto grid max-w-[1100px] gap-12 px-5 py-16 md:px-9 md:py-20 lg:grid-cols-[1fr_16rem]">
        <div className="space-y-12">
          {policy.sections.map((s, i) => (
            <section key={s.heading} className="rule pt-6">
              <p className="meta-sm tnum text-verm">{String(i + 1).padStart(2, "0")}</p>
              <h2 className="display mt-3 text-[1.75rem]">{s.heading}</h2>
              <ul className="mt-5 space-y-3.5">
                {s.body.map((b) => (
                  <li key={b} className="flex items-start gap-3 leading-[1.85] text-ink/80">
                    <span className="mt-2.5 h-1 w-1 shrink-0 bg-verm" />
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>

        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="border border-ink/15 bg-paper-2 p-6">
            <p className="meta text-stone">Last updated</p>
            <p className="tnum mt-2 text-sm">01 January 2026</p>
            <div className="rule mt-6 space-y-3 pt-5">
              <p className="meta text-stone">Other policies</p>
              {Object.entries(POLICIES).map(([key, value]) => (
                <a
                  key={key}
                  href={`/p/${key}`}
                  className={`link-underline block text-sm ${
                    key === slug ? "text-verm" : "text-ink/80 hover:text-ink"
                  }`}
                >
                  {value.title}
                </a>
              ))}
            </div>
            <p className="mt-6 text-xs leading-relaxed text-stone">
              Questions? Email{" "}
              <a href="mailto:care@velours.pk" className="link-underline text-ink">
                care@velours.pk
              </a>
            </p>
          </div>
        </aside>
      </div>
    </>
  );
}
