"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Loader2, ShoppingBag, Lock, ArrowLeft } from "lucide-react";
import { useCart } from "@/components/cart-provider";
import { formatPKR, PROVINCES } from "@/lib/constants";
import { Alert, Field, EmptyState } from "@/components/ui";
import { useToast } from "@/components/toast";

export default function CheckoutPage() {
  const cart = useCart();
  const router = useRouter();
  const toast = useToast();

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    province: "",
    postalCode: "",
    instructions: "",
    paymentMethod: "cod",
    saveAddress: true,
  });

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (d?.ok && d.user) {
          setForm((f) => ({
            ...f,
            name: d.user.name ?? f.name,
            email: d.user.email ?? f.email,
            phone: d.user.phone ?? f.phone,
            address: d.user.address ?? f.address,
            city: d.user.city ?? f.city,
            province: d.user.province ?? f.province,
            postalCode: d.user.postalCode ?? f.postalCode,
          }));
        }
      })
      .catch(() => {});
  }, []);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function placeOrder(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!cart.lines.length) {
      setError("Your bag is empty.");
      return;
    }
    for (const line of cart.lines) {
      if (line.quantity > line.stock) {
        setError(
          `Only ${line.stock} left of ${line.name} (${line.size} / ${line.color}). Please adjust your bag.`
        );
        return;
      }
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          items: cart.lines.map((l) => ({
            productId: l.productId,
            size: l.size,
            color: l.color,
            quantity: l.quantity,
          })),
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data?.error || "We could not place your order. Please try again.");
      }

      cart.clear();
      toast("Order placed successfully", "success");
      router.push(`/order-confirmed?number=${encodeURIComponent(data.orderNumber)}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Network error. Please try again.");
      setSubmitting(false);
    }
  }

  if (cart.hydrated && cart.lines.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-5 py-20">
        <EmptyState
          icon={<ShoppingBag size={36} />}
          title="Nothing to check out"
          description="Your bag is empty. Add a piece first and then come back to complete your order."
          action={
            <Link href="/shop" className="btn btn-ink mt-2">
              Browse the collection
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1500px] px-5 py-12 md:px-9 md:py-16">
      <Link href="/cart" className="link-underline meta inline-flex items-center gap-2 text-stone hover:text-ink">
        <ArrowLeft size={14} /> Back to bag
      </Link>

      <div className="rule-heavy mt-6 flex items-end justify-between gap-6 pt-4">
        <h1 className="display text-[clamp(2.4rem,7vw,4.5rem)]">Checkout</h1>
        <p className="meta-sm pb-2 text-stone">Secure · Cash on delivery</p>
      </div>

      <form onSubmit={placeOrder} className="mt-10 grid gap-14 lg:grid-cols-[1.5fr_1fr]">
        <div className="space-y-12">
          {error && <Alert tone="error">{error}</Alert>}

          {/* customer */}
          <section>
            <h2 className="display text-[1.65rem]">
              <span className="meta mr-3 align-middle text-stone">01</span> Customer Information
            </h2>
            <div className="mt-7 grid gap-7 sm:grid-cols-2">
              <Field label="Full name">
                <input
                  required
                  className="field"
                  value={form.name}
                  onChange={(e) => update("name", e.target.value)}
                  placeholder="Ahmed Raza"
                  autoComplete="name"
                />
              </Field>
              <Field label="Email address">
                <input
                  required
                  type="email"
                  className="field"
                  value={form.email}
                  onChange={(e) => update("email", e.target.value)}
                  placeholder="you@email.com"
                  autoComplete="email"
                />
              </Field>
              <Field label="Phone number" className="sm:col-span-2">
                <input
                  required
                  type="tel"
                  className="field tnum"
                  value={form.phone}
                  onChange={(e) => update("phone", e.target.value)}
                  placeholder="+92 3XX XXXXXXX"
                  autoComplete="tel"
                />
              </Field>
            </div>
          </section>

          {/* shipping */}
          <section>
            <h2 className="display text-[1.65rem]">
              <span className="meta mr-3 align-middle text-stone">02</span> Shipping Information
            </h2>
            <div className="mt-7 grid gap-7 sm:grid-cols-2">
              <Field label="Complete address" className="sm:col-span-2">
                <input
                  required
                  className="field"
                  value={form.address}
                  onChange={(e) => update("address", e.target.value)}
                  placeholder="House 12, Street 4, Block B, DHA Phase 6"
                  autoComplete="street-address"
                />
              </Field>
              <Field label="City">
                <input
                  required
                  className="field"
                  value={form.city}
                  onChange={(e) => update("city", e.target.value)}
                  placeholder="Karachi"
                  autoComplete="address-level2"
                />
              </Field>
              <Field label="Province">
                <select
                  required
                  className="field"
                  value={form.province}
                  onChange={(e) => update("province", e.target.value)}
                >
                  <option value="">Select province</option>
                  {PROVINCES.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Postal code">
                <input
                  className="field tnum"
                  value={form.postalCode}
                  onChange={(e) => update("postalCode", e.target.value)}
                  placeholder="75500"
                  autoComplete="postal-code"
                />
              </Field>
              <Field label="Delivery instructions (optional)" className="sm:col-span-2">
                <textarea
                  className="field resize-none"
                  rows={3}
                  value={form.instructions}
                  onChange={(e) => update("instructions", e.target.value)}
                  placeholder="Ring the bell twice, leave with the guard if not home…"
                />
              </Field>
            </div>
          </section>

          {/* payment */}
          <section>
            <h2 className="display text-[1.65rem]">
              <span className="meta mr-3 align-middle text-stone">03</span> Payment
            </h2>
            <div className="mt-7 space-y-3">
              {[
                ["cod", "Cash on Delivery", "Pay in cash when your parcel arrives. Available nationwide."],
                ["card", "Card / Online", "Coming soon — JazzCash, Easypaisa and card payments."],
              ].map(([value, title, desc]) => {
                const disabled = value !== "cod";
                return (
                  <label
                    key={value}
                    className={`flex cursor-pointer items-start gap-4 border p-5 transition-colors ${
                      form.paymentMethod === value
                        ? "border-ink bg-paper-2"
                        : "border-ink/15 hover:border-ink/35"
                    } ${disabled ? "cursor-not-allowed opacity-55" : ""}`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      value={value}
                      checked={form.paymentMethod === value}
                      disabled={disabled}
                      onChange={() => update("paymentMethod", value)}
                      className="mt-1 accent-[#0B0B0B]"
                    />
                    <span>
                      <span className="block text-[0.95rem] font-medium">{title}</span>
                      <span className="mt-1 block text-sm leading-relaxed text-stone">{desc}</span>
                    </span>
                  </label>
                );
              })}
            </div>
          </section>
        </div>

        {/* summary */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="border border-ink/15 bg-paper-2 p-7">
            <h2 className="display text-[1.65rem]">Order Summary</h2>

            <div className="mt-6 space-y-5">
              {cart.lines.map((line) => (
                <div key={line.key} className="flex gap-4">
                  <img
                    src={line.image}
                    alt={line.name}
                    className="h-[5.25rem] w-[4.25rem] shrink-0 object-cover"
                    loading="lazy"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{line.name}</p>
                    <p className="meta-sm tnum mt-1 text-stone">
                      {line.size} / {line.color} · Qty {line.quantity}
                    </p>
                    <p className="tnum mt-1.5 text-sm">{formatPKR(line.price * line.quantity)}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="rule mt-7 space-y-3 pt-5 text-sm">
              <div className="flex justify-between">
                <span className="text-stone">Subtotal</span>
                <span className="tnum">{formatPKR(cart.subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone">Shipping</span>
                <span className="tnum">{cart.shipping === 0 ? "Free" : formatPKR(cart.shipping)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone">Payment</span>
                <span>Cash on delivery</span>
              </div>
            </div>

            <div className="rule mt-5 flex items-end justify-between pt-5">
              <span className="meta">Grand total</span>
              <span className="tnum text-[1.75rem] font-semibold">{formatPKR(cart.total)}</span>
            </div>

            <button type="submit" disabled={submitting} className="btn btn-ink mt-6 w-full">
              {submitting ? (
                <>
                  <Loader2 size={16} className="spin" /> Placing order…
                </>
              ) : (
                <>Place order</>
              )}
            </button>

            <p className="mt-4 flex items-start gap-2 text-xs leading-relaxed text-stone">
              <Lock size={13} className="mt-0.5 shrink-0" />
              Your details are used only to deliver this order. Stock is verified against live
              inventory before confirmation.
            </p>
          </div>
        </aside>
      </form>
    </div>
  );
}
