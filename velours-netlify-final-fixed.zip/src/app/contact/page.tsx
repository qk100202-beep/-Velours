import type { Metadata } from "next";
import { Mail, Phone, MapPin, Clock } from "lucide-react";
import { ContactForm } from "@/components/contact-form";
import { SectionHead } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with the VELOURS team — support, sizing, returns and collaborations.",
};

const SUBJECTS = [
  ["Order & delivery", "Where is my order, delivery times, rider issues"],
  ["Sizing & fit", "Which size to pick, measurements, fit advice"],
  ["Returns & exchange", "Start a return, exchange a size, report a fault"],
  ["Wholesale & stockist", "Stock VELOURS in your store or city"],
];

export default function ContactPage() {
  return (
    <>
      <header className="relative overflow-hidden bg-ink text-paper">
        <div className="absolute inset-0">
          <img
            src="/images/atelier.svg"
            alt=""
            aria-hidden="true"
            className="h-full w-full object-cover opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/45" />
        </div>
        <div className="relative mx-auto max-w-[1500px] px-5 py-16 md:px-9 md:py-24">
          <p className="meta text-stone-2">Contact</p>
          <h1 className="display mt-4 text-[clamp(2.6rem,8vw,6rem)]">Talk To Us</h1>
          <p className="mt-6 max-w-xl text-[1.02rem] leading-relaxed text-paper/75">
            Real people, real answers. We reply to every message within 24 hours on working days —
            usually much faster.
          </p>
        </div>
      </header>

      <div className="mx-auto grid max-w-[1500px] gap-14 px-5 py-16 md:px-9 lg:grid-cols-[1.35fr_1fr] lg:py-20">
        <div>
          <SectionHead eyebrow="01 — Send a message" title="How Can We Help?" />
          <div className="mt-9">
            <ContactForm />
          </div>
        </div>

        <aside>
          <SectionHead eyebrow="02 — Reach us" title="Direct Lines" />
          <div className="mt-8 space-y-8">
            {[
              [Mail, "Email", "care@velours.pk", "For orders, returns and general support"],
              [Phone, "WhatsApp", "+92 300 1234567", "Fastest for order-related questions"],
              [MapPin, "Studio", "Studio 4, Zamzama Lane, Clifton, Karachi", "Visits by appointment only"],
              [Clock, "Hours", "Mon – Sat, 10:00 – 19:00 PKT", "Closed on public holidays"],
            ].map(([Icon, label, value, note]) => {
              const C = Icon as typeof Mail;
              return (
                <div key={label as string} className="rule flex items-start gap-4 pt-6">
                  <C size={18} className="mt-0.5 shrink-0 text-verm" />
                  <div>
                    <p className="meta text-stone">{label as string}</p>
                    <p className="mt-2 text-[1.02rem] font-medium">{value as string}</p>
                    <p className="mt-1.5 text-sm text-stone">{note as string}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-12 border border-ink/15 bg-paper-2 p-7">
            <h3 className="display text-[1.55rem]">Common Questions</h3>
            <div className="mt-6 space-y-5">
              {SUBJECTS.map(([t, d]) => (
                <div key={t}>
                  <p className="text-[0.95rem] font-medium">{t}</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-stone">{d}</p>
                </div>
              ))}
            </div>
            <p className="mt-7 text-sm leading-relaxed text-stone">
              Looking for delivery, returns or sizing details?{" "}
              <a href="/p/shipping" className="link-underline text-verm">
                Read our policies
              </a>
              .
            </p>
          </div>
        </aside>
      </div>
    </>
  );
}
