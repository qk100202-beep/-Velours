import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getProductBySlug, listProducts } from "@/lib/data";
import { ProductGallery } from "@/components/product-gallery";
import { ProductBuy } from "@/components/product-buy";
import { ProductCard } from "@/components/product-card";
import { Breadcrumbs, SectionHead } from "@/components/ui";
import { StaggerGroup, StaggerItem } from "@/components/reveal";
import { Check } from "lucide-react";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return { title: "Product not found" };
  return {
    title: product.name,
    description: product.description.slice(0, 155),
    openGraph: { images: [{ url: product.images[0]?.url ?? "" }] },
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const related = await listProducts({
    category: product.category,
    limit: 4,
    includeUnpublished: false,
  });
  const others = related.filter((p) => p.id !== product.id).slice(0, 4);

  return (
    <>
      <div className="mx-auto max-w-[1500px] px-5 pt-8 md:px-9">
        <Breadcrumbs
          items={[
            { label: "Home", href: "/" },
            { label: "Shop", href: "/shop" },
            {
              label: product.category === "t-shirts" ? "T-Shirts" : "Hoodies",
              href: `/shop?category=${product.category}`,
            },
            { label: product.name },
          ]}
        />
      </div>

      <section className="mx-auto grid max-w-[1500px] gap-10 px-5 py-10 md:px-9 lg:grid-cols-[1.15fr_1fr] lg:gap-16 lg:py-14">
        <div>
          <ProductGallery images={product.images} name={product.name} />
        </div>
        <div className="lg:sticky lg:top-24 lg:self-start">
          <ProductBuy product={product} />
        </div>
      </section>

      {/* product information */}
      <section className="mx-auto max-w-[1500px] px-5 pb-6 md:px-9">
        <div className="grid gap-10 border-t border-ink/15 pt-12 lg:grid-cols-3">
          <div>
            <h2 className="display text-[1.75rem]">Product Information</h2>
            <ul className="mt-6 space-y-3.5">
              {[
                `SKU — ${product.sku}`,
                `Category — ${product.category === "t-shirts" ? "T-Shirt" : "Hoodie"}`,
                product.fabric ? `Fabric — ${product.fabric}` : "Fabric — 100% cotton",
                `Colours — ${product.colors.map((c) => c.name).join(", ") || "—"}`,
                `Sizes — ${["XS", "S", "M", "L", "XL", "XXL"].join(", ")}`,
                "Printed & finished in Karachi, Pakistan",
              ].map((line) => (
                <li key={line} className="flex items-start gap-3 text-sm leading-relaxed text-ink/80">
                  <Check size={15} className="mt-0.5 shrink-0 text-verm" />
                  {line}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h2 className="display text-[1.75rem]">Shipping Information</h2>
            <ul className="mt-6 space-y-3.5 text-sm leading-relaxed text-ink/80">
              <li>
                <strong className="font-semibold">Karachi, Lahore &amp; Islamabad</strong> — 2 to 4
                working days.
              </li>
              <li>
                <strong className="font-semibold">Rest of Pakistan</strong> — 4 to 7 working days.
              </li>
              <li>
                <strong className="font-semibold">Free shipping</strong> on all orders above Rs.
                8,000. A flat Rs. 250 applies below that.
              </li>
              <li>
                <strong className="font-semibold">Cash on delivery</strong> is available nationwide.
                Online payment is coming soon.
              </li>
              <li>Orders are dispatched Monday to Saturday, excluding public holidays.</li>
            </ul>
          </div>

          <div id="size-guide">
            <h2 className="display text-[1.75rem]">Returns &amp; Size Guide</h2>
            <div className="mt-6 overflow-hidden">
              <table className="dtable">
                <thead>
                  <tr>
                    <th>Size</th>
                    <th>Chest (in)</th>
                    <th>Length (in)</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ["XS", 36, 26],
                    ["S", 38, 27],
                    ["M", 40, 28],
                    ["L", 43, 29],
                    ["XL", 46, 30],
                    ["XXL", 48, 31],
                  ].map(([s, c, l]) => (
                    <tr key={s as string}>
                      <td className="font-medium">{s as string}</td>
                      <td className="tnum">{c as number}</td>
                      <td className="tnum">{l as number}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <ul className="mt-6 space-y-3 text-sm leading-relaxed text-ink/80">
              <li>7-day return &amp; exchange window from the delivery date.</li>
              <li>Items must be unworn, unwashed and returned with original tags.</li>
              <li>Sale items are exchange-only unless faulty.</li>
            </ul>
            <Link href="/p/returns" className="link-underline meta mt-5 inline-block text-verm">
              Full return policy →
            </Link>
          </div>
        </div>
      </section>

      {/* related */}
      {others.length > 0 && (
        <section className="mx-auto max-w-[1500px] px-5 py-20 md:px-9">
          <SectionHead
            eyebrow="Pairs well with"
            title="You May Also Like"
            count={`${others.length} pieces`}
            href={`/shop?category=${product.category}`}
          />
          <StaggerGroup className="mt-9 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">
            {others.map((p) => (
              <StaggerItem key={p.id}>
                <ProductCard product={p} />
              </StaggerItem>
            ))}
          </StaggerGroup>
        </section>
      )}
    </>
  );
}
