import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getOrderForUser } from "@/lib/orders";
import { getSessionUser } from "@/lib/auth";
import { formatDateTime, formatPKR, STATUS_META, type OrderStatus } from "@/lib/constants";
import { StatusTimeline } from "@/components/status-timeline";
import { Breadcrumbs } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order Details" };

export default async function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getSessionUser();
  if (!user) redirect(`/login?next=/orders/${id}`);

  const order = await getOrderForUser(Number(id), user.id);
  if (!order) notFound();

  return (
    <div className="mx-auto max-w-[1100px] px-5 py-12 md:px-9 md:py-16">
      <Breadcrumbs
        items={[
          { label: "Home", href: "/" },
          { label: "My account", href: "/account" },
          { label: "Orders", href: "/account/orders" },
          { label: order.orderNumber },
        ]}
      />

      <header className="mt-8 flex flex-wrap items-end justify-between gap-6 border-b border-ink/15 pb-8">
        <div>
          <p className="meta text-stone">Order</p>
          <h1 className="display mt-3 text-[clamp(2.1rem,6vw,3.75rem)]">{order.orderNumber}</h1>
          <p className="tnum mt-3 text-stone">Placed {formatDateTime(order.createdAt)}</p>
        </div>
        <div className="text-right">
          <p className="meta text-stone">Status</p>
          <p className="display mt-2 text-[1.75rem] text-verm">
            {STATUS_META[order.status as OrderStatus]?.label ?? order.status}
          </p>
          <p className="mt-2 max-w-xs text-sm leading-relaxed text-stone">
            {STATUS_META[order.status as OrderStatus]?.description}
          </p>
        </div>
      </header>

      <section className="mt-12 border border-ink/15 bg-paper-2 p-7">
        <h2 className="display text-[1.55rem]">Tracking Progress</h2>
        <div className="mt-9">
          <StatusTimeline status={order.status} events={order.events} />
        </div>
      </section>

      <section className="mt-12">
        <h2 className="display text-[1.55rem]">Items</h2>
        <div className="mt-6 border-t border-ink/15">
          {order.items.map((item) => (
            <div key={item.id} className="flex items-center gap-5 border-b border-ink/10 py-5">
              <img
                src={item.imageUrl ?? "/images/tee-black.svg"}
                alt={item.productName}
                className="h-[5.5rem] w-[4.5rem] shrink-0 object-cover"
                loading="lazy"
              />
              <div className="min-w-0 flex-1">
                <p className="font-medium">{item.productName}</p>
                <p className="meta-sm tnum mt-1.5 text-stone">
                  {item.sku && <>SKU {item.sku} · </>}
                  {item.size} / {item.color} · Qty {item.quantity}
                </p>
              </div>
              <div className="text-right">
                <p className="tnum text-sm text-stone">{formatPKR(item.unitPrice)}</p>
                <p className="tnum mt-1 font-semibold">{formatPKR(item.unitPrice * item.quantity)}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 ml-auto max-w-xs space-y-2.5 text-sm">
          <div className="flex justify-between">
            <span className="text-stone">Subtotal</span>
            <span className="tnum">{formatPKR(order.subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone">Shipping</span>
            <span className="tnum">{order.shipping === 0 ? "Free" : formatPKR(order.shipping)}</span>
          </div>
          <div className="rule flex items-end justify-between pt-3">
            <span className="meta">Total</span>
            <span className="tnum text-[1.45rem] font-semibold">{formatPKR(order.total)}</span>
          </div>
        </div>
      </section>

      <section className="mt-12 grid gap-8 border-t border-ink/15 pt-10 md:grid-cols-2">
        <div>
          <h3 className="meta">Delivery address</h3>
          <p className="mt-4 text-sm leading-[1.9] text-ink/80">
            {order.customerName}
            <br />
            {order.address}
            <br />
            {order.city}, {order.province}
            {order.postalCode && (
              <>
                <br />
                {order.postalCode}
              </>
            )}
            <br />
            <span className="tnum">{order.customerPhone}</span>
            <br />
            {order.customerEmail}
          </p>
        </div>
        <div>
          <h3 className="meta">Order history</h3>
          <ul className="mt-4 space-y-3">
            {order.events.map((e) => (
              <li key={e.id} className="flex items-start gap-3 text-sm">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 bg-verm" />
                <span>
                  <span className="font-medium capitalize">{e.status.replace(/_/g, " ")}</span>
                  <span className="tnum ml-2 text-stone">{formatDateTime(e.createdAt)}</span>
                  {e.note && <span className="mt-1 block text-stone">{e.note}</span>}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <div className="mt-12 flex flex-wrap gap-3">
        <Link
          href={`/track?order=${order.orderNumber}&email=${order.customerEmail}`}
          className="btn btn-ink"
        >
          Track this order
        </Link>
        <Link href="/shop" className="btn btn-outline">
          Continue shopping
        </Link>
      </div>
    </div>
  );
}
