"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { Loader2, MailCheck } from "lucide-react";
import { AuthShell } from "@/components/auth-shell";
import { Alert, Field } from "@/components/ui";

export default function ForgotPage() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [devUrl, setDevUrl] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/forgot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Request failed.");
      if (data.devResetUrl) setDevUrl(data.devResetUrl);
      setSent(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthShell
      eyebrow="Account recovery"
      title="Reset Password"
      subtitle="We will email you a secure link to set a new password."
      image="/images/detail-macro.svg"
      footer={
        <p className="text-sm text-stone">
          Remembered it?{" "}
          <Link href="/login" className="link-underline font-medium text-verm">
            Back to sign in
          </Link>
        </p>
      }
    >
      {sent ? (
        <div className="space-y-6">
          <div className="flex items-start gap-3 border border-ink/18 bg-paper-2 px-5 py-4">
            <MailCheck size={18} className="mt-0.5 shrink-0 text-verm" />
            <p className="text-sm leading-relaxed text-ink/80">
              If an account exists for <strong>{email}</strong>, a password reset link has been sent.
              The link expires in 1 hour.
            </p>
          </div>
          {devUrl && (
            <Alert tone="info">
              Email delivery is not configured in this environment, so here is your reset link:{" "}
              <Link href={devUrl} className="link-underline ml-1 font-medium text-verm">
                Set a new password
              </Link>
            </Alert>
          )}
          <Link href="/login" className="btn btn-outline w-full">
            Return to sign in
          </Link>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-7">
          {error && <Alert tone="error">{error}</Alert>}
          <Field label="Email address">
            <input
              type="email"
              required
              className="field"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@email.com"
              autoComplete="email"
            />
          </Field>
          <button type="submit" disabled={loading} className="btn btn-ink w-full">
            {loading ? (
              <>
                <Loader2 size={16} className="spin" /> Sending link…
              </>
            ) : (
              "Send reset link"
            )}
          </button>
        </form>
      )}
    </AuthShell>
  );
}
