import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { Check, Package, MapPin, CreditCard, ArrowRight } from "lucide-react";
import { getOrderByNumber } from "@/lib/orders";
import { formatDateTime, formatPKR, STATUS_META, type OrderStatus } from "@/lib/constants";
import { Breadcrumbs } from "@/components/ui";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order Confirmed" };

export default async function OrderConfirmedPage({
  searchParams,
}: {
  searchParams: Promise<{ number?: string }>;
}) {
  const { number } = await searchParams;
  if (!number) notFound();
  const order = await getOrderByNumber(number);
  if (!order) notFound();

  const deliveryFrom = new Date(order.createdAt);
  deliveryFrom.setDate(deliveryFrom.getDate() + 3);
  const deliveryTo = new Date(order.createdAt);
  deliveryTo.setDate(deliveryTo.getDate() + 6);

  return (
    <div className="mx-auto max-w-[1100px] px-5 py-12 md:px-9 md:py-16">
      <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Order confirmed" }]} />

      <header className="mt-8 border-b border-ink/15 pb-10">
        <div className="flex items-center gap-4">
          <span className="grid h-12 w-12 place-items-center bg-ink text-paper">
            <Check size={22} />
          </span>
          <p className="meta text-verm">Payment method — Cash on delivery</p>
        </div>
        <h1 className="display mt-6 text-[clamp(2.5rem,8vw,5.25rem)]">Order Confirmed</h1>
        <p className="mt-5 max-w-2xl text-[1.05rem] leading-relaxed text-stone">
          Thank you, <strong className="text-ink">{order.customerName}</strong>. Your order has been
          received and our team is preparing it. A confirmation has been sent to{" "}
          <strong className="text-ink">{order.customerEmail}</strong>.
        </p>
      </header>

      {/* key numbers */}
      <div className="grid gap-px border-b border-ink/15 bg-ink/12 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ["Order number", order.orderNumber],
          ["Order date", formatDateTime(order.createdAt)],
          [
            "Estimated delivery",
            `${deliveryFrom.toLocaleDateString("en-PK", { day: "2-digit", month: "short" })} – ${deliveryTo.toLocaleDateString("en-PK", { day: "2-digit", month: "short", year: "numeric" })}`,
          ],
          ["Current status", STATUS_META[order.status as OrderStatus]?.label ?? order.status],
        ].map(([label, value]) => (
          <div key={label} className="bg-paper px-5 py-6">
            <p className="meta text-stone">{label}</p>
            <p className="tnum mt-2 text-[1.05rem] font-medium">{value}</p>
          </div>
        ))}
      </div>

      {/* items */}
      <section className="mt-12">
        <h2 className="display text-[1.85rem]">Ordered Products</h2>
        <div className="mt-6 border-t border-ink/15">
          {order.items.map((item) => (
            <div
              key={item.id}
              className="flex items-center gap-5 border-b border-ink/10 py-5"
            >
              <img
                src={item.imageUrl ?? "/images/tee-black.svg"}
                alt={item.productName}
                className="h-[5.75rem] w-[4.75rem] shrink-0 object-cover"
                loading="lazy"
              />
              <div className="min-w-0 flex-1">
                <p className="font-medium">{item.productName}</p>
                <p className="meta-sm tnum mt-1.5 text-stone">
                  Size {item.size} · {item.color} · Qty {item.quantity}
                </p>
              </div>
              <div className="text-right">
                <p className="tnum text-sm text-stone">{formatPKR(item.unitPrice)} each</p>
                <p className="tnum mt-1 font-semibold">
                  {formatPKR(item.unitPrice * item.quantity)}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 ml-auto max-w-sm space-y-2.5 text-sm">
          <div className="flex justify-between">
            <span className="text-stone">Subtotal</span>
            <span className="tnum">{formatPKR(order.subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-stone">Shipping</span>
            <span className="tnum">{order.shipping === 0 ? "Free" : formatPKR(order.shipping)}</span>
          </div>
          <div className="rule flex items-end justify-between pt-3.5">
            <span className="meta">Total paid</span>
            <span className="tnum text-[1.5rem] font-semibold">{formatPKR(order.total)}</span>
          </div>
        </div>
      </section>

      {/* delivery + payment */}
      <section className="mt-14 grid gap-8 border-t border-ink/15 pt-10 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2.5">
            <MapPin size={17} className="text-verm" />
            <h3 className="meta">Shipping address</h3>
          </div>
          <p className="mt-4 text-sm leading-[1.85] text-ink/80">
            {order.customerName}
            <br />
            {order.address}
            <br />
            {order.city}, {order.province}
            {order.postalCode && (
              <>
                <br />
                {order.postalCode}
              </>
            )}
            <br />
            <span className="tnum">{order.customerPhone}</span>
          </p>
        </div>

        <div>
          <div className="flex items-center gap-2.5">
            <CreditCard size={17} className="text-verm" />
            <h3 className="meta">Payment method</h3>
          </div>
          <p className="mt-4 text-sm leading-[1.85] text-ink/80">
            Cash on Delivery
            <br />
            Pay <strong className="tnum">{formatPKR(order.total)}</strong> in cash when your parcel
            arrives.
          </p>
        </div>

        <div>
          <div className="flex items-center gap-2.5">
            <Package size={17} className="text-verm" />
            <h3 className="meta">Delivery notes</h3>
          </div>
          <p className="mt-4 text-sm leading-[1.85] text-ink/80">
            {order.instructions || "No special delivery instructions were provided."}
          </p>
        </div>
      </section>

      {/* actions */}
      <div className="mt-12 flex flex-wrap gap-3">
        <Link href={`/track?order=${order.orderNumber}&email=${order.customerEmail}`} className="btn btn-ink">
          Track order <ArrowRight size={15} />
        </Link>
        <Link href="/account/orders" className="btn btn-outline">
          View order
        </Link>
        <Link href="/shop" className="btn btn-outline">
          Continue shopping
        </Link>
      </div>
    </div>
  );
}
