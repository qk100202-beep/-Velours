"use client";

import { useState, type FormEvent, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2 } from "lucide-react";
import { AuthShell } from "@/components/auth-shell";
import { Alert, Field } from "@/components/ui";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || "/account";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Sign in failed.");
      router.push(next);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setLoading(false);
    }
  }

  return (
    <AuthShell
      eyebrow="Welcome back"
      title="Sign In"
      subtitle="Your bag, orders and saved pieces live here."
      footer={
        <p className="text-sm text-stone">
          New to VELOURS?{" "}
          <Link href="/signup" className="link-underline font-medium text-verm">
            Create an account
          </Link>
        </p>
      }
    >
      <form onSubmit={submit} className="space-y-7">
        {error && <Alert tone="error">{error}</Alert>}
        <Field label="Email address">
          <input
            type="email"
            required
            autoComplete="email"
            className="field"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@email.com"
          />
        </Field>
        <Field label="Password">
          <input
            type="password"
            required
            autoComplete="current-password"
            className="field"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
          />
        </Field>

        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2.5 text-sm text-stone">
            <input type="checkbox" className="accent-[#0B0B0B]" defaultChecked /> Remember me
          </label>
          <Link href="/forgot" className="link-underline meta-sm text-stone hover:text-ink">
            Forgot password?
          </Link>
        </div>

        <button type="submit" disabled={loading} className="btn btn-ink w-full">
          {loading ? (
            <>
              <Loader2 size={16} className="spin" /> Signing in…
            </>
          ) : (
            "Sign in"
          )}
        </button>

        <div className="rule pt-6">
          <p className="meta-sm text-stone">Are you a store administrator?</p>
          <Link href="/admin/login" className="link-underline meta mt-2 inline-block text-verm">
            Go to the admin portal →
          </Link>
        </div>
      </form>
    </AuthShell>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-[60vh]" />}>
      <LoginForm />
    </Suspense>
  );
}
