import type { Metadata } from "next";
import { ShopView, type ShopQuery } from "@/components/shop-view";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "New Arrivals",
  description: "The latest VELOURS drop — fresh styles, new vibes.",
};

export default async function NewArrivalsPage({ searchParams }: { searchParams: Promise<ShopQuery> }) {
  const query = await searchParams;
  return (
    <ShopView
      query={{ ...query, new: "1" }}
      eyebrow="Just Landed"
      title="New Arrivals"
      description="Fresh styles. New vibes. Everything in this chapter was added in the last few weeks — when a press run ends, it does not come back."
    />
  );
}
