"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Loader2, ShieldCheck } from "lucide-react";
import { Alert, Field } from "@/components/ui";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Sign in failed.");
      router.push("/admin");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.1fr_1fr]">
      <div className="relative hidden overflow-hidden bg-ink lg:block">
        <img
          src="/images/hero.svg"
          alt=""
          aria-hidden="true"
          className="h-full w-full object-cover opacity-65"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/35 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-12">
          <p className="display text-[clamp(2.15rem,3.8vw,3.5rem)] leading-[0.9] text-paper">
            VELOURS
            <br />
            <span className="text-stone-2">Control Room</span>
          </p>
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-paper/70">
            Products, inventory, orders and customers — everything that runs the store, in one
            place.
          </p>
        </div>
      </div>

      <div className="flex flex-col justify-center px-6 py-14 md:px-14">
        <div className="mx-auto w-full max-w-md">
          <div className="flex items-center gap-2.5">
            <ShieldCheck size={18} className="text-verm" />
            <p className="meta text-stone">Restricted area</p>
          </div>
          <h1 className="display mt-5 text-[clamp(2.35rem,6vw,3.55rem)]">Admin Sign In</h1>
          <p className="mt-4 leading-relaxed text-stone">
            Authorised personnel only. Every attempt is verified server-side against the role stored
            on your account.
          </p>

          <form onSubmit={submit} className="mt-9 space-y-7">
            {error && <Alert tone="error">{error}</Alert>}
            <Field label="Admin email">
              <input
                type="email"
                required
                autoComplete="username"
                className="field"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@velours.pk"
              />
            </Field>
            <Field label="Password">
              <input
                type="password"
                required
                autoComplete="current-password"
                className="field"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </Field>
            <button type="submit" disabled={loading} className="btn btn-ink w-full">
              {loading ? (
                <>
                  <Loader2 size={16} className="spin" /> Verifying…
                </>
              ) : (
                "Sign in to dashboard"
              )}
            </button>
          </form>

          <div className="rule mt-10 space-y-3 pt-6">
            <p className="text-xs leading-relaxed text-stone">
              The administrator password is never stored in source code, HTML or the browser bundle.
              It is supplied through the <code className="text-ink">ADMIN_SEED_PASSWORD</code> environment
              variable and saved only as a salted cryptographic hash.
            </p>
            <Link href="/" className="link-underline meta-sm inline-block text-verm">
              ← Back to the storefront
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
