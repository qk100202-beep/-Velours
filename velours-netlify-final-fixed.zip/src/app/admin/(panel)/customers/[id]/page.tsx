import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowLeft, Mail, Phone, MapPin, ShieldCheck } from "lucide-react";
import { db } from "@/db";
import { orders, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { listOrdersForUser } from "@/lib/orders";
import { formatDate, formatDateTime, formatPKR, STATUS_META, type OrderStatus } from "@/lib/constants";
import { CustomerStatusButton } from "@/components/admin/settings-form";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin Customer" };

export default async function AdminCustomerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const customerId = Number(id);
  const [customer] = await db.select().from(users).where(eq(users.id, customerId)).limit(1);
  if (!customer) notFound();

  const customerOrders = await listOrdersForUser(customerId);
  const spend = customerOrders
    .filter((o) => o.status !== "cancelled")
    .reduce((s, o) => s + o.total, 0);
  const orderRows = await db.select().from(orders).where(eq(orders.userId, customerId));
  const orderCount = orderRows;

  return (
    <div>
      <Link
        href="/admin/customers"
        className="link-underline meta inline-flex items-center gap-2 text-stone hover:text-ink"
      >
        <ArrowLeft size={14} /> All customers
      </Link>

      <header className="mt-6 flex flex-wrap items-end justify-between gap-6 border-b border-ink/15 pb-7">
        <div className="flex items-center gap-5">
          <span className="grid h-16 w-16 shrink-0 place-items-center bg-ink text-2xl text-paper">
            {customer.name.charAt(0).toUpperCase()}
          </span>
          <div>
            <p className="meta text-stone">Customer profile</p>
            <h1 className="display mt-2 text-[clamp(2rem,5vw,3.15rem)]">{customer.name}</h1>
            <p className="tnum meta-sm mt-2 text-stone">
              Account #{customer.id} · Joined {formatDate(customer.createdAt)}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <span className={`badge ${customer.status === "active" ? "badge-featured" : "badge-sale"}`}>
            {customer.status}
          </span>
          {customer.role === "admin" && (
            <span className="badge badge-new">
              <ShieldCheck size={11} className="mr-1" /> Administrator
            </span>
          )}
          {customer.role !== "admin" && (
            <CustomerStatusButton customerId={customer.id} status={customer.status} />
          )}
        </div>
      </header>

      <div className="mt-8 grid gap-px bg-ink/12 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ["Total orders", String(orderCount.length)],
          ["Total spent", formatPKR(spend)],
          ["Average order", formatPKR(orderCount.length ? Math.round(spend / orderCount.length) : 0)],
          ["Last order", customerOrders[0] ? formatDate(customerOrders[0].createdAt) : "—"],
        ].map(([label, value]) => (
          <div key={label} className="bg-paper px-6 py-6">
            <p className="meta text-stone">{label}</p>
            <p className="tnum mt-3 text-[1.55rem] font-semibold leading-none">{value}</p>
          </div>
        ))}
      </div>

      <div className="mt-9 grid gap-8 lg:grid-cols-3">
        <section className="border border-ink/15 p-7">
          <h2 className="display text-[1.45rem]">Contact</h2>
          <div className="mt-6 space-y-4 text-sm">
            <div className="flex items-start gap-3">
              <Mail size={16} className="mt-0.5 shrink-0 text-verm" />
              <a href={`mailto:${customer.email}`} className="link-underline">
                {customer.email}
              </a>
            </div>
            <div className="flex items-start gap-3">
              <Phone size={16} className="mt-0.5 shrink-0 text-verm" />
              <span className="tnum">{customer.phone ?? "Not provided"}</span>
            </div>
            <div className="flex items-start gap-3">
              <MapPin size={16} className="mt-0.5 shrink-0 text-verm" />
              <p className="leading-[1.9]">
                {customer.address ?? "No address on file"}
                {customer.city && (
                  <>
                    <br />
                    {customer.city}, {customer.province}
                    {customer.postalCode && ` ${customer.postalCode}`}
                  </>
                )}
              </p>
            </div>
          </div>
          <div className="rule mt-7 pt-5">
            <p className="meta text-stone">Security</p>
            <p className="mt-2.5 text-xs leading-relaxed text-stone">
              This account&rsquo;s password is stored only as a salted scrypt hash and is never
              readable by any person or shown in this interface.
            </p>
          </div>
        </section>

        <section className="border border-ink/15 lg:col-span-2">
          <div className="border-b border-ink/12 px-6 py-5">
            <h2 className="display text-[1.45rem]">Order History</h2>
          </div>
          {customerOrders.length === 0 ? (
            <p className="px-6 py-12 text-center text-sm text-stone">
              This customer has not placed an order yet.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="dtable min-w-[42rem]">
                <thead>
                  <tr>
                    <th>Order</th>
                    <th>Date</th>
                    <th>Items</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th className="text-right">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {customerOrders.map((o) => (
                    <tr key={o.id}>
                      <td className="tnum font-medium">{o.orderNumber}</td>
                      <td className="tnum">{formatDateTime(o.createdAt)}</td>
                      <td className="tnum">{o.items.reduce((s, i) => s + i.quantity, 0)}</td>
                      <td className="tnum font-semibold">{formatPKR(o.total)}</td>
                      <td>
                        <span className="meta-sm text-verm">
                          {STATUS_META[o.status as OrderStatus]?.short ?? o.status}
                        </span>
                      </td>
                      <td className="text-right">
                        <Link
                          href={`/admin/orders/${o.id}`}
                          className="link-underline meta-sm text-verm"
                        >
                          Open
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
