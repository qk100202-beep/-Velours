import Link from "next/link";
import type { Metadata } from "next";
import { Search, Users, ArrowRight } from "lucide-react";
import { listCustomers } from "@/lib/orders";
import { formatDate, formatPKR } from "@/lib/constants";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin Customers" };

export default async function AdminCustomersPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; role?: string }>;
}) {
  const { q, role } = await searchParams;
  let customers = await listCustomers();

  if (q) {
    const term = q.toLowerCase();
    customers = customers.filter(
      (c) =>
        c.name.toLowerCase().includes(term) ||
        c.email.toLowerCase().includes(term) ||
        (c.phone ?? "").toLowerCase().includes(term) ||
        (c.city ?? "").toLowerCase().includes(term)
    );
  }
  if (role) customers = customers.filter((c) => c.role === role);

  const totalSpend = customers.reduce((s, c) => s + c.spent, 0);

  return (
    <div>
      <header className="border-b border-ink/15 pb-7">
        <p className="meta text-stone">People</p>
        <h1 className="display mt-3 text-[clamp(2.15rem,5.5vw,3.45rem)]">Customers</h1>
        <p className="mt-3 max-w-2xl text-stone">
          Registered accounts and their lifetime activity. Passwords are never exposed here — the
          database stores only salted cryptographic hashes.
        </p>
      </header>

      <div className="mt-8 grid gap-px bg-ink/12 sm:grid-cols-3">
        {[
          ["Total customers", String(customers.filter((c) => c.role === "customer").length)],
          ["Total lifetime spend", formatPKR(totalSpend)],
          ["Admin accounts", String(customers.filter((c) => c.role === "admin").length)],
        ].map(([label, value]) => (
          <div key={label} className="bg-paper px-6 py-6">
            <p className="meta text-stone">{label}</p>
            <p className="tnum mt-3 text-[1.65rem] font-semibold leading-none">{value}</p>
          </div>
        ))}
      </div>

      <form method="GET" className="mt-9 flex flex-wrap items-end gap-3">
        <label className="flex min-w-[17rem] flex-1 items-center gap-3 border-b border-ink/25 pb-2">
          <Search size={16} className="text-stone" />
          <input
            name="q"
            defaultValue={q ?? ""}
            placeholder="Search by name, email, phone or city…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-stone-2"
          />
        </label>
        <select name="role" defaultValue={role ?? ""} className="field w-auto py-2">
          <option value="">All roles</option>
          <option value="customer">Customers</option>
          <option value="admin">Administrators</option>
        </select>
        <button type="submit" className="btn btn-outline">
          Filter
        </button>
      </form>

      <div className="mt-8 overflow-x-auto border border-ink/15">
        <table className="dtable min-w-[58rem]">
          <thead>
            <tr>
              <th>Customer</th>
              <th>Contact</th>
              <th>City</th>
              <th>Joined</th>
              <th>Orders</th>
              <th>Total spent</th>
              <th>Status</th>
              <th className="text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((c) => (
              <tr key={c.id}>
                <td>
                  <div className="flex items-center gap-3">
                    <span className="grid h-10 w-10 shrink-0 place-items-center bg-ink text-sm text-paper">
                      {c.name.charAt(0).toUpperCase()}
                    </span>
                    <div>
                      <p className="font-medium">{c.name}</p>
                      <p className="meta-sm text-stone">{c.role}</p>
                    </div>
                  </div>
                </td>
                <td>
                  <p className="text-sm">{c.email}</p>
                  <p className="tnum text-xs text-stone">{c.phone ?? "—"}</p>
                </td>
                <td>{c.city ?? "—"}</td>
                <td className="tnum">{formatDate(c.createdAt)}</td>
                <td className="tnum">{c.orders}</td>
                <td className="tnum font-semibold">{formatPKR(c.spent)}</td>
                <td>
                  <span className={`meta-sm ${c.status === "active" ? "text-ink" : "text-verm"}`}>
                    {c.status}
                  </span>
                </td>
                <td className="text-right">
                  <Link
                    href={`/admin/customers/${c.id}`}
                    className="link-underline meta-sm inline-flex items-center gap-1.5 text-verm"
                  >
                    View <ArrowRight size={12} />
                  </Link>
                </td>
              </tr>
            ))}
            {customers.length === 0 && (
              <tr>
                <td colSpan={8} className="py-16 text-center">
                  <Users size={30} className="mx-auto text-stone-2" />
                  <p className="mt-4 text-stone">No customers match this filter.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
