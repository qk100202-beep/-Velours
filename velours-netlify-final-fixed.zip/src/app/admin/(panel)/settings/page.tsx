import type { Metadata } from "next";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { SettingsForm } from "@/components/admin/settings-form";
import { CheckCircle2, XCircle, ShieldCheck, HardDrive, Mail, Server } from "lucide-react";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin Settings" };

export default async function AdminSettingsPage() {
  const rows = await db.select().from(settings);
  const map: Record<string, string> = {};
  for (const r of rows) map[r.key] = r.value;

  const admin = await getSessionUser();

  const envChecks = [
    {
      label: "Admin password supplied via environment",
      ok: Boolean(process.env.ADMIN_SEED_PASSWORD),
      note: "Read from ADMIN_SEED_PASSWORD. Never written into source, HTML or the browser bundle.",
    },
    {
      label: "Image storage",
      ok: true,
      note:
        process.env.IMAGE_STORAGE === "cloudinary"
          ? "Cloudinary cloud storage is active (up to your plan's capacity)."
          : "Local object storage outside the source tree (storage/uploads). Set IMAGE_STORAGE=cloudinary to switch to cloud storage.",
    },
    {
      label: "Transactional email",
      ok: Boolean(process.env.RESEND_API_KEY && process.env.EMAIL_FROM),
      note: "Set RESEND_API_KEY, EMAIL_FROM and CONTACT_INBOX to enable order and reset emails.",
    },
    {
      label: "Database connection",
      ok: Boolean(process.env.DATABASE_URL),
      note: "Provided through DATABASE_URL.",
    },
    {
      label: "Cloud storage credentials",
      ok: Boolean(process.env.CLOUDINARY_CLOUD_NAME),
      note: "Set CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY and CLOUDINARY_API_SECRET for CDN delivery.",
    },
  ];

  return (
    <div>
      <header className="border-b border-ink/15 pb-7">
        <p className="meta text-stone">Configuration</p>
        <h1 className="display mt-3 text-[clamp(2.15rem,5.5vw,3.45rem)]">Settings</h1>
        <p className="mt-3 max-w-2xl text-stone">
          Store details, shipping thresholds and a live check of which services are configured for
          this deployment.
        </p>
      </header>

      <div className="mt-9 grid gap-10 lg:grid-cols-[1.35fr_1fr]">
        <section>
          <h2 className="display border-b border-ink/12 pb-3 text-[1.55rem]">Store Settings</h2>
          <div className="mt-7">
            <SettingsForm initial={map} />
          </div>
        </section>

        <aside className="space-y-8">
          <section className="border border-ink/15 bg-paper-2 p-7">
            <h2 className="display text-[1.45rem]">Administrator</h2>
            <div className="mt-5 space-y-3 text-sm">
              <div className="flex justify-between gap-4">
                <span className="text-stone">Name</span>
                <span className="font-medium">{admin?.name}</span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-stone">Email</span>
                <span className="font-medium">{admin?.email}</span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-stone">Role</span>
                <span className="flex items-center gap-1.5 font-medium">
                  <ShieldCheck size={14} className="text-verm" /> Administrator
                </span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-stone">Password</span>
                <span className="tnum text-stone">•••••••• (hashed)</span>
              </div>
            </div>
          </section>

          <section className="border border-ink/15 p-7">
            <h2 className="display text-[1.45rem]">Environment Status</h2>
            <div className="mt-6 space-y-5">
              {envChecks.map((c) => (
                <div key={c.label} className="flex items-start gap-3">
                  {c.ok ? (
                    <CheckCircle2 size={17} className="mt-0.5 shrink-0 text-verm" />
                  ) : (
                    <XCircle size={17} className="mt-0.5 shrink-0 text-stone-2" />
                  )}
                  <div>
                    <p className="text-sm font-medium">{c.label}</p>
                    <p className="mt-1.5 text-xs leading-relaxed text-stone">{c.note}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="border border-ink/15 p-7">
            <h2 className="display text-[1.45rem]">Deployment</h2>
            <div className="mt-6 space-y-4 text-sm">
              <div className="flex items-start gap-3">
                <Server size={16} className="mt-0.5 shrink-0 text-verm" />
                <p className="leading-relaxed text-stone">
                  Netlify-ready. <code className="text-ink">netlify.toml</code> provides the build
                  command, publish directory and SPA redirects for Next.js.
                </p>
              </div>
              <div className="flex items-start gap-3">
                <HardDrive size={16} className="mt-0.5 shrink-0 text-verm" />
                <p className="leading-relaxed text-stone">
                  Uploaded product images live outside <code className="text-ink">src/</code> and are
                  served through <code className="text-ink">/api/files</code>. Switch to cloud
                  storage for production.
                </p>
              </div>
              <div className="flex items-start gap-3">
                <Mail size={16} className="mt-0.5 shrink-0 text-verm" />
                <p className="leading-relaxed text-stone">
                  Add <code className="text-ink">RESEND_API_KEY</code> to send order confirmations
                  and password resets. Until then those flows log to the server console.
                </p>
              </div>
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}
