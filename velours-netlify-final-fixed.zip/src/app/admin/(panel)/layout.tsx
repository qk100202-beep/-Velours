import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { getSessionUser } from "@/lib/auth";
import { AdminSidebar } from "@/components/admin/sidebar";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  // Server-side guard: a customer cannot reach admin pages by changing the URL.
  if (!user) redirect("/admin/login");
  if (user.role !== "admin" || user.status !== "active") redirect("/");

  return (
    <div className="flex min-h-screen bg-paper">
      <AdminSidebar name={user.name} email={user.email} />
      <div className="min-w-0 flex-1 lg:pl-[15.5rem]">
        <div className="mx-auto max-w-[1400px] px-5 py-9 md:px-9 md:py-11">{children}</div>
      </div>
    </div>
  );
}
