import type { Metadata } from "next";
import { db } from "@/db";
import { productImages, products, productVariants } from "@/db/schema";
import { InventoryTable, type InventoryRow } from "@/components/admin/inventory-table";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin Inventory" };

export default async function AdminInventoryPage() {
  const variants = await db.select().from(productVariants);
  const allProducts = await db.select().from(products);
  const images = await db.select().from(productImages);

  const rows: InventoryRow[] = variants
    .map((v) => {
      const product = allProducts.find((p) => p.id === v.productId);
      if (!product) return null;
      return {
        variantId: v.id,
        productId: product.id,
        productName: product.name,
        sku: product.sku,
        category: product.category,
        size: v.size,
        color: v.color,
        colorHex: v.colorHex,
        stock: v.stock,
        image:
          images.find((i) => i.productId === product.id && i.isMain)?.url ??
          images.find((i) => i.productId === product.id)?.url ??
          null,
      };
    })
    .filter((r): r is InventoryRow => r !== null)
    .sort(
      (a, b) =>
        a.productName.localeCompare(b.productName) ||
        a.size.localeCompare(b.size) ||
        a.color.localeCompare(b.color)
    );

  const totalUnits = rows.reduce((s, r) => s + r.stock, 0);
  const low = rows.filter((r) => r.stock > 0 && r.stock <= 8).length;
  const out = rows.filter((r) => r.stock === 0).length;

  return (
    <div>
      <header className="border-b border-ink/15 pb-7">
        <p className="meta text-stone">Stock control</p>
        <h1 className="display mt-3 text-[clamp(2.15rem,5.5vw,3.45rem)]">Inventory</h1>
        <p className="mt-3 max-w-2xl text-stone">
          Every size &amp; colour combination across the catalogue. Change a value and press Save to
          write it straight to the database — the storefront updates immediately.
        </p>
      </header>

      <div className="mt-8 grid gap-px bg-ink/12 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ["Total SKUs", String(rows.length)],
          ["Units on hand", totalUnits.toLocaleString("en-PK")],
          ["Low stock lines", String(low)],
          ["Out of stock lines", String(out)],
        ].map(([label, value]) => (
          <div key={label} className="bg-paper px-6 py-6">
            <p className="meta text-stone">{label}</p>
            <p className="tnum mt-3 text-[1.65rem] font-semibold leading-none">{value}</p>
          </div>
        ))}
      </div>

      <div className="mt-9">
        <InventoryTable rows={rows} />
      </div>
    </div>
  );
}
