import Link from "next/link";
import type { Metadata } from "next";
import { Search, ArrowRight, ClipboardList } from "lucide-react";
import { listAllOrders } from "@/lib/orders";
import { ORDER_STATUSES, STATUS_META, formatDate, formatPKR, type OrderStatus } from "@/lib/constants";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin Orders" };

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; status?: string; sort?: string }>;
}) {
  const { q, status, sort } = await searchParams;
  const orders = await listAllOrders({ search: q, status, sort });

  return (
    <div>
      <header className="flex flex-wrap items-end justify-between gap-5 border-b border-ink/15 pb-7">
        <div>
          <p className="meta text-stone">Fulfilment</p>
          <h1 className="display mt-3 text-[clamp(2.15rem,5.5vw,3.45rem)]">Orders</h1>
          <p className="tnum mt-3 text-stone">
            {orders.length} {orders.length === 1 ? "order" : "orders"}
            {status ? ` · filtered by ${STATUS_META[status as OrderStatus]?.label ?? status}` : ""}
          </p>
        </div>
      </header>

      <form method="GET" className="mt-8 flex flex-wrap items-end gap-3">
        <label className="flex min-w-[17rem] flex-1 items-center gap-3 border-b border-ink/25 pb-2">
          <Search size={16} className="text-stone" />
          <input
            name="q"
            defaultValue={q ?? ""}
            placeholder="Search by order number, customer, email, phone or city…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-stone-2"
          />
        </label>
        <select name="status" defaultValue={status ?? ""} className="field w-auto py-2">
          <option value="">All statuses</option>
          {ORDER_STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_META[s].label}
            </option>
          ))}
        </select>
        <select name="sort" defaultValue={sort ?? ""} className="field w-auto py-2">
          <option value="">Newest first</option>
          <option value="oldest">Oldest first</option>
          <option value="amount-desc">Amount: high to low</option>
          <option value="amount-asc">Amount: low to high</option>
        </select>
        <button type="submit" className="btn btn-outline">
          Filter
        </button>
      </form>

      <div className="mt-8 overflow-x-auto border border-ink/15">
        <table className="dtable min-w-[62rem]">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Customer</th>
              <th>Date</th>
              <th>Items</th>
              <th>Amount</th>
              <th>Payment</th>
              <th>Status</th>
              <th className="text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id}>
                <td className="tnum font-medium">{o.orderNumber}</td>
                <td>
                  <p className="font-medium">{o.customerName}</p>
                  <p className="text-xs text-stone">{o.customerEmail}</p>
                  <p className="tnum text-xs text-stone">{o.customerPhone}</p>
                </td>
                <td className="tnum">{formatDate(o.createdAt)}</td>
                <td className="tnum">{o.itemCount}</td>
                <td className="tnum font-semibold">{formatPKR(o.total)}</td>
                <td>
                  <span className="badge badge-featured capitalize">{o.paymentMethod}</span>
                </td>
                <td>
                  <span
                    className={`meta-sm ${
                      ["cancelled"].includes(o.status) ? "text-stone-2" : "text-verm"
                    }`}
                  >
                    {STATUS_META[o.status as OrderStatus]?.short ?? o.status}
                  </span>
                </td>
                <td>
                  <div className="flex justify-end gap-3">
                    <Link
                      href={`/track?order=${o.orderNumber}&email=${o.customerEmail}`}
                      className="link-underline meta-sm text-stone"
                    >
                      Track view
                    </Link>
                    <Link
                      href={`/admin/orders/${o.id}`}
                      className="link-underline meta-sm inline-flex items-center gap-1.5 text-verm"
                    >
                      Open <ArrowRight size={12} />
                    </Link>
                  </div>
                </td>
              </tr>
            ))}
            {orders.length === 0 && (
              <tr>
                <td colSpan={8} className="py-16 text-center">
                  <ClipboardList size={30} className="mx-auto text-stone-2" />
                  <p className="mt-4 text-stone">No orders match this filter.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
