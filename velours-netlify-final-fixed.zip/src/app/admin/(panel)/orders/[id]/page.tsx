import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArrowLeft, Mail, Phone, MapPin, CreditCard, User } from "lucide-react";
import { getAdminOrder } from "@/lib/orders";
import { formatDateTime, formatPKR, STATUS_META, type OrderStatus } from "@/lib/constants";
import { StatusTimeline } from "@/components/status-timeline";
import { OrderStatusControl } from "@/components/admin/order-status-control";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin Order Details" };

export default async function AdminOrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const order = await getAdminOrder(Number(id));
  if (!order) notFound();

  return (
    <div>
      <Link
        href="/admin/orders"
        className="link-underline meta inline-flex items-center gap-2 text-stone hover:text-ink"
      >
        <ArrowLeft size={14} /> All orders
      </Link>

      <header className="mt-6 flex flex-wrap items-end justify-between gap-6 border-b border-ink/15 pb-7">
        <div>
          <p className="meta text-stone">Order</p>
          <h1 className="display mt-3 text-[clamp(2.15rem,5.5vw,3.45rem)]">{order.orderNumber}</h1>
          <p className="tnum mt-3 text-stone">
            Placed {formatDateTime(order.createdAt)} · Last updated {formatDateTime(order.updatedAt)}
          </p>
        </div>
        <div className="text-right">
          <p className="meta text-stone">Current status</p>
          <p className="display mt-2 text-[1.85rem] text-verm">
            {STATUS_META[order.status as OrderStatus]?.label ?? order.status}
          </p>
          <p className="tnum mt-2 text-lg font-semibold">{formatPKR(order.total)}</p>
        </div>
      </header>

      {/* status control */}
      <section className="mt-8 border border-ink/15 bg-paper-2 p-7">
        <h2 className="display text-[1.55rem]">Update Order Status</h2>
        <p className="mt-2 text-sm text-stone">
          Every change is written to the database and appears immediately on the customer&rsquo;s
          tracking timeline.
        </p>
        <div className="mt-7">
          <OrderStatusControl
            orderId={order.id}
            current={order.status}
            cancelled={order.status === "cancelled"}
          />
        </div>
      </section>

      {/* timeline */}
      <section className="mt-8 border border-ink/15 p-7">
        <h2 className="display text-[1.55rem]">Fulfilment Timeline</h2>
        <div className="mt-9">
          <StatusTimeline status={order.status} events={order.events} />
        </div>
      </section>

      <div className="mt-8 grid gap-8 lg:grid-cols-3">
        {/* customer */}
        <section className="border border-ink/15 p-7">
          <h2 className="display text-[1.45rem]">Customer</h2>
          <div className="mt-6 space-y-4 text-sm">
            <div className="flex items-start gap-3">
              <User size={16} className="mt-0.5 shrink-0 text-verm" />
              <div>
                <p className="font-medium">{order.customerName}</p>
                <p className="meta-sm tnum mt-1 text-stone">
                  {order.userId ? `Account #${order.userId}` : "Guest checkout"}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Mail size={16} className="mt-0.5 shrink-0 text-verm" />
              <a href={`mailto:${order.customerEmail}`} className="link-underline">
                {order.customerEmail}
              </a>
            </div>
            <div className="flex items-start gap-3">
              <Phone size={16} className="mt-0.5 shrink-0 text-verm" />
              <a href={`tel:${order.customerPhone}`} className="tnum link-underline">
                {order.customerPhone}
              </a>
            </div>
            {order.userId && (
              <Link
                href={`/admin/customers/${order.userId}`}
                className="link-underline meta-sm inline-block text-verm"
              >
                View customer profile →
              </Link>
            )}
          </div>
        </section>

        {/* delivery */}
        <section className="border border-ink/15 p-7">
          <h2 className="display text-[1.45rem]">Delivery</h2>
          <div className="mt-6 space-y-4 text-sm">
            <div className="flex items-start gap-3">
              <MapPin size={16} className="mt-0.5 shrink-0 text-verm" />
              <p className="leading-[1.9]">
                {order.address}
                <br />
                {order.city}, {order.province}
                {order.postalCode && (
                  <>
                    <br />
                    {order.postalCode}
                  </>
                )}
              </p>
            </div>
            <div className="rule pt-4">
              <p className="meta text-stone">Delivery instructions</p>
              <p className="mt-2 leading-relaxed text-ink/80">
                {order.instructions || "None provided."}
              </p>
            </div>
          </div>
        </section>

        {/* payment */}
        <section className="border border-ink/15 p-7">
          <h2 className="display text-[1.45rem]">Payment</h2>
          <div className="mt-6 space-y-3 text-sm">
            <div className="flex items-start gap-3">
              <CreditCard size={16} className="mt-0.5 shrink-0 text-verm" />
              <div>
                <p className="font-medium capitalize">
                  {order.paymentMethod === "cod" ? "Cash on delivery" : order.paymentMethod}
                </p>
                <p className="meta-sm mt-1 text-stone">
                  {order.paymentMethod === "cod" ? "Collected by the rider" : "Prepaid"}
                </p>
              </div>
            </div>
            <div className="rule space-y-2.5 pt-4">
              <div className="flex justify-between">
                <span className="text-stone">Subtotal</span>
                <span className="tnum">{formatPKR(order.subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone">Shipping</span>
                <span className="tnum">
                  {order.shipping === 0 ? "Free" : formatPKR(order.shipping)}
                </span>
              </div>
              <div className="flex justify-between border-t border-ink/12 pt-2.5">
                <span className="font-medium">Total</span>
                <span className="tnum font-semibold">{formatPKR(order.total)}</span>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* items */}
      <section className="mt-8 border border-ink/15">
        <div className="border-b border-ink/12 px-6 py-5">
          <h2 className="display text-[1.55rem]">Ordered Products</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="dtable min-w-[46rem]">
            <thead>
              <tr>
                <th>Product</th>
                <th>SKU</th>
                <th>Size</th>
                <th>Colour</th>
                <th>Qty</th>
                <th>Unit price</th>
                <th className="text-right">Line total</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map((item) => (
                <tr key={item.id}>
                  <td>
                    <div className="flex items-center gap-3">
                      <img
                        src={item.imageUrl ?? "/images/tee-black.svg"}
                        alt={item.productName}
                        className="h-12 w-10 shrink-0 object-cover"
                        loading="lazy"
                      />
                      <div>
                        <p className="font-medium">{item.productName}</p>
                        {item.productId && (
                          <Link
                            href={`/admin/products/${item.productId}`}
                            className="link-underline meta-sm text-verm"
                          >
                            Edit product
                          </Link>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="tnum">{item.sku ?? "—"}</td>
                  <td>{item.size}</td>
                  <td>{item.color}</td>
                  <td className="tnum">{item.quantity}</td>
                  <td className="tnum">{formatPKR(item.unitPrice)}</td>
                  <td className="tnum text-right font-semibold">
                    {formatPKR(item.unitPrice * item.quantity)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* history */}
      <section className="mt-8 border border-ink/15 p-7">
        <h2 className="display text-[1.55rem]">Order History</h2>
        <ul className="mt-6 space-y-4">
          {order.events.map((e) => (
            <li key={e.id} className="flex items-start gap-3 text-sm">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 bg-verm" />
              <span>
                <span className="font-medium capitalize">{e.status.replace(/_/g, " ")}</span>
                <span className="tnum ml-2 text-stone">{formatDateTime(e.createdAt)}</span>
                {e.note && <span className="mt-1 block text-stone">{e.note}</span>}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
