import Link from "next/link";
import type { Metadata } from "next";
import {
  Package,
  ClipboardList,
  Users,
  IndianRupee,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Boxes,
  ArrowRight,
} from "lucide-react";
import { getDashboardStats } from "@/lib/data";
import { formatDate, formatPKR, STATUS_META, type OrderStatus } from "@/lib/constants";
import { RevenueBars, TopProductsBars, Donut } from "@/components/admin/charts";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin Dashboard" };

export default async function AdminDashboard() {
  const stats = await getDashboardStats();

  return (
    <div>
      <header className="flex flex-wrap items-end justify-between gap-5 border-b border-ink/15 pb-7">
        <div>
          <p className="meta text-stone">VELOURS control room</p>
          <h1 className="display mt-3 text-[clamp(2.15rem,5.5vw,3.45rem)]">Dashboard</h1>
        </div>
        <div className="flex flex-wrap gap-2.5">
          <Link href="/admin/products/new" className="btn btn-ink">
            Add product
          </Link>
          <Link href="/admin/orders" className="btn btn-outline">
            Manage orders
          </Link>
        </div>
      </header>

      {/* KPI grid */}
      <div className="mt-8 grid gap-px bg-ink/12 sm:grid-cols-2 lg:grid-cols-4">
        {[
          [IndianRupee, "Total sales", formatPKR(stats.revenue), `${stats.totalOrders} orders recorded`],
          [ClipboardList, "Open orders", String(stats.open), `${stats.pending} awaiting confirmation`],
          [CheckCircle2, "Delivered", String(stats.delivered), "Completed successfully"],
          [Users, "Customers", String(stats.customers), "Registered accounts"],
        ].map(([Icon, label, value, note]) => {
          const C = Icon as typeof Package;
          return (
            <div key={label as string} className="bg-paper px-6 py-7">
              <div className="flex items-center justify-between">
                <C size={18} className="text-verm" />
                <span className="meta-sm text-stone">{label as string}</span>
              </div>
              <p className="tnum mt-5 text-[1.85rem] font-semibold leading-none">{value as string}</p>
              <p className="mt-2.5 text-xs text-stone">{note as string}</p>
            </div>
          );
        })}
      </div>

      <div className="mt-8 grid gap-px bg-ink/12 sm:grid-cols-2 lg:grid-cols-4">
        {[
          [Package, "Products", String(stats.products), "In catalogue"],
          [Boxes, "Low stock", String(stats.lowStock), "8 units or fewer", stats.lowStock > 0],
          [AlertTriangle, "Out of stock", String(stats.outOfStock), "Needs restocking", stats.outOfStock > 0],
          [Clock, "New orders", String(stats.recent.length), "Most recent activity"],
        ].map(([Icon, label, value, note, warn]) => {
          const C = Icon as typeof Package;
          return (
            <div key={label as string} className="bg-paper px-6 py-7">
              <div className="flex items-center justify-between">
                <C size={18} className={warn ? "text-verm" : "text-ink/55"} />
                <span className="meta-sm text-stone">{label as string}</span>
              </div>
              <p className={`tnum mt-5 text-[1.85rem] font-semibold leading-none ${warn ? "text-verm" : ""}`}>
                {value as string}
              </p>
              <p className="mt-2.5 text-xs text-stone">{note as string}</p>
            </div>
          );
        })}
      </div>

      {/* charts */}
      <div className="mt-10 grid gap-10 lg:grid-cols-[1.5fr_1fr]">
        <section className="border border-ink/15 p-7">
          <div className="flex items-end justify-between gap-4 border-b border-ink/12 pb-4">
            <h2 className="display text-[1.55rem]">Revenue — Last 6 Months</h2>
            <p className="meta-sm tnum text-stone">PKR, excluding cancellations</p>
          </div>
          <div className="mt-8">
            <RevenueBars data={stats.monthly} />
          </div>
        </section>

        <section className="border border-ink/15 p-7">
          <h2 className="display border-b border-ink/12 pb-4 text-[1.55rem]">Top Products</h2>
          <div className="mt-7">
            <TopProductsBars data={stats.topProducts} />
          </div>

          <h2 className="display mt-10 border-b border-ink/12 pb-4 text-[1.55rem]">Fulfilment</h2>
          <div className="mt-7">
            <Donut
              parts={[
                { label: "Pending", value: stats.pending, color: "#C6422B" },
                { label: "In progress", value: Math.max(0, stats.open - stats.pending), color: "#7A756D" },
                { label: "Delivered", value: stats.delivered, color: "#0B0B0B" },
              ]}
            />
          </div>
        </section>
      </div>

      {/* recent orders */}
      <section className="mt-10 border border-ink/15">
        <div className="flex items-end justify-between gap-4 border-b border-ink/12 px-6 py-5">
          <h2 className="display text-[1.55rem]">Recent Orders</h2>
          <Link href="/admin/orders" className="link-underline meta-sm text-verm">
            View all →
          </Link>
        </div>
        {stats.recent.length === 0 ? (
          <p className="px-6 py-10 text-center text-sm text-stone">
            No orders yet. They will appear here as customers check out.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="dtable min-w-[52rem]">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th>Amount</th>
                  <th>Payment</th>
                  <th>Status</th>
                  <th className="text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {stats.recent.map((o) => (
                  <tr key={o.id}>
                    <td className="tnum font-medium">{o.orderNumber}</td>
                    <td>
                      <p className="font-medium">{o.customerName}</p>
                      <p className="text-xs text-stone">{o.customerEmail}</p>
                    </td>
                    <td className="tnum">{formatDate(o.createdAt)}</td>
                    <td className="tnum font-semibold">{formatPKR(o.total)}</td>
                    <td className="uppercase">{o.paymentMethod}</td>
                    <td>
                      <span className="meta-sm text-verm">
                        {STATUS_META[o.status as OrderStatus]?.short ?? o.status}
                      </span>
                    </td>
                    <td className="text-right">
                      <Link
                        href={`/admin/orders/${o.id}`}
                        className="link-underline meta-sm inline-flex items-center gap-1.5"
                      >
                        Open <ArrowRight size={12} />
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
