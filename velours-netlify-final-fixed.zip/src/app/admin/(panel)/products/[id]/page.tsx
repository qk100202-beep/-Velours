import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getProductById } from "@/lib/data";
import { ProductForm } from "@/components/admin/product-form";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Edit Product" };

export default async function AdminEditProductPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const product = await getProductById(Number(id));
  if (!product) notFound();

  return (
    <div>
      <header className="border-b border-ink/15 pb-7">
        <p className="meta text-stone">Catalogue — Editing</p>
        <h1 className="display mt-3 text-[clamp(2.15rem,5.5vw,3.45rem)]">{product.name}</h1>
        <p className="tnum mt-3 text-stone">
          SKU {product.sku} · {product.images.length} images · {product.variants.length} variants ·{" "}
          {product.totalStock} units
        </p>
      </header>

      <div className="mt-10">
        <ProductForm
          initial={{
            id: product.id,
            name: product.name,
            slug: product.slug,
            category: product.category,
            description: product.description,
            fabric: product.fabric ?? "",
            price: product.price,
            salePrice: product.salePrice ?? "",
            sku: product.sku,
            featured: product.featured,
            newArrival: product.newArrival,
            published: product.published,
            images: product.images.map((img) => ({
              url: img.url,
              alt: img.alt ?? "",
              isMain: img.isMain,
              uploading: false,
              progress: 100,
            })),
            variants: product.variants.map((v) => ({
              size: v.size,
              color: v.color,
              colorHex: v.colorHex ?? "#0B0B0B",
              stock: v.stock,
            })),
          }}
        />
      </div>
    </div>
  );
}
