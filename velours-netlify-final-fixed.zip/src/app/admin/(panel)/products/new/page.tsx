import type { Metadata } from "next";
import { ProductForm } from "@/components/admin/product-form";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Add Product" };

export default function AdminAddProductPage() {
  return (
    <div>
      <header className="border-b border-ink/15 pb-7">
        <p className="meta text-stone">Catalogue</p>
        <h1 className="display mt-3 text-[clamp(2.15rem,5.5vw,3.45rem)]">Add Product</h1>
        <p className="mt-3 max-w-2xl text-stone">
          Create a new T-shirt or hoodie. Upload the full image set — front, back, side and detail —
          then define every size &amp; colour combination with its own stock level.
        </p>
      </header>

      <div className="mt-10">
        <ProductForm />
      </div>
    </div>
  );
}
