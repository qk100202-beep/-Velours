import Link from "next/link";
import type { Metadata } from "next";
import { Plus, Search } from "lucide-react";
import { listProducts } from "@/lib/data";
import { formatPKR } from "@/lib/constants";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin Products" };

export default async function AdminProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; category?: string; status?: string }>;
}) {
  const { q, category, status } = await searchParams;
  let products = await listProducts({ includeUnpublished: true, sort: "newest", limit: 200 });

  if (q) {
    const term = q.toLowerCase();
    products = products.filter(
      (p) =>
        p.name.toLowerCase().includes(term) ||
        p.sku.toLowerCase().includes(term) ||
        p.description.toLowerCase().includes(term)
    );
  }
  if (category) products = products.filter((p) => p.category === category);
  if (status === "published") products = products.filter((p) => p.published);
  if (status === "draft") products = products.filter((p) => !p.published);
  if (status === "low") products = products.filter((p) => p.totalStock > 0 && p.totalStock <= 8);
  if (status === "out") products = products.filter((p) => p.totalStock === 0);

  return (
    <div>
      <header className="flex flex-wrap items-end justify-between gap-5 border-b border-ink/15 pb-7">
        <div>
          <p className="meta text-stone">Catalogue</p>
          <h1 className="display mt-3 text-[clamp(2.15rem,5.5vw,3.45rem)]">Products</h1>
          <p className="tnum mt-3 text-stone">
            {products.length} {products.length === 1 ? "product" : "products"} in the catalogue
          </p>
        </div>
        <Link href="/admin/products/new" className="btn btn-ink">
          <Plus size={15} /> Add product
        </Link>
      </header>

      <form className="mt-8 flex flex-wrap items-end gap-3" method="GET">
        <label className="flex min-w-[16rem] flex-1 items-center gap-3 border-b border-ink/25 pb-2">
          <Search size={16} className="text-stone" />
          <input
            name="q"
            defaultValue={q ?? ""}
            placeholder="Search by name, SKU or description…"
            className="w-full bg-transparent text-sm outline-none placeholder:text-stone-2"
          />
        </label>
        <select name="category" defaultValue={category ?? ""} className="field w-auto py-2">
          <option value="">All categories</option>
          <option value="t-shirts">T-Shirts</option>
          <option value="hoodies">Hoodies</option>
        </select>
        <select name="status" defaultValue={status ?? ""} className="field w-auto py-2">
          <option value="">All statuses</option>
          <option value="published">Published</option>
          <option value="draft">Draft</option>
          <option value="low">Low stock</option>
          <option value="out">Out of stock</option>
        </select>
        <button type="submit" className="btn btn-outline">
          Filter
        </button>
      </form>

      <div className="mt-8 overflow-x-auto border border-ink/15">
        <table className="dtable min-w-[58rem]">
          <thead>
            <tr>
              <th>Product</th>
              <th>SKU</th>
              <th>Category</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Flags</th>
              <th>Status</th>
              <th className="text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td>
                  <div className="flex items-center gap-3">
                    <img
                      src={p.images[0]?.url ?? "/images/tee-black.svg"}
                      alt={p.name}
                      className="h-12 w-10 shrink-0 object-cover"
                      loading="lazy"
                    />
                    <div className="min-w-0">
                      <p className="truncate font-medium">{p.name}</p>
                      <p className="text-xs text-stone">
                        {p.images.length} image{p.images.length === 1 ? "" : "s"} ·{" "}
                        {p.variants.length} variants
                      </p>
                    </div>
                  </div>
                </td>
                <td className="tnum">{p.sku}</td>
                <td className="capitalize">{p.category.replace("-", " ")}</td>
                <td className="tnum">
                  {p.salePrice !== null ? (
                    <>
                      <span className="font-semibold text-verm">{formatPKR(p.salePrice)}</span>
                      <span className="ml-2 text-xs text-stone line-through">
                        {formatPKR(p.price)}
                      </span>
                    </>
                  ) : (
                    formatPKR(p.price)
                  )}
                </td>
                <td className="tnum">
                  <span
                    className={
                      p.totalStock === 0
                        ? "text-verm"
                        : p.totalStock <= 8
                          ? "text-verm"
                          : "text-ink"
                    }
                  >
                    {p.totalStock}
                  </span>
                </td>
                <td>
                  <div className="flex flex-wrap gap-1.5">
                    {p.featured && <span className="badge badge-featured">Featured</span>}
                    {p.newArrival && <span className="badge badge-new">New</span>}
                  </div>
                </td>
                <td>
                  <span className={`meta-sm ${p.published ? "text-ink" : "text-stone-2"}`}>
                    {p.published ? "Published" : "Draft"}
                  </span>
                </td>
                <td>
                  <div className="flex justify-end gap-3">
                    <Link href={`/product/${p.slug}`} className="link-underline meta-sm text-stone">
                      View
                    </Link>
                    <Link
                      href={`/admin/products/${p.id}`}
                      className="link-underline meta-sm text-verm"
                    >
                      Edit
                    </Link>
                  </div>
                </td>
              </tr>
            ))}
            {products.length === 0 && (
              <tr>
                <td colSpan={8} className="py-12 text-center text-stone">
                  No products match this filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
