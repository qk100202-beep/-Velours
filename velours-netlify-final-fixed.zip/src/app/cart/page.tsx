"use client";

import Link from "next/link";
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from "lucide-react";
import { useCart } from "@/components/cart-provider";
import { formatPKR } from "@/lib/constants";
import { EmptyState } from "@/components/ui";
import { motion, AnimatePresence } from "framer-motion";

export default function CartPage() {
  const cart = useCart();

  return (
    <div className="mx-auto max-w-[1500px] px-5 py-12 md:px-9 md:py-16">
      <div className="rule-heavy flex items-end justify-between gap-6 pt-4">
        <h1 className="display text-[clamp(2.4rem,7vw,4.5rem)]">Your Bag</h1>
        <p className="meta-sm tnum pb-2 text-stone">
          {cart.count} {cart.count === 1 ? "item" : "items"}
        </p>
      </div>

      {cart.lines.length === 0 ? (
        <EmptyState
          icon={<ShoppingBag size={36} />}
          title="Your bag is empty"
          description="Nothing here yet. Start with the new drop — the numbered press run goes quickly."
          action={
            <Link href="/shop" className="btn btn-ink mt-2">
              Start shopping
            </Link>
          }
        />
      ) : (
        <div className="mt-10 grid gap-12 lg:grid-cols-[1.6fr_1fr]">
          <div>
            <div className="meta-sm hidden grid-cols-[1fr_7rem_7rem_5rem] gap-4 border-b border-ink/15 pb-3 text-stone md:grid">
              <span>Product</span>
              <span className="text-center">Quantity</span>
              <span className="text-right">Price</span>
              <span className="text-right">Total</span>
            </div>

            <AnimatePresence initial={false}>
              {cart.lines.map((line) => (
                <motion.div
                  key={line.key}
                  layout
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -24 }}
                  transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
                  className="grid grid-cols-1 items-center gap-4 border-b border-ink/10 py-6 md:grid-cols-[1fr_7rem_7rem_5rem]"
                >
                  <div className="flex gap-5">
                    <Link href={`/product/${line.slug}`}>
                      <img
                        src={line.image}
                        alt={line.name}
                        className="h-[7.5rem] w-[6rem] shrink-0 object-cover"
                        loading="lazy"
                      />
                    </Link>
                    <div className="flex min-w-0 flex-col">
                      <Link
                        href={`/product/${line.slug}`}
                        className="text-[1.05rem] font-medium transition-colors hover:text-verm"
                      >
                        {line.name}
                      </Link>
                      <p className="meta-sm tnum mt-1.5 text-stone">SKU {line.sku}</p>
                      <p className="meta-sm mt-1 text-stone">
                        Size {line.size} · {line.color}
                      </p>
                      <button
                        onClick={() => cart.remove(line.key)}
                        className="link-underline meta-sm mt-3 flex items-center gap-1.5 self-start text-stone transition hover:text-verm"
                      >
                        <Trash2 size={13} /> Remove
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-start md:justify-center">
                    <div className="flex items-center border border-ink/18">
                      <button
                        onClick={() => cart.update(line.key, line.quantity - 1)}
                        className="grid h-9 w-9 place-items-center transition hover:bg-ink hover:text-paper"
                        aria-label="Decrease quantity"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="tnum w-9 text-center">{line.quantity}</span>
                      <button
                        onClick={() => cart.update(line.key, line.quantity + 1)}
                        disabled={line.quantity >= line.stock}
                        className="grid h-9 w-9 place-items-center transition hover:bg-ink hover:text-paper disabled:opacity-30"
                        aria-label="Increase quantity"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                    {line.quantity >= line.stock && (
                      <p className="meta-sm ml-3 text-verm md:hidden">Max stock</p>
                    )}
                  </div>

                  <div className="tnum text-left md:text-right">{formatPKR(line.price)}</div>
                  <div className="tnum text-left font-semibold md:text-right">
                    {formatPKR(line.price * line.quantity)}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link href="/shop" className="btn btn-outline">
                Continue shopping
              </Link>
              <button onClick={cart.clear} className="btn btn-outline">
                Empty bag
              </button>
            </div>
          </div>

          {/* summary */}
          <aside className="lg:sticky lg:top-24 lg:self-start">
            <div className="border border-ink/15 bg-paper-2 p-7">
              <h2 className="display text-[1.65rem]">Order Summary</h2>

              <div className="mt-6 space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-stone">Subtotal</span>
                  <span className="tnum">{formatPKR(cart.subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-stone">Shipping</span>
                  <span className="tnum">{cart.shipping === 0 ? "Free" : formatPKR(cart.shipping)}</span>
                </div>
                {cart.subtotal < 8000 && (
                  <p className="tnum meta-sm text-verm">
                    Add {formatPKR(8000 - cart.subtotal)} more for free shipping
                  </p>
                )}
              </div>

              <div className="rule mt-6 flex items-end justify-between pt-5">
                <span className="meta">Total</span>
                <span className="tnum text-[1.65rem] font-semibold">{formatPKR(cart.total)}</span>
              </div>

              <Link href="/checkout" className="btn btn-ink mt-6 w-full">
                Proceed to checkout <ArrowRight size={15} />
              </Link>

              <ul className="mt-6 space-y-2 text-xs leading-relaxed text-stone">
                <li>· Cash on delivery available nationwide</li>
                <li>· Stock is verified before your order is confirmed</li>
                <li>· 7-day return &amp; exchange on unworn items</li>
              </ul>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
