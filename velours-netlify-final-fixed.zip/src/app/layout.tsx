import type { Metadata, Viewport } from "next";
import { Archivo_Black, Inter_Tight, Instrument_Serif } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/components/cart-provider";
import { CartDrawer } from "@/components/cart-drawer";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { IndexRail } from "@/components/index-rail";
import { ToastProvider } from "@/components/toast";
import { seedOnce } from "@/lib/seed";

const archivo = Archivo_Black({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-archivo",
  display: "swap",
});

const interTight = Inter_Tight({
  subsets: ["latin"],
  variable: "--font-inter-tight",
  display: "swap",
});

const instrument = Instrument_Serif({
  weight: "400",
  subsets: ["latin"],
  style: ["normal", "italic"],
  variable: "--font-instrument",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://velours.pk"),
  title: {
    default: "VELOURS — Premium Streetwear, Pakistan",
    template: "%s · VELOURS",
  },
  description:
    "VELOURS builds premium heavyweight T-shirts and hoodies in Karachi for the next generation. Free shipping all over Pakistan.",
  keywords: ["streetwear Pakistan", "premium hoodies Karachi", "oversized t-shirts PKR", "VELOURS"],
  openGraph: {
    title: "VELOURS — Premium Streetwear, Pakistan",
    description: "Premium T-shirts & hoodies for the next generation.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#0B0B0B",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  seedOnce();
  return (
    <html lang="en" className={`${archivo.variable} ${interTight.variable} ${instrument.variable}`}>
      <body className="antialiased">
        <ToastProvider>
          <CartProvider>
            <CartDrawer />
          <IndexRail />
          <div className="rail-offset flex min-h-screen flex-col">
            <Header />
            <main className="flex-1">{children}</main>
              <Footer />
            </div>
          </CartProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
