import Link from "next/link";
import type { Metadata } from "next";
import { Search, PackageSearch } from "lucide-react";
import { lookupOrder } from "@/lib/orders";
import { formatDateTime, formatPKR, STATUS_META, type OrderStatus } from "@/lib/constants";
import { StatusTimeline } from "@/components/status-timeline";
import { Alert, SectionHead } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Track Order",
  description: "Track your VELOURS order in real time using your order number and email.",
};

export default async function TrackPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string; email?: string }>;
}) {
  const { order: orderNo, email } = await searchParams;
  let order = null;
  let error: string | null = null;

  if (orderNo || email) {
    if (!orderNo || !email) {
      error = "Please enter both your order number and the email or phone used at checkout.";
    } else {
      order = await lookupOrder(orderNo, email);
      if (!order) error = "No order matches those details. Check the order number and try again.";
    }
  }

  return (
    <div>
      <header className="relative overflow-hidden bg-ink text-paper">
        <div className="absolute inset-0">
          <img
            src="/images/atelier.svg"
            alt=""
            aria-hidden="true"
            className="h-full w-full object-cover opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/40" />
        </div>
        <div className="relative mx-auto max-w-[1500px] px-5 py-16 md:px-9 md:py-20">
          <p className="meta text-stone-2">Order tracking</p>
          <h1 className="display mt-4 text-[clamp(2.6rem,8vw,5.75rem)]">Where Is My Order?</h1>
          <p className="mt-5 max-w-xl text-[1.02rem] leading-relaxed text-paper/75">
            Enter your order number and the email address or phone number you used at checkout. The
            status shown below is the real status stored against your order.
          </p>
        </div>
      </header>

      <div className="mx-auto max-w-[1100px] px-5 py-14 md:px-9">
        <form method="GET" className="grid gap-6 border border-ink/15 bg-paper-2 p-7 sm:grid-cols-[1fr_1fr_auto]">
          <label className="block">
            <span className="label">Order number</span>
            <input
              name="order"
              defaultValue={orderNo ?? ""}
              placeholder="VLR-20260114-4821"
              className="field tnum"
              required
            />
          </label>
          <label className="block">
            <span className="label">Email or phone</span>
            <input
              name="email"
              defaultValue={email ?? ""}
              placeholder="you@email.com"
              className="field"
              required
            />
          </label>
          <div className="flex items-end">
            <button type="submit" className="btn btn-ink w-full sm:w-auto">
              <Search size={15} /> Track
            </button>
          </div>
        </form>

        {error && (
          <div className="mt-8">
            <Alert tone="error">{error}</Alert>
          </div>
        )}

        {order && (
          <div className="mt-12">
            <div className="flex flex-wrap items-end justify-between gap-6 border-b border-ink/15 pb-8">
              <div>
                <p className="meta text-stone">Order</p>
                <h2 className="display mt-3 text-[clamp(1.9rem,5vw,3.15rem)]">{order.orderNumber}</h2>
                <p className="tnum mt-3 text-stone">Placed {formatDateTime(order.createdAt)}</p>
              </div>
              <div className="text-right">
                <p className="meta text-stone">Current status</p>
                <p className="display mt-2 text-[1.75rem] text-verm">
                  {STATUS_META[order.status as OrderStatus]?.label ?? order.status}
                </p>
              </div>
            </div>

            <div className="mt-10 border border-ink/15 bg-paper-2 p-7">
              <h3 className="display text-[1.45rem]">Progress</h3>
              <p className="mt-3 max-w-2xl text-sm leading-relaxed text-stone">
                {STATUS_META[order.status as OrderStatus]?.description}
              </p>
              <div className="mt-9">
                <StatusTimeline status={order.status} events={order.events} />
              </div>
            </div>

            <div className="mt-10 grid gap-10 md:grid-cols-2">
              <div>
                <h3 className="meta">Items in this order</h3>
                <div className="mt-5 space-y-4">
                  {order.items.map((item) => (
                    <div key={item.id} className="flex items-center gap-4 border-b border-ink/10 pb-4">
                      <img
                        src={item.imageUrl ?? "/images/tee-black.svg"}
                        alt={item.productName}
                        className="h-16 w-14 shrink-0 object-cover"
                        loading="lazy"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{item.productName}</p>
                        <p className="meta-sm tnum mt-1 text-stone">
                          {item.size} / {item.color} · Qty {item.quantity}
                        </p>
                      </div>
                      <p className="tnum text-sm font-semibold">
                        {formatPKR(item.unitPrice * item.quantity)}
                      </p>
                    </div>
                  ))}
                </div>
                <div className="rule mt-5 flex items-end justify-between pt-4">
                  <span className="meta">Total</span>
                  <span className="tnum text-[1.5rem] font-semibold">{formatPKR(order.total)}</span>
                </div>
              </div>

              <div>
                <h3 className="meta">Delivery address</h3>
                <p className="mt-5 text-sm leading-[1.95] text-ink/80">
                  {order.customerName}
                  <br />
                  {order.address}
                  <br />
                  {order.city}, {order.province}
                  {order.postalCode && (
                    <>
                      <br />
                      {order.postalCode}
                    </>
                  )}
                  <br />
                  <span className="tnum">{order.customerPhone}</span>
                </p>

                <h3 className="meta mt-8">Status history</h3>
                <ul className="mt-5 space-y-3">
                  {order.events.map((e) => (
                    <li key={e.id} className="flex items-start gap-3 text-sm">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 bg-verm" />
                      <span>
                        <span className="font-medium capitalize">{e.status.replace(/_/g, " ")}</span>
                        <span className="tnum ml-2 text-stone">{formatDateTime(e.createdAt)}</span>
                        {e.note && <span className="mt-1 block text-stone">{e.note}</span>}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}

        {!order && !error && (
          <div className="mt-16">
            <SectionHead eyebrow="How it works" title="Tracking, Explained" count="03 Steps" />
            <div className="mt-8 grid gap-8 md:grid-cols-3">
              {[
                ["01", "Find your order number", "It looks like VLR-20260114-4821 and is in your confirmation email and on your account page."],
                ["02", "Enter your contact detail", "Use the same email address or phone number you entered at checkout."],
                ["03", "See live status", "Placed → Confirmed → Processing → Packed → Shipped → Out for Delivery → Delivered."],
              ].map(([n, t, d]) => (
                <div key={n} className="rule pt-5">
                  <p className="display tnum text-[2.35rem] text-verm">{n}</p>
                  <h3 className="mt-3 text-[1.05rem] font-medium">{t}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-stone">{d}</p>
                </div>
              ))}
            </div>
            <div className="mt-12 flex items-center gap-3">
              <PackageSearch size={18} className="text-stone" />
              <p className="text-sm text-stone">
                Have an account?{" "}
                <Link href="/account/orders" className="link-underline text-verm">
                  See all your orders
                </Link>
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
