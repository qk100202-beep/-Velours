import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[62vh] max-w-[1100px] flex-col items-start justify-center px-5 py-20 md:px-9">
      <p className="meta text-verm">Error 404</p>
      <h1 className="display mt-5 text-[clamp(3.25rem,13vw,9rem)] leading-[0.84]">
        This page
        <br />
        does not
        <br />
        exist.
      </h1>
      <p className="mt-8 max-w-md leading-relaxed text-stone">
        The link may be broken, or the piece you were looking for may have sold out and been removed
        from the collection.
      </p>
      <div className="mt-9 flex flex-wrap gap-3">
        <Link href="/" className="btn btn-ink">
          Back to home
        </Link>
        <Link href="/shop" className="btn btn-outline">
          Browse the collection
        </Link>
      </div>
    </div>
  );
}
