import Link from "next/link";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { getSessionUser } from "@/lib/auth";
import { listOrdersForUser } from "@/lib/orders";
import { AccountProfile } from "@/components/account-profile";
import { formatDate, formatPKR, STATUS_META, type OrderStatus } from "@/lib/constants";
import { Package, ShoppingBag, Heart, ArrowRight } from "lucide-react";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "My Account" };

export default async function AccountPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/account");

  const orders = await listOrdersForUser(user.id);
  const spend = orders.filter((o) => o.status !== "cancelled").reduce((s, o) => s + o.total, 0);
  const latest = orders.slice(0, 3);

  return (
    <div className="mx-auto max-w-[1500px] px-5 py-12 md:px-9 md:py-16">
      <header className="flex flex-wrap items-end justify-between gap-6 border-b border-ink/15 pb-9">
        <div>
          <p className="meta text-stone">My account</p>
          <h1 className="display mt-4 text-[clamp(2.4rem,7vw,4.5rem)]">Hello, {user.name.split(" ")[0]}</h1>
          <p className="mt-4 text-stone">
            Member since {formatDate(user.createdAt)} · {user.email}
          </p>
        </div>
        <Link href="/account/orders" className="btn btn-ink">
          Order history <ArrowRight size={15} />
        </Link>
      </header>

      {/* stats */}
      <div className="grid gap-px border-b border-ink/15 bg-ink/12 sm:grid-cols-2 lg:grid-cols-4">
        {[
          [Package, "Total orders", String(orders.length)],
          [ShoppingBag, "Total spent", formatPKR(spend)],
          [
            Heart,
            "Active orders",
            String(orders.filter((o) => !["delivered", "cancelled"].includes(o.status)).length),
          ],
          [
            ArrowRight,
            "Last order",
            orders[0] ? formatDate(orders[0].createdAt) : "—",
          ],
        ].map(([Icon, label, value]) => {
          const C = Icon as typeof Package;
          return (
            <div key={label as string} className="bg-paper px-5 py-7">
              <C size={17} className="text-verm" />
              <p className="meta mt-3 text-stone">{label as string}</p>
              <p className="tnum mt-2 text-[1.35rem] font-semibold">{value as string}</p>
            </div>
          );
        })}
      </div>

      {/* recent orders */}
      <section className="mt-14">
        <div className="flex items-end justify-between gap-6 border-b border-ink/15 pb-4">
          <h2 className="display text-[1.85rem]">Recent Orders</h2>
          <Link href="/account/orders" className="link-underline meta text-verm">
            View all →
          </Link>
        </div>

        {latest.length === 0 ? (
          <div className="flex flex-col items-center gap-4 py-16 text-center">
            <ShoppingBag size={34} className="text-stone-2" />
            <p className="text-stone">You have not placed an order yet.</p>
            <Link href="/shop" className="btn btn-ink mt-2">
              Start shopping
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="dtable mt-2 min-w-[46rem]">
              <thead>
                <tr>
                  <th>Order</th>
                  <th>Date</th>
                  <th>Items</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th className="text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {latest.map((o) => (
                  <tr key={o.id}>
                    <td className="tnum font-medium">{o.orderNumber}</td>
                    <td className="tnum">{formatDate(o.createdAt)}</td>
                    <td className="tnum">{o.items.reduce((s, i) => s + i.quantity, 0)}</td>
                    <td className="tnum font-semibold">{formatPKR(o.total)}</td>
                    <td>
                      <span className="meta-sm text-verm">
                        {STATUS_META[o.status as OrderStatus]?.short ?? o.status}
                      </span>
                    </td>
                    <td className="text-right">
                      <Link href={`/orders/${o.id}`} className="link-underline meta-sm text-ink">
                        View
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* profile */}
      <section className="mt-16">
        <AccountProfile
          user={{
            id: user.id,
            name: user.name,
            email: user.email,
            phone: user.phone,
            address: user.address,
            city: user.city,
            province: user.province,
            postalCode: user.postalCode,
          }}
        />
      </section>
    </div>
  );
}
