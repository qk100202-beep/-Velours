import Link from "next/link";
import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { PackageSearch, ArrowRight } from "lucide-react";
import { getSessionUser } from "@/lib/auth";
import { listOrdersForUser } from "@/lib/orders";
import { formatDate, formatPKR, STATUS_META, type OrderStatus } from "@/lib/constants";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Order History" };

export default async function OrderHistoryPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/account/orders");

  const orders = await listOrdersForUser(user.id);

  return (
    <div className="mx-auto max-w-[1500px] px-5 py-12 md:px-9 md:py-16">
      <header className="flex flex-wrap items-end justify-between gap-6 border-b border-ink/15 pb-8">
        <div>
          <p className="meta text-stone">My account</p>
          <h1 className="display mt-4 text-[clamp(2.4rem,7vw,4.5rem)]">Order History</h1>
          <p className="tnum mt-4 text-stone">
            {orders.length} {orders.length === 1 ? "order" : "orders"} placed with VELOURS
          </p>
        </div>
        <Link href="/track" className="btn btn-outline">
          Track an order
        </Link>
      </header>

      {orders.length === 0 ? (
        <div className="flex flex-col items-center gap-5 py-24 text-center">
          <PackageSearch size={40} className="text-stone-2" />
          <h2 className="display text-[1.85rem]">No orders yet</h2>
          <p className="max-w-md text-stone">
            When you place an order it will appear here with its live status, tracking timeline and
            full receipt.
          </p>
          <Link href="/shop" className="btn btn-ink mt-2">
            Browse the collection <ArrowRight size={15} />
          </Link>
        </div>
      ) : (
        <div className="mt-10 space-y-8">
          {orders.map((o) => {
            const meta = STATUS_META[o.status as OrderStatus];
            return (
              <article key={o.id} className="border border-ink/15">
                <div className="flex flex-wrap items-center justify-between gap-5 border-b border-ink/12 bg-paper-2 px-6 py-5">
                  <div>
                    <p className="tnum text-[1.05rem] font-semibold">{o.orderNumber}</p>
                    <p className="tnum meta-sm mt-1.5 text-stone">Placed {formatDate(o.createdAt)}</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-6">
                    <div className="text-right">
                      <p className="meta text-stone">Total</p>
                      <p className="tnum mt-1 font-semibold">{formatPKR(o.total)}</p>
                    </div>
                    <div className="text-right">
                      <p className="meta text-stone">Status</p>
                      <p className="meta-sm mt-1 text-verm">{meta?.short ?? o.status}</p>
                    </div>
                    <div className="flex gap-2">
                      <Link href={`/orders/${o.id}`} className="btn btn-outline px-4 py-2.5">
                        View order
                      </Link>
                      <Link
                        href={`/track?order=${o.orderNumber}&email=${o.customerEmail}`}
                        className="btn btn-ink px-4 py-2.5"
                      >
                        Track
                      </Link>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 overflow-x-auto px-6 py-5">
                  {o.items.map((i) => (
                    <div key={i.id} className="flex w-[15rem] shrink-0 gap-3">
                      <img
                        src={i.imageUrl ?? "/images/tee-black.svg"}
                        alt={i.productName}
                        className="h-[4.5rem] w-[3.5rem] shrink-0 object-cover"
                        loading="lazy"
                      />
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{i.productName}</p>
                        <p className="meta-sm tnum mt-1 text-stone">
                          {i.size} / {i.color} · ×{i.quantity}
                        </p>
                        <p className="tnum mt-1 text-sm">{formatPKR(i.unitPrice * i.quantity)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
