import Link from "next/link";
import { listProducts } from "@/lib/data";
import { ProductCard } from "@/components/product-card";
import { Hero, MarqueeBand } from "@/components/hero";
import { SectionHead } from "@/components/ui";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/reveal";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [featured, newest, best, tees, hoodies] = await Promise.all([
    listProducts({ featured: true, limit: 8 }),
    listProducts({ newArrival: true, limit: 4 }),
    listProducts({ sort: "popular", limit: 4 }),
    listProducts({ category: "t-shirts", limit: 3 }),
    listProducts({ category: "hoodies", limit: 3 }),
  ]);

  return (
    <>
      <Hero />

      <MarqueeBand
        items={[
          "FREE SHIPPING ALL OVER PAKISTAN",
          "240 – 520 GSM",
          "CUT & SEWN IN KARACHI",
          "CASH ON DELIVERY",
          "NEW DROP LIVE",
        ]}
      />

      {/* -------------------- featured collections -------------------- */}
      <section className="mx-auto max-w-[1500px] px-5 pt-16 md:px-9 md:pt-24">
        <SectionHead
          eyebrow="01 — Collections"
          title="Shop the Edit"
          count="03 Chapters"
          href="/shop"
          hrefLabel="All products"
        />

        <StaggerGroup className="mt-8 grid gap-4 md:grid-cols-3">
          {[
            {
              href: "/shop?category=t-shirts",
              title: "T-Shirts",
              blurb: "Comfort meets style",
              img: "/images/tee-black.svg",
              count: `${tees.length * 4} pieces`,
            },
            {
              href: "/shop?category=hoodies",
              title: "Hoodies",
              blurb: "Stay warm, stay real",
              img: "/images/hoodie-bone.svg",
              count: `${hoodies.length * 4} pieces`,
            },
            {
              href: "/shop?new=1",
              title: "New Arrivals",
              blurb: "Fresh styles. New vibes.",
              img: "/images/tee-graphic.svg",
              count: `${newest.length * 3} pieces`,
            },
          ].map((c) => (
            <StaggerItem key={c.title}>
              <Link href={c.href} className="group relative block overflow-hidden bg-ink text-paper">
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={c.img}
                    alt={c.title}
                    loading="lazy"
                    className="h-full w-full object-cover opacity-70 transition-all duration-[900ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.07] group-hover:opacity-85"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/45 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6">
                  <p className="meta-sm tnum text-stone-2">{c.count}</p>
                  <h3 className="display mt-2 text-[1.85rem]">{c.title}</h3>
                  <p className="serif-voice mt-1 text-[1.05rem] text-paper/80">{c.blurb}</p>
                  <span className="link-underline meta mt-4 inline-block text-paper group-hover:text-verm">
                    Shop now →
                  </span>
                </div>
              </Link>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      {/* -------------------- featured products -------------------- */}
      <section className="mx-auto max-w-[1500px] px-5 pt-20 md:px-9">
        <SectionHead
          eyebrow="02 — Featured"
          title="Featured Products"
          count={`${featured.length} pieces`}
          href="/shop?featured=1"
          hrefLabel="View all"
        />
        <p className="serif-voice mt-3 text-[1.25rem] text-stone">Our most loved pieces.</p>

        <StaggerGroup className="mt-9 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 lg:grid-cols-4">
          {featured.map((p, i) => (
            <StaggerItem key={p.id}>
              <ProductCard product={p} priority={i < 4} />
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      {/* -------------------- new drops band -------------------- */}
      <section className="mt-24 bg-ink text-paper">
        <div className="mx-auto grid max-w-[1500px] items-stretch gap-0 lg:grid-cols-2">
          <div className="relative min-h-[22rem] lg:min-h-[36rem]">
            <img
              src="/images/hoodie-black-worn.svg"
              alt="VELOURS new drop campaign"
              loading="lazy"
              className="absolute inset-0 h-full w-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent lg:bg-gradient-to-r" />
          </div>

          <div className="flex flex-col justify-center px-5 py-14 md:px-12 lg:py-20">
            <p className="meta text-stone-2">03 — New Drops</p>
            <h2 className="display mt-5 text-[clamp(2.4rem,6vw,4.6rem)]">
              The Better Days
              <br />
              Ahead Drop
            </h2>
            <p className="mt-6 max-w-md text-[1.02rem] leading-relaxed text-paper/72">
              200 numbered pieces, hand screen-printed on 260 GSM heavyweight cotton. Once the
              press run is gone, it is gone — we do not restock a drop.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/shop?new=1" className="btn btn-paper">
                Shop new arrivals
              </Link>
              <Link href="/product/better-days-ahead-graphic-tee" className="btn btn-outline-paper">
                See the piece
              </Link>
            </div>

            <div className="rule-light mt-10 grid grid-cols-3 gap-6 pt-7">
              {[
                ["200", "Numbered pieces"],
                ["260", "GSM cotton"],
                ["07", "Days returns"],
              ].map(([n, l]) => (
                <div key={l}>
                  <p className="display tnum text-[2.15rem] text-paper">{n}</p>
                  <p className="meta-sm mt-1 text-stone-2">{l}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* -------------------- best sellers -------------------- */}
      <section className="mx-auto max-w-[1500px] px-5 pt-20 md:px-9">
        <SectionHead
          eyebrow="04 — Best Sellers"
          title="Most Wanted"
          count="Ranked by you"
          href="/shop?sort=popular"
          hrefLabel="See ranking"
        />
        <StaggerGroup className="mt-9 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">
          {best.map((p) => (
            <StaggerItem key={p.id}>
              <ProductCard product={p} />
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      {/* -------------------- limited collection -------------------- */}
      <section className="mt-24">
        <div className="mx-auto max-w-[1500px] px-5 md:px-9">
          <div className="grid gap-0 border border-ink/15 lg:grid-cols-[1.15fr_1fr]">
            <div className="relative min-h-[20rem] overflow-hidden lg:min-h-[32rem]">
              <img
                src="/images/detail-macro.svg"
                alt="Cotton jersey macro detail"
                loading="lazy"
                className="absolute inset-0 h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-ink/25 mix-blend-multiply" />
            </div>
            <div className="flex flex-col justify-center bg-paper-2 px-6 py-12 md:px-12">
              <p className="meta text-stone">05 — Limited Collection</p>
              <h2 className="display mt-4 text-[clamp(2.1rem,5vw,3.65rem)]">
                Made in small
                <br />
                numbers, on purpose
              </h2>
              <p className="mt-6 max-w-lg leading-[1.8] text-ink/78">
                Every VELOURS run is produced in batches of a few hundred at a family workshop in
                Karachi. We buy fabric by the roll, cut by hand and print one colour at a time. It
                costs more and it moves slower — but the piece you receive is the one we would wear
                ourselves.
              </p>
              <Link href="/about" className="btn btn-ink mt-8 self-start">
                Read our story
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* -------------------- editorial quote -------------------- */}
      <section className="mx-auto max-w-[1500px] px-5 py-24 md:px-9">
        <Reveal>
          <blockquote className="mx-auto max-w-4xl text-center">
            <p className="serif-voice text-[clamp(1.85rem,5.2vw,3.65rem)] leading-[1.16]">
              “We started VELOURS because the hoodie we wanted to wear did not exist yet — heavy
              enough to last, honest enough to live in.”
            </p>
            <footer className="meta mt-8 text-stone">
              Aliyan Q. — Founder &amp; Head of Design
            </footer>
          </blockquote>
        </Reveal>
      </section>

      {/* -------------------- streetwear collection strip -------------------- */}
      <section className="mx-auto max-w-[1500px] px-5 pb-24 md:px-9">
        <SectionHead
          eyebrow="06 — Streetwear Collection"
          title="Built for the Everyday"
          count="T-Shirts & Hoodies"
          href="/shop"
          hrefLabel="Shop all"
        />
        <StaggerGroup className="mt-8 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 lg:grid-cols-6">
          {[...tees, ...hoodies].map((p) => (
            <StaggerItem key={p.id}>
              <ProductCard product={p} />
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      {/* -------------------- service band -------------------- */}
      <section className="border-y border-ink/12 bg-paper-2">
        <div className="mx-auto grid max-w-[1500px] gap-8 px-5 py-14 md:grid-cols-4 md:px-9">
          {[
            ["Free Shipping", "On every order above Rs. 8,000 across Pakistan."],
            ["Cash on Delivery", "Pay when the parcel arrives at your door."],
            ["7-Day Returns", "Wrong size? Send it back within a week."],
            ["Real Support", "WhatsApp & email, answered by the team."],
          ].map(([t, d]) => (
            <div key={t}>
              <p className="meta text-ink">{t}</p>
              <p className="mt-2.5 text-sm leading-relaxed text-stone">{d}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
