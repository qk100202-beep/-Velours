import type { Metadata } from "next";
import Link from "next/link";
import { PageHero, SectionHead } from "@/components/ui";
import { Reveal, StaggerGroup, StaggerItem } from "@/components/reveal";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "About",
  description:
    "VELOURS is a Karachi streetwear studio building premium heavyweight T-shirts and hoodies in small batches.",
};

export default function AboutPage() {
  return (
    <>
      <PageHero
        eyebrow="About VELOURS"
        title="A small studio in Karachi with high standards."
        description="We started in 2021 with one tee, one screen-printing table and a stubborn idea: Pakistani streetwear could be as heavy, as clean and as well-made as anything imported — at a price our generation can actually pay."
        image="/images/atelier.svg"
      />

      <section className="mx-auto max-w-[1500px] px-5 py-16 md:px-9 md:py-24">
        <div className="grid gap-12 lg:grid-cols-[1.15fr_1fr]">
          <div>
            <SectionHead eyebrow="01 — Our story" title="Built, Not Bought" count="Since 2021" />
            <div className="mt-8 space-y-6 text-[1.02rem] leading-[1.85] text-ink/82">
              <p>
                VELOURS began because the hoodie we wanted to wear did not exist yet. Everything on
                the market was either thin and disposable, or priced like an import. We wanted
                something in between: 480 GSM brushed fleece, a hood that actually holds its shape,
                stitching that survives a hundred washes — and a price that made sense in rupees.
              </p>
              <p>
                Today every piece is cut and sewn at a family-run workshop off Korangi Creek by
                machinists we know by name. We buy fabric by the roll, print one colour at a time on
                a manual press, and produce in batches of a few hundred. It is slower. It is also
                the only way we know to keep the quality honest.
              </p>
              <p>
                We ship free anywhere in Pakistan, accept cash on delivery, and answer our own
                support messages. If a piece is not right, send it back within seven days.
              </p>
            </div>
          </div>

          <div className="relative min-h-[22rem] overflow-hidden lg:min-h-[34rem]">
            <img
              src="/images/detail-macro.svg"
              alt="Macro detail of VELOURS heavyweight cotton"
              className="absolute inset-0 h-full w-full object-cover"
              loading="lazy"
            />
          </div>
        </div>
      </section>

      {/* numbers */}
      <section className="bg-ink text-paper">
        <div className="mx-auto max-w-[1500px] px-5 py-16 md:px-9 md:py-20">
          <StaggerGroup className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["12,400+", "Pieces shipped across Pakistan"],
              ["240–520", "GSM fabric weight range"],
              ["07", "Day return & exchange window"],
              ["04", "Cities with same-week delivery"],
            ].map(([n, l]) => (
              <StaggerItem key={l}>
                <div>
                  <p className="display tnum text-[clamp(2.4rem,5vw,3.65rem)]">{n}</p>
                  <p className="meta-sm mt-3 text-stone-2">{l}</p>
                </div>
              </StaggerItem>
            ))}
          </StaggerGroup>
        </div>
      </section>

      {/* values */}
      <section className="mx-auto max-w-[1500px] px-5 py-16 md:px-9 md:py-24">
        <SectionHead eyebrow="02 — What we stand for" title="The Standard" count="04 Principles" />
        <StaggerGroup className="mt-10 grid gap-x-10 gap-y-12 md:grid-cols-2">
          {[
            [
              "Weight over hype",
              "We would rather release four pieces a year that last than forty that do not. Every product page lists the real GSM, the real fabric and the real fit.",
            ],
            [
              "Made where we live",
              "Cut, sewn, printed and finished in Karachi. Short supply chains mean we can fix a problem in days instead of months.",
            ],
            [
              "Priced for our generation",
              "Direct to you, no middlemen, no import markup. Premium fabric at a price a student saving up can reach.",
            ],
            [
              "Honest service",
              "Cash on delivery, free shipping above Rs. 8,000, seven-day returns and a support line answered by the people who packed your order.",
            ],
          ].map(([t, d], i) => (
            <StaggerItem key={t}>
              <div className="rule pt-6">
                <p className="meta-sm tnum text-verm">{String(i + 1).padStart(2, "0")}</p>
                <h3 className="display mt-3 text-[1.75rem]">{t}</h3>
                <p className="mt-4 max-w-lg leading-[1.85] text-ink/78">{d}</p>
              </div>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </section>

      <section className="border-t border-ink/15">
        <div className="mx-auto flex max-w-[1500px] flex-col items-start gap-8 px-5 py-16 md:flex-row md:items-center md:justify-between md:px-9">
          <Reveal>
            <p className="serif-voice max-w-2xl text-[clamp(1.75rem,4vw,2.85rem)] leading-[1.2]">
              “Wear your story — we just make the fabric heavy enough to hold it.”
            </p>
          </Reveal>
          <Link href="/shop" className="btn btn-ink shrink-0">
            Shop the collection
          </Link>
        </div>
      </section>
    </>
  );
}
