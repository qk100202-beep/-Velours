import type { Metadata } from "next";
import { ShopView, type ShopQuery } from "@/components/shop-view";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "T-Shirts",
  description: "Premium oversized and boxy T-shirts from VELOURS, 220–280 GSM cotton.",
};

export default async function TShirtsPage({ searchParams }: { searchParams: Promise<ShopQuery> }) {
  const query = await searchParams;
  return (
    <ShopView
      query={{ ...query, category: "t-shirts" }}
      eyebrow="Category 01 — T-Shirts"
      title="T-Shirts"
      description="Comfort meets style. Boxy, oversized and heavyweight tees cut from 220–280 GSM combed cotton, garment washed so they feel broken-in from day one."
    />
  );
}
