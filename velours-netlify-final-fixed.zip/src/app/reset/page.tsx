"use client";

import { Suspense, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2 } from "lucide-react";
import { AuthShell } from "@/components/auth-shell";
import { Alert, Field } from "@/components/ui";
import { useToast } from "@/components/toast";

function ResetForm() {
  const router = useRouter();
  const params = useSearchParams();
  const toast = useToast();
  const token = params.get("token") ?? "";

  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (password !== confirm) {
      setError("Passwords do not match.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, newPassword: password }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Reset failed.");
      toast("Password updated — sign in with your new password", "success");
      router.push("/login");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setLoading(false);
    }
  }

  return (
    <AuthShell
      eyebrow="Account recovery"
      title="Set New Password"
      subtitle="Choose something strong — at least 8 characters with a number."
      image="/images/detail-macro.svg"
    >
      {!token ? (
        <div className="space-y-6">
          <Alert tone="error">This reset link is not valid. Request a new one to continue.</Alert>
          <Link href="/forgot" className="btn btn-ink w-full">
            Request a new link
          </Link>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-7">
          {error && <Alert tone="error">{error}</Alert>}
          <Field label="New password">
            <input
              type="password"
              required
              className="field"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="8+ characters"
              autoComplete="new-password"
            />
          </Field>
          <Field label="Confirm new password">
            <input
              type="password"
              required
              className="field"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              placeholder="Repeat password"
              autoComplete="new-password"
            />
          </Field>
          <button type="submit" disabled={loading} className="btn btn-ink w-full">
            {loading ? (
              <>
                <Loader2 size={16} className="spin" /> Updating…
              </>
            ) : (
              "Update password"
            )}
          </button>
        </form>
      )}
    </AuthShell>
  );
}

export default function ResetPage() {
  return (
    <Suspense fallback={<div className="min-h-[60vh]" />}>
      <ResetForm />
    </Suspense>
  );
}
