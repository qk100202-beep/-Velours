import type { Metadata } from "next";
import { ShopView, type ShopQuery } from "@/components/shop-view";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Hoodies",
  description: "Premium heavyweight hoodies from VELOURS, 440–520 GSM brushed fleece.",
};

export default async function HoodiesPage({ searchParams }: { searchParams: Promise<ShopQuery> }) {
  const query = await searchParams;
  return (
    <ShopView
      query={{ ...query, category: "hoodies" }}
      eyebrow="Category 02 — Hoodies"
      title="Hoodies"
      description="Stay warm, stay real. Double-layered hoods, flat woven drawcords and 440–520 GSM brushed fleece, built for cold nights and long roads."
    />
  );
}
