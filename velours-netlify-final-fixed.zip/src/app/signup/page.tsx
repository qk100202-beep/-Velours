"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { AuthShell } from "@/components/auth-shell";
import { Alert, Field } from "@/components/ui";
import { useToast } from "@/components/toast";

export default function SignupPage() {
  const router = useRouter();
  const toast = useToast();
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "", confirm: "" });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function update(key: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (form.password !== form.confirm) {
      setError("Passwords do not match.");
      return;
    }
    if (form.password.length < 8) {
      setError("Password must be at least 8 characters long.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          phone: form.phone,
          password: form.password,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Account creation failed.");
      toast("Welcome to VELOURS", "success");
      router.push("/account");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setLoading(false);
    }
  }

  return (
    <AuthShell
      eyebrow="Join VELOURS"
      title="Create Account"
      subtitle="Faster checkout, order tracking and early access to every drop."
      image="/images/atelier.svg"
      footer={
        <p className="text-sm text-stone">
          Already have an account?{" "}
          <Link href="/login" className="link-underline font-medium text-verm">
            Sign in
          </Link>
        </p>
      }
    >
      <form onSubmit={submit} className="space-y-7">
        {error && <Alert tone="error">{error}</Alert>}
        <Field label="Full name">
          <input
            required
            className="field"
            value={form.name}
            onChange={(e) => update("name", e.target.value)}
            placeholder="Ahmed Raza"
            autoComplete="name"
          />
        </Field>
        <Field label="Email address">
          <input
            required
            type="email"
            className="field"
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
            placeholder="you@email.com"
            autoComplete="email"
          />
        </Field>
        <Field label="Phone number (optional)">
          <input
            type="tel"
            className="field tnum"
            value={form.phone}
            onChange={(e) => update("phone", e.target.value)}
            placeholder="+92 3XX XXXXXXX"
            autoComplete="tel"
          />
        </Field>
        <div className="grid gap-7 sm:grid-cols-2">
          <Field label="Password">
            <input
              required
              type="password"
              className="field"
              value={form.password}
              onChange={(e) => update("password", e.target.value)}
              placeholder="8+ characters"
              autoComplete="new-password"
            />
          </Field>
          <Field label="Confirm password">
            <input
              required
              type="password"
              className="field"
              value={form.confirm}
              onChange={(e) => update("confirm", e.target.value)}
              placeholder="Repeat password"
              autoComplete="new-password"
            />
          </Field>
        </div>

        <button type="submit" disabled={loading} className="btn btn-ink w-full">
          {loading ? (
            <>
              <Loader2 size={16} className="spin" /> Creating account…
            </>
          ) : (
            "Create account"
          )}
        </button>

        <p className="text-xs leading-relaxed text-stone">
          By creating an account you agree to our{" "}
          <Link href="/p/terms" className="link-underline text-ink">
            Terms &amp; Conditions
          </Link>{" "}
          and{" "}
          <Link href="/p/privacy" className="link-underline text-ink">
            Privacy Policy
          </Link>
          .
        </p>
      </form>
    </AuthShell>
  );
}
