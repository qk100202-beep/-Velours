import type { Metadata } from "next";
import { ShopView, type ShopQuery } from "@/components/shop-view";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop All",
  description: "Shop VELOURS premium T-shirts and hoodies. Free shipping across Pakistan.",
};

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<ShopQuery>;
}) {
  const query = await searchParams;
  return (
    <ShopView
      query={query}
      eyebrow="Shop — All Products"
      title={query.search ? `Results for “${query.search}”` : "The Collection"}
      description="Heavyweight T-shirts and hoodies, built in small batches. Filter by size, colour and price to find your piece."
    />
  );
}
