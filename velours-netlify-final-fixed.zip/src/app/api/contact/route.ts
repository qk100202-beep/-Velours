import { NextRequest } from "next/server";
import { ApiError, jsonError } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const subject = String(body.subject ?? "").trim();
    const message = String(body.message ?? "").trim();

    if (name.length < 2) throw new ApiError("Please enter your name.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new ApiError("Please enter a valid email address.");
    if (!subject) throw new ApiError("Please choose a subject.");
    if (message.length < 15) throw new ApiError("Please write a message of at least 15 characters.");

    const payload = { name, email, subject, message, at: new Date().toISOString() };

    if (process.env.RESEND_API_KEY && process.env.CONTACT_INBOX && process.env.EMAIL_FROM) {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: process.env.EMAIL_FROM,
          to: process.env.CONTACT_INBOX,
          replyTo: email,
          subject: `VELOURS contact — ${subject}`,
          html: `<p><strong>${name}</strong> (${email}) wrote:</p><p>${message.replace(/\n/g, "<br/>")}</p>`,
        }),
      });
    } else {
      console.info("[velours] contact message:", JSON.stringify(payload));
    }

    return Response.json({ ok: true, message: "Thanks — our team will reply within 24 hours." });
  } catch (e) {
    return jsonError(e);
  }
}
