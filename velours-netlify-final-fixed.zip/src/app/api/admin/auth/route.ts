import { NextRequest } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { ApiError, createSession, destroySession, jsonError, sha256, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * Admin authentication is intentionally separate from the customer flow.
 * The admin password is never present in source code — it is supplied through
 * the ADMIN_SEED_PASSWORD environment variable and stored only as a salted
 * scrypt hash in the database.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const email = String(body.email ?? "").trim().toLowerCase();
    const password = String(body.password ?? "");
    if (!email || !password) throw new ApiError("Enter your admin email and password.");

    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      throw new ApiError("Incorrect admin credentials.");
    }
    if (user.role !== "admin") {
      // Do not leak whether the account exists or what role it holds.
      throw new ApiError("Incorrect admin credentials.");
    }
    if (user.status !== "active") throw new ApiError("This admin account is disabled.");

    await createSession(user.id, "admin");
    return Response.json({ ok: true, user: { name: user.name, email: user.email, role: user.role } });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE() {
  try {
    await destroySession();
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}

/* Optional: force-expire every session for an account (used by admin settings) */
export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const token = req.cookies.get("velours_session")?.value;
    if (!token) throw new ApiError("Please sign in.", 401);
    const rows = await db
      .select({ role: sessions.role, userId: sessions.userId })
      .from(sessions)
      .where(eq(sessions.id, sha256(token)))
      .limit(1);
    if (!rows[0] || rows[0].role !== "admin") throw new ApiError("Not authorised.", 403);
    const targetId = Number(body.userId);
    if (!targetId) throw new ApiError("Missing user id");
    await db
      .delete(sessions)
      .where(and(eq(sessions.userId, targetId)));
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
