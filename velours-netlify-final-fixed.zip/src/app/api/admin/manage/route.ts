import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { productVariants, users, orders, orderItems, productImages, orderEvents } from "@/db/schema";
import { ApiError, jsonError, requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

/* --------------------------- INVENTORY --------------------------- */
export async function PUT(req: NextRequest) {
  try {
    await requireAdmin();
    const body = await req.json().catch(() => ({}));
    const variantId = Number(body.variantId);
    const stock = Number(body.stock);
    if (!Number.isInteger(variantId)) throw new ApiError("Missing inventory row.");
    if (!Number.isFinite(stock) || stock < 0 || stock > 100000)
      throw new ApiError("Stock must be between 0 and 100000.");

    const [row] = await db
      .update(productVariants)
      .set({ stock })
      .where(eq(productVariants.id, variantId))
      .returning();
    if (!row) throw new ApiError("Inventory row not found.", 404);
    return Response.json({ ok: true, row });
  } catch (e) {
    return jsonError(e);
  }
}

/* ---------------------------- CUSTOMERS -------------------------- */
export async function GET(req: NextRequest) {
  try {
    await requireAdmin();
    const id = Number(new URL(req.url).searchParams.get("id"));
    if (!id) throw new ApiError("Missing customer id.");

    const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    if (!user) throw new ApiError("Customer not found.", 404);

    const userOrders = await db
      .select()
      .from(orders)
      .where(eq(orders.userId, id));
    const orderIds = userOrders.map((o) => o.id);
    const items = orderIds.length
      ? await db.select().from(orderItems)
      : [];
    const images = await db.select().from(productImages);

    return Response.json({
      ok: true,
      customer: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        address: user.address,
        city: user.city,
        province: user.province,
        postalCode: user.postalCode,
        role: user.role,
        status: user.status,
        createdAt: user.createdAt,
      },
      orders: userOrders.map((o) => ({
        ...o,
        items: items
          .filter((i) => i.orderId === o.id)
          .map((i) => ({
            ...i,
            image: images.find((im) => im.productId === i.productId)?.url ?? i.imageUrl,
          })),
      })),
    });
  } catch (e) {
    return jsonError(e);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    const body = await req.json().catch(() => ({}));
    const id = Number(body.id);
    const status = String(body.status ?? "");
    if (!id) throw new ApiError("Missing customer id.");
    if (!["active", "suspended"].includes(status)) throw new ApiError("Unknown account status.");
    if (id === admin.id) throw new ApiError("You cannot change the status of your own account.");

    const [row] = await db
      .update(users)
      .set({ status, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return Response.json({ ok: true, customer: row });
  } catch (e) {
    return jsonError(e);
  }
}

/* --------------------------- ORDER NOTE -------------------------- */
export async function POST(req: NextRequest) {
  try {
    const admin = await requireAdmin();
    const body = await req.json().catch(() => ({}));
    const orderId = Number(body.orderId);
    const note = String(body.note ?? "").trim();
    if (!orderId || !note) throw new ApiError("Write a note first.");
    await db.insert(orderEvents).values({
      orderId,
      status: "note",
      note: `${admin.name}: ${note}`,
    });
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
