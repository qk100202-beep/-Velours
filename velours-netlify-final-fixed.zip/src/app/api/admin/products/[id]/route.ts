import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { jsonError, requireAdmin, ApiError } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    await requireAdmin();
    const { id } = await ctx.params;
    const [product] = await db.select().from(products).where(eq(products.id, Number(id))).limit(1);
    if (!product) throw new ApiError("Product not found.", 404);
    return Response.json({ ok: true, product });
  } catch (e) {
    return jsonError(e);
  }
}

/**
 * PATCH accepts a partial product payload. Image and variant syncing lives in
 * the shared helper used by the create route so both stay identical.
 */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    await requireAdmin();
    const { id } = await ctx.params;
    const productId = Number(id);
    const [existing] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
    if (!existing) throw new ApiError("Product not found.", 404);

    const body = await req.json().catch(() => ({}));
    const { syncChildren, validate } = await import("../route-helpers");
    const data = validate({ ...existing, ...body, salePrice: body.salePrice ?? existing.salePrice });
    const { images, variants, ...columns } = data;

    await db
      .update(products)
      .set({ ...columns, updatedAt: new Date() })
      .where(eq(products.id, productId));
    await syncChildren(productId, images, variants);
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    await requireAdmin();
    const { id } = await ctx.params;
    await db.delete(products).where(eq(products.id, Number(id)));
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
