import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { productImages, products, productVariants } from "@/db/schema";
import { jsonError, requireAdmin, ApiError } from "@/lib/auth";
import { slugify, syncChildren, validate } from "./route-helpers";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await requireAdmin();
    const rows = await db.select().from(products).orderBy(products.createdAt);
    const imgs = await db.select().from(productImages);
    const vars = await db.select().from(productVariants);
    return Response.json({
      ok: true,
      products: rows.map((p) => ({
        ...p,
        images: imgs.filter((i) => i.productId === p.id).sort((a, b) => a.position - b.position),
        variants: vars.filter((v) => v.productId === p.id),
        totalStock: vars.filter((v) => v.productId === p.id).reduce((s, v) => s + v.stock, 0),
      })),
    });
  } catch (e) {
    return jsonError(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
    const payload = await req.json().catch(() => ({}));
    const data = validate(payload);

    const clash = await db.select().from(products).where(eq(products.slug, data.slug)).limit(1);
    if (clash.length) throw new ApiError("A product with this slug already exists.");

    const [product] = await db
      .insert(products)
      .values({
        name: data.name,
        slug: data.slug || slugify(data.name),
        category: data.category,
        description: data.description,
        fabric: data.fabric,
        price: data.price,
        salePrice: data.salePrice,
        sku: data.sku,
        featured: data.featured,
        newArrival: data.newArrival,
        published: data.published,
      })
      .returning();

    await syncChildren(product!.id, data.images, data.variants);
    return Response.json({ ok: true, id: product!.id, slug: product!.slug });
  } catch (e) {
    return jsonError(e);
  }
}
