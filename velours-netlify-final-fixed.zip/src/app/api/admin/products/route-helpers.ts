import { eq } from "drizzle-orm";
import { db } from "@/db";
import { productImages, productVariants } from "@/db/schema";
import { ApiError } from "@/lib/auth";

export type ImageInput = { url: string; alt?: string | null; isMain?: boolean };
export type VariantInput = { size: string; color: string; colorHex?: string | null; stock: number };

export function slugify(name: string) {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export type ProductPayload = {
  name: string;
  category: string;
  price: number;
  salePrice: number | null;
  sku: string;
  description: string;
  fabric: string | null;
  slug: string;
  featured: boolean;
  newArrival: boolean;
  published: boolean;
  images: { url: string; alt: string | null; position: number; isMain: boolean }[];
  variants: { size: string; color: string; colorHex: string | null; stock: number }[];
};

export function validate(payload: Record<string, unknown>): ProductPayload {
  const name = String(payload.name ?? "").trim();
  if (name.length < 3) throw new ApiError("Product name must be at least 3 characters.");
  const category = String(payload.category ?? "");
  if (!["t-shirts", "hoodies"].includes(category)) throw new ApiError("Choose a valid category.");
  const price = Number(payload.price);
  if (!Number.isFinite(price) || price < 1) throw new ApiError("Enter a valid price in PKR.");
  const saleRaw = payload.salePrice;
  const salePrice =
    saleRaw === null || saleRaw === undefined || saleRaw === "" ? null : Number(saleRaw);
  if (salePrice !== null && (!Number.isFinite(salePrice) || salePrice >= price)) {
    throw new ApiError("Sale price must be lower than the regular price.");
  }
  const sku = String(payload.sku ?? "").trim().toUpperCase();
  if (sku.length < 3) throw new ApiError("Enter a valid SKU.");
  const description = String(payload.description ?? "").trim();
  if (description.length < 20) throw new ApiError("Write a description of at least 20 characters.");

  const imagesIn = (payload.images as ImageInput[] | undefined) ?? [];
  if (!imagesIn.length) throw new ApiError("Add at least one product image.");
  const variantsIn = (payload.variants as VariantInput[] | undefined) ?? [];
  if (!variantsIn.length) throw new ApiError("Add at least one size & colour combination.");

  return {
    name,
    category,
    price: Math.round(price),
    salePrice: salePrice === null ? null : Math.round(salePrice),
    sku,
    description,
    fabric: payload.fabric ? String(payload.fabric).trim() : null,
    slug: String(payload.slug ?? "").trim() || slugify(name),
    featured: Boolean(payload.featured),
    newArrival: Boolean(payload.newArrival),
    published: payload.published !== false,
    images: imagesIn.map((img, i) => ({
      url: String(img.url ?? ""),
      alt: img.alt ? String(img.alt) : null,
      position: i,
      isMain: Boolean(img.isMain) || i === 0,
    })),
    variants: variantsIn.map((v) => ({
      size: String(v.size ?? "").toUpperCase(),
      color: String(v.color ?? "").trim(),
      colorHex: v.colorHex ? String(v.colorHex) : null,
      stock: Math.max(0, Math.round(Number(v.stock) || 0)),
    })),
  };
}

export async function syncChildren(
  productId: number,
  images: ProductPayload["images"],
  variants: ProductPayload["variants"]
) {
  await db.delete(productImages).where(eq(productImages.productId, productId));
  await db.insert(productImages).values(
    images.map((img) => ({
      productId,
      url: img.url,
      alt: img.alt,
      position: img.position,
      isMain: img.isMain,
    }))
  );

  const existing = await db
    .select()
    .from(productVariants)
    .where(eq(productVariants.productId, productId));

  for (const v of variants) {
    const match = existing.find((e) => e.size === v.size && e.color === v.color);
    if (match) {
      await db
        .update(productVariants)
        .set({ stock: v.stock, colorHex: v.colorHex })
        .where(eq(productVariants.id, match.id));
    } else {
      await db.insert(productVariants).values({ productId, size: v.size, color: v.color, colorHex: v.colorHex, stock: v.stock });
    }
  }
  for (const e of existing) {
    const still = variants.some((v) => v.size === e.size && v.color === e.color);
    if (!still) await db.delete(productVariants).where(eq(productVariants.id, e.id));
  }
}
