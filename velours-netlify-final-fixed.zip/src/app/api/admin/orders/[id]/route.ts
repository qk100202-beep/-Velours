import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orderEvents, orders, productVariants } from "@/db/schema";
import { ApiError, jsonError, requireAdmin } from "@/lib/auth";
import { ORDER_STATUSES, type OrderStatus } from "@/lib/constants";

export const dynamic = "force-dynamic";

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireAdmin();
    const { id } = await ctx.params;
    const orderId = Number(id);
    const body = await req.json().catch(() => ({}));
    const status = String(body.status ?? "") as OrderStatus;

    if (!ORDER_STATUSES.includes(status)) throw new ApiError("Unknown order status.");

    const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    if (!order) throw new ApiError("Order not found.", 404);
    if (order.status === status) return Response.json({ ok: true, unchanged: true });

    await db
      .update(orders)
      .set({ status, updatedAt: new Date() })
      .where(eq(orders.id, orderId));

    await db.insert(orderEvents).values({
      orderId,
      status,
      note: body.note ? String(body.note) : `Status updated to ${status} by ${admin.email}.`,
    });

    // Restock automatically when an order is cancelled.
    if (status === "cancelled") {
      const { orderItems } = await import("@/db/schema");
      const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
      for (const item of items) {
        const variant = await db
          .select()
          .from(productVariants)
          .where(eq(productVariants.productId, item.productId ?? -1));
        const match = variant.find((v) => v.size === item.size && v.color === item.color);
        if (match) {
          await db
            .update(productVariants)
            .set({ stock: match.stock + item.quantity })
            .where(eq(productVariants.id, match.id));
        }
      }
    }

    return Response.json({ ok: true, status });
  } catch (e) {
    return jsonError(e);
  }
}
