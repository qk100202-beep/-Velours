import { NextRequest } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ApiError, jsonError, requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

const EDITABLE = new Set([
  "site_tagline",
  "support_email",
  "support_phone",
  "shipping_flat",
  "free_shipping_over",
  "announcement",
]);

export async function GET() {
  try {
    await requireAdmin();
    const rows = await db.select().from(settings);
    return Response.json({
      ok: true,
      settings: rows,
      env: {
        imageStorage: process.env.IMAGE_STORAGE || "local",
        emailConfigured: Boolean(process.env.RESEND_API_KEY && process.env.EMAIL_FROM),
        cloudinaryConfigured: Boolean(process.env.CLOUDINARY_CLOUD_NAME),
        nodeEnv: process.env.NODE_ENV,
      },
    });
  } catch (e) {
    return jsonError(e);
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
    const body = await req.json().catch(() => ({}));
    const entries = Object.entries((body.settings ?? {}) as Record<string, string>);

    for (const [key, value] of entries) {
      if (!EDITABLE.has(key)) throw new ApiError(`Setting “${key}” cannot be changed.`);
      await db
        .insert(settings)
        .values({ key, value: String(value) })
        .onConflictDoUpdate({ target: settings.key, set: { value: String(value) } });
    }

    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
