import { NextRequest } from "next/server";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { orderEvents, orderItems, orders, productImages, products, productVariants } from "@/db/schema";
import { ApiError, getSessionUser, jsonError } from "@/lib/auth";
import { FREE_SHIPPING_OVER, SHIPPING_FLAT } from "@/lib/constants";

export const dynamic = "force-dynamic";

type IncomingItem = {
  productId: number;
  size: string;
  color: string;
  quantity: number;
};

function orderNumber() {
  const d = new Date();
  const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
  const rand = Math.floor(Math.random() * 9000) + 1000;
  return `VLR-${stamp}-${rand}`;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const user = await getSessionUser();

    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const phone = String(body.phone ?? "").trim();
    const address = String(body.address ?? "").trim();
    const city = String(body.city ?? "").trim();
    const province = String(body.province ?? "").trim();
    const postalCode = String(body.postalCode ?? "").trim();
    const instructions = String(body.instructions ?? "").trim();
    const paymentMethod = String(body.paymentMethod ?? "cod");

    if (name.length < 2) throw new ApiError("Please enter the full name for this order.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new ApiError("Please enter a valid email address.");
    if (phone.replace(/\D/g, "").length < 10) throw new ApiError("Please enter a valid phone number.");
    if (address.length < 8) throw new ApiError("Please enter a complete delivery address.");
    if (!city) throw new ApiError("Please enter your city.");
    if (!province) throw new ApiError("Please select your province.");
    if (!["cod", "card", "bank"].includes(paymentMethod)) throw new ApiError("Unsupported payment method.");
    if (paymentMethod !== "cod")
      throw new ApiError("Online payment is not enabled yet. Please choose Cash on Delivery.");

    const items: IncomingItem[] = Array.isArray(body.items) ? body.items : [];
    if (!items.length) throw new ApiError("Your bag is empty.");

    for (const it of items) {
      if (!it.productId || !it.size || !it.color) throw new ApiError("Bag item is missing size or colour.");
      if (!Number.isInteger(it.quantity) || it.quantity < 1 || it.quantity > 20)
        throw new ApiError("Quantity must be between 1 and 20.");
    }

    const productIds = [...new Set(items.map((i) => i.productId))];
    const productRows = await db.select().from(products).where(inArray(products.id, productIds));
    const variantRows = await db
      .select()
      .from(productVariants)
      .where(inArray(productVariants.productId, productIds));
    const imageRows = await db
      .select()
      .from(productImages)
      .where(inArray(productImages.productId, productIds));

    const result = await db.transaction(async (tx) => {
      let subtotal = 0;
      const lines: {
        productId: number;
        productName: string;
        sku: string;
        size: string;
        color: string;
        quantity: number;
        unitPrice: number;
        imageUrl: string | null;
        variantId: number;
      }[] = [];

      for (const it of items) {
        const product = productRows.find((p) => p.id === it.productId);
        if (!product || !product.published) {
          throw new ApiError(`A product in your bag is no longer available.`);
        }
        const variant = variantRows.find(
          (v) => v.productId === it.productId && v.size === it.size && v.color === it.color
        );
        if (!variant) throw new ApiError(`${product.name}: ${it.size} / ${it.color} is not available.`);
        if (variant.stock < it.quantity) {
          throw new ApiError(
            `Only ${variant.stock} left of ${product.name} (${it.size} / ${it.color}). Please adjust your bag.`
          );
        }

        const unitPrice = product.salePrice ?? product.price;
        subtotal += unitPrice * it.quantity;

        const image =
          imageRows
            .filter((i) => i.productId === product.id)
            .sort((a, b) => Number(b.isMain) - Number(a.isMain) || a.position - b.position)[0]?.url ?? null;

        lines.push({
          productId: product.id,
          productName: product.name,
          sku: product.sku,
          size: it.size,
          color: it.color,
          quantity: it.quantity,
          unitPrice,
          imageUrl: image,
          variantId: variant.id,
        });

        await tx
          .update(productVariants)
          .set({ stock: variant.stock - it.quantity })
          .where(eq(productVariants.id, variant.id));
      }

      const shipping = subtotal >= FREE_SHIPPING_OVER ? 0 : SHIPPING_FLAT;
      const total = subtotal + shipping;

      const [order] = await tx
        .insert(orders)
        .values({
          orderNumber: orderNumber(),
          userId: user?.id ?? null,
          customerName: name,
          customerEmail: email,
          customerPhone: phone,
          address,
          city,
          province,
          postalCode: postalCode || null,
          instructions: instructions || null,
          subtotal,
          shipping,
          total,
          paymentMethod,
          status: "pending",
        })
        .returning();

      await tx.insert(orderItems).values(
        lines.map((l) => ({
          orderId: order!.id,
          productId: l.productId,
          productName: l.productName,
          sku: l.sku,
          size: l.size,
          color: l.color,
          quantity: l.quantity,
          unitPrice: l.unitPrice,
          imageUrl: l.imageUrl,
        }))
      );

      await tx.insert(orderEvents).values({
        orderId: order!.id,
        status: "pending",
        note: "Order placed by customer.",
      });

      return order!;
    });

    // Confirmation email — only sent when an email provider is configured.
    if (process.env.RESEND_API_KEY && process.env.EMAIL_FROM) {
      try {
        await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            from: process.env.EMAIL_FROM,
            to: email,
            subject: `VELOURS order ${result.orderNumber} confirmed`,
            html: `<h2>Thank you, ${name}.</h2><p>Your order <strong>${result.orderNumber}</strong> has been placed.</p><p>Total: Rs. ${result.total.toLocaleString("en-PK")}</p><p>Track it any time at <a href="${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/track?order=${result.orderNumber}">velours.pk/track</a>.</p>`,
          }),
        });
      } catch (e) {
        console.error("[velours] confirmation email failed", e);
      }
    }

    return Response.json({
      ok: true,
      orderId: result.id,
      orderNumber: result.orderNumber,
      total: result.total,
    });
  } catch (e) {
    return jsonError(e);
  }
}
