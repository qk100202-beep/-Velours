import { NextRequest } from "next/server";
import { jsonError, ApiError } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData().catch(() => null);
    const email = String((form?.get("email") as string) ?? "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) throw new ApiError("Please enter a valid email.");

    if (process.env.RESEND_API_KEY && process.env.EMAIL_FROM) {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: process.env.EMAIL_FROM,
          to: email,
          subject: "Welcome to the VELOURS drop list",
          html: "<p>You are on the list. We will email you before every drop.</p><p>VELOURS</p>",
        }),
      });
    } else {
      console.info("[velours] newsletter signup:", email);
    }

    // Always send the user back to the storefront with a visible confirmation.
    return new Response(null, {
      status: 303,
      headers: { Location: "/?subscribed=1" },
    });
  } catch (e) {
    const res = jsonError(e);
    return res;
  }
}
