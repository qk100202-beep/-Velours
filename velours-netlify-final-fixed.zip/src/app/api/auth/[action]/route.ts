import { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { passwordResets, users } from "@/db/schema";
import {
  ApiError,
  createSession,
  destroySession,
  getSessionUser,
  hashPassword,
  jsonError,
  sha256,
  verifyPassword,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function validateEmail(email: string) {
  if (!EMAIL_RE.test(email.trim())) throw new ApiError("Please enter a valid email address.");
}

function validatePassword(pw: string) {
  if (!pw || pw.length < 8) throw new ApiError("Password must be at least 8 characters long.");
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw))
    throw new ApiError("Password must contain both letters and numbers.");
}

export async function GET(_req: NextRequest, ctx: { params: Promise<{ action: string }> }) {
  const { action } = await ctx.params;
  try {
    if (action === "me") {
      const user = await getSessionUser();
      if (!user) return Response.json({ ok: true, user: null });
      return Response.json({
        ok: true,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          address: user.address,
          city: user.city,
          province: user.province,
          postalCode: user.postalCode,
          role: user.role,
          status: user.status,
          createdAt: user.createdAt,
        },
      });
    }
    throw new ApiError("Not found", 404);
  } catch (e) {
    return jsonError(e);
  }
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ action: string }> }) {
  const { action } = await ctx.params;
  try {
    const body = await req.json().catch(() => ({}));

    switch (action) {
      /* ----------------------------- SIGN UP ---------------------------- */
      case "signup": {
        const name = String(body.name ?? "").trim();
        const email = String(body.email ?? "").trim().toLowerCase();
        const password = String(body.password ?? "");
        if (name.length < 2) throw new ApiError("Please enter your full name.");
        validateEmail(email);
        validatePassword(password);

        const existing = await db.select().from(users).where(eq(users.email, email)).limit(1);
        if (existing.length) throw new ApiError("An account with this email already exists.");

        const [user] = await db
          .insert(users)
          .values({
            name,
            email,
            passwordHash: hashPassword(password),
            phone: body.phone ? String(body.phone).trim() : null,
            role: "customer",
            status: "active",
          })
          .returning();

        await createSession(user!.id, "customer");
        return Response.json({ ok: true, user: { id: user!.id, name: user!.name, email: user!.email } });
      }

      /* ----------------------------- LOGIN ------------------------------ */
      case "login": {
        const email = String(body.email ?? "").trim().toLowerCase();
        const password = String(body.password ?? "");
        validateEmail(email);
        if (!password) throw new ApiError("Please enter your password.");

        const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
        if (!user || !verifyPassword(password, user.passwordHash)) {
          throw new ApiError("Incorrect email or password.");
        }
        if (user.status === "suspended") {
          throw new ApiError("This account has been suspended. Please contact support.");
        }
        if (user.role === "admin") {
          throw new ApiError("Admin accounts must sign in through the admin portal.");
        }
        await createSession(user.id, user.role);
        return Response.json({ ok: true, user: { id: user.id, name: user.name, email: user.email } });
      }

      /* ----------------------------- LOGOUT ---------------------------- */
      case "logout": {
        await destroySession();
        return Response.json({ ok: true });
      }

      /* --------------------------- UPDATE PROFILE ---------------------- */
      case "profile": {
        const me = await getSessionUser();
        if (!me) throw new ApiError("Please sign in to continue.", 401);
        const name = String(body.name ?? "").trim();
        if (name.length < 2) throw new ApiError("Please enter your full name.");
        const email = String(body.email ?? "").trim().toLowerCase();
        validateEmail(email);
        const clash = await db.select().from(users).where(eq(users.email, email)).limit(1);
        if (clash.length && clash[0].id !== me.id) throw new ApiError("That email is already in use.");

        const [updated] = await db
          .update(users)
          .set({
            name,
            email,
            phone: body.phone ? String(body.phone).trim() : null,
            address: body.address ? String(body.address).trim() : null,
            city: body.city ? String(body.city).trim() : null,
            province: body.province ? String(body.province).trim() : null,
            postalCode: body.postalCode ? String(body.postalCode).trim() : null,
            updatedAt: new Date(),
          })
          .where(eq(users.id, me.id))
          .returning();
        return Response.json({ ok: true, user: updated });
      }

      /* --------------------------- CHANGE PASSWORD --------------------- */
      case "password": {
        const me = await getSessionUser();
        if (!me) throw new ApiError("Please sign in to continue.", 401);
        const current = String(body.currentPassword ?? "");
        const next = String(body.newPassword ?? "");
        if (!verifyPassword(current, me.passwordHash))
          throw new ApiError("Your current password is incorrect.");
        validatePassword(next);
        await db
          .update(users)
          .set({ passwordHash: hashPassword(next), updatedAt: new Date() })
          .where(eq(users.id, me.id));
        return Response.json({ ok: true, message: "Password updated." });
      }

      /* --------------------------- FORGOT PASSWORD -------------------- */
      case "forgot": {
        const email = String(body.email ?? "").trim().toLowerCase();
        validateEmail(email);
        const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
        // never reveal whether the account exists
        if (!user) return Response.json({ ok: true });

        const token = sha256(`${user.id}:${Math.random()}:${Date.now()}`).slice(0, 48);
        await db.insert(passwordResets).values({
          userId: user.id,
          tokenHash: sha256(token),
          expiresAt: new Date(Date.now() + 60 * 60 * 1000),
        });

        const resetUrl = `${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/reset?token=${token}`;
        // Email delivery is configured via RESEND_API_KEY / SMTP. Until then the
        // reset link is written to the server log so the flow is still testable.
        if (process.env.RESEND_API_KEY && process.env.EMAIL_FROM) {
          await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              from: process.env.EMAIL_FROM,
              to: user.email,
              subject: "Reset your VELOURS password",
              html: `<p>Hello ${user.name},</p><p>Use the link below to reset your password. It expires in 1 hour.</p><p><a href="${resetUrl}">${resetUrl}</a></p><p>VELOURS</p>`,
            }),
          });
        } else {
          console.info("[velours] password reset link:", resetUrl);
        }
        return Response.json({ ok: true, devResetUrl: process.env.NODE_ENV !== "production" ? resetUrl : undefined });
      }

      /* --------------------------- RESET PASSWORD ---------------------- */
      case "reset": {
        const token = String(body.token ?? "");
        const next = String(body.newPassword ?? "");
        if (!token) throw new ApiError("This reset link is not valid.");
        validatePassword(next);
        const [row] = await db
          .select()
          .from(passwordResets)
          .where(eq(passwordResets.tokenHash, sha256(token)))
          .limit(1);
        if (!row || row.usedAt || row.expiresAt.getTime() < Date.now()) {
          throw new ApiError("This reset link has expired. Please request a new one.");
        }
        await db
          .update(users)
          .set({ passwordHash: hashPassword(next), updatedAt: new Date() })
          .where(eq(users.id, row.userId));
        await db.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.id, row.id));
        return Response.json({ ok: true, message: "Password updated. You can now sign in." });
      }

      default:
        throw new ApiError("Not found", 404);
    }
  } catch (e) {
    return jsonError(e);
  }
}
