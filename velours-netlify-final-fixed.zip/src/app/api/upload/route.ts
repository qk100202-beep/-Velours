import { NextRequest } from "next/server";
import { mkdir, writeFile, unlink } from "fs/promises";
import path from "path";
import { randomBytes } from "crypto";
import { ApiError, jsonError, requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * Product image storage.
 *
 * Files are written OUTSIDE the source tree, to `storage/uploads/` at the
 * project root, and are served through `/api/files/[name]`. Nothing is ever
 * committed to `src/`.
 *
 * To use cloud storage instead (recommended for production, ~15 GB plan):
 * set IMAGE_STORAGE=cloudinary with CLOUDINARY_CLOUD_NAME / API_KEY / API_SECRET
 * and the same request will upload to your Cloudinary account and return the
 * CDN URL. The admin UI does not change.
 */
const MAX_BYTES = 8 * 1024 * 1024;
const ALLOWED = new Map([
  ["image/jpeg", ".svg"],
  ["image/png", ".png"],
  ["image/webp", ".webp"],
  ["image/avif", ".avif"],
]);

async function uploadToCloudinary(buffer: Buffer, filename: string): Promise<string> {
  const cloud = process.env.CLOUDINARY_CLOUD_NAME;
  const key = process.env.CLOUDINARY_API_KEY;
  const secret = process.env.CLOUDINARY_API_SECRET;
  if (!cloud || !key || !secret) throw new ApiError("Cloud storage is not configured.", 500);

  const timestamp = Math.round(Date.now() / 1000);
  const crypto = await import("crypto");
  const signature = crypto
    .createHash("sha1")
    .update(`folder=velours/products&timestamp=${timestamp}${secret}`)
    .digest("hex");

  const form = new FormData();
  form.append("file", new Blob([new Uint8Array(buffer)]), filename);
  form.append("api_key", key);
  form.append("timestamp", String(timestamp));
  form.append("folder", "velours/products");
  form.append("signature", signature);

  const res = await fetch(`https://api.cloudinary.com/v1_1/${cloud}/image/upload`, {
    method: "POST",
    body: form,
  });
  const data = (await res.json()) as { secure_url?: string; error?: { message?: string } };
  if (!res.ok || !data.secure_url) throw new ApiError(data.error?.message || "Image upload failed.", 500);
  return data.secure_url;
}

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
    const form = await req.formData();
    const files = form.getAll("files").filter((f): f is File => f instanceof File);
    if (!files.length) throw new ApiError("No files were selected.");
    if (files.length > 12) throw new ApiError("You can upload up to 12 images at a time.");

    const useCloud = process.env.IMAGE_STORAGE === "cloudinary";
    const uploaded: { url: string; name: string; size: number }[] = [];

    for (const file of files) {
      if (file.size > MAX_BYTES) throw new ApiError(`${file.name} is larger than 8 MB.`);
      const ext = ALLOWED.get(file.type);
      if (!ext) throw new ApiError(`${file.name} is not a supported image (JPG, PNG, WebP or AVIF).`);

      const buffer = Buffer.from(await file.arrayBuffer());
      if (useCloud) {
        const url = await uploadToCloudinary(buffer, file.name);
        uploaded.push({ url, name: file.name, size: file.size });
      } else {
        const dir = path.join(process.cwd(), "storage", "uploads");
        await mkdir(dir, { recursive: true });
        const name = `${Date.now()}-${randomBytes(6).toString("hex")}${ext}`;
        await writeFile(path.join(dir, name), buffer);
        uploaded.push({ url: `/api/files/${name}`, name: file.name, size: file.size });
      }
    }

    return Response.json({ ok: true, files: uploaded });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    await requireAdmin();
    const body = await req.json().catch(() => ({}));
    const url = String(body.url ?? "");
    if (!url.startsWith("/api/files/")) throw new ApiError("Only managed uploads can be deleted.");
    const name = path.basename(url);
    await unlink(path.join(process.cwd(), "storage", "uploads", name)).catch(() => {});
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
