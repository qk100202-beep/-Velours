import "server-only";
import { db } from "@/db";
import { orderEvents, orderItems, orders, productImages, users } from "@/db/schema";
import { and, eq, desc, or } from "drizzle-orm";

export type OrderLine = {
  id: number;
  productId: number | null;
  productName: string;
  sku: string | null;
  size: string;
  color: string;
  quantity: number;
  unitPrice: number;
  imageUrl: string | null;
};

export type OrderWithItems = {
  id: number;
  orderNumber: string;
  userId: number | null;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  address: string;
  city: string;
  province: string;
  postalCode: string | null;
  instructions: string | null;
  subtotal: number;
  shipping: number;
  total: number;
  paymentMethod: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  items: OrderLine[];
  events: { id: number; status: string; note: string | null; createdAt: string }[];
};

function shape(
  order: typeof orders.$inferSelect,
  items: OrderLine[],
  events: { id: number; status: string; note: string | null; createdAt: Date }[]
): OrderWithItems {
  return {
    ...order,
    createdAt: order.createdAt.toISOString(),
    updatedAt: order.updatedAt.toISOString(),
    items,
    events: events.map((e) => ({ ...e, createdAt: e.createdAt.toISOString() })),
  };
}

async function load(id: number): Promise<OrderWithItems | null> {
  const [order] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  if (!order) return null;

  const rawItems = await db.select().from(orderItems).where(eq(orderItems.orderId, id));
  const imgs = await db.select().from(productImages);
  const events = await db
    .select()
    .from(orderEvents)
    .where(eq(orderEvents.orderId, id))
    .orderBy(orderEvents.createdAt);

  const items: OrderLine[] = rawItems.map((i) => ({
    id: i.id,
    productId: i.productId,
    productName: i.productName,
    sku: i.sku,
    size: i.size,
    color: i.color,
    quantity: i.quantity,
    unitPrice: i.unitPrice,
    imageUrl:
      imgs.find((im) => im.productId === i.productId && im.isMain)?.url ??
      imgs.find((im) => im.productId === i.productId)?.url ??
      i.imageUrl,
  }));

  return shape(order, items, events);
}

export async function getOrderByNumber(orderNumber: string) {
  const [order] = await db
    .select()
    .from(orders)
    .where(eq(orders.orderNumber, orderNumber.trim()))
    .limit(1);
  if (!order) return null;
  return load(order.id);
}

export async function getOrderForUser(id: number, userId: number) {
  const rows = await db
    .select()
    .from(orders)
    .where(and(eq(orders.id, id), eq(orders.userId, userId)))
    .limit(1);
  if (!rows[0]) return null;
  return load(id);
}

export async function listOrdersForUser(userId: number) {
  const rows = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, userId))
    .orderBy(desc(orders.createdAt));

  const allItems = await db.select().from(orderItems);
  const imgs = await db.select().from(productImages);

  return rows.map((o) => ({
    ...o,
    createdAt: o.createdAt.toISOString(),
    updatedAt: o.updatedAt.toISOString(),
    items: allItems
      .filter((i) => i.orderId === o.id)
      .map((i) => ({
        ...i,
        imageUrl:
          imgs.find((im) => im.productId === i.productId && im.isMain)?.url ??
          i.imageUrl,
      })),
  }));
}

export async function lookupOrder(orderNumber: string, email: string) {
  const [order] = await db
    .select()
    .from(orders)
    .where(
      and(
        eq(orders.orderNumber, orderNumber.trim().toUpperCase()),
        or(eq(orders.customerEmail, email.trim().toLowerCase()), eq(orders.customerPhone, email.trim()))
      )
    )
    .limit(1);
  if (!order) return null;
  return load(order.id);
}

export async function listAllOrders(opts: { search?: string; status?: string; sort?: string } = {}) {
  const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
  const items = await db.select().from(orderItems);

  let list = rows.map((o) => ({
    ...o,
    createdAt: o.createdAt.toISOString(),
    updatedAt: o.updatedAt.toISOString(),
    itemCount: items.filter((i) => i.orderId === o.id).reduce((s, i) => s + i.quantity, 0),
  }));

  if (opts.status && opts.status !== "all") list = list.filter((o) => o.status === opts.status);
  if (opts.search) {
    const q = opts.search.toLowerCase();
    list = list.filter(
      (o) =>
        o.orderNumber.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.customerEmail.toLowerCase().includes(q) ||
        o.customerPhone.toLowerCase().includes(q) ||
        o.city.toLowerCase().includes(q)
    );
  }
  if (opts.sort === "amount-desc") list.sort((a, b) => b.total - a.total);
  else if (opts.sort === "amount-asc") list.sort((a, b) => a.total - b.total);
  else if (opts.sort === "oldest") list.sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt));

  return list;
}

export async function getAdminOrder(id: number) {
  return load(id);
}

export async function listCustomers() {
  const rows = await db.select().from(users).orderBy(desc(users.createdAt));
  const orderRows = await db.select().from(orders);
  return rows.map((u) => {
    const mine = orderRows.filter((o) => o.userId === u.id);
    return {
      id: u.id,
      name: u.name,
      email: u.email,
      phone: u.phone,
      city: u.city,
      role: u.role,
      status: u.status,
      createdAt: u.createdAt.toISOString(),
      orders: mine.length,
      spent: mine
        .filter((o) => o.status !== "cancelled")
        .reduce((s, o) => s + o.total, 0),
      lastOrder: mine.length
        ? mine.map((o) => o.createdAt.toISOString()).sort().reverse()[0]
        : null,
    };
  });
}
