/** Central image map: replace files in /public/images without changing product code. */
export const STORE_IMAGES = {
  teeBlack: "/images/tee-black.svg",
  teeGraphic: "/images/tee-graphic.svg",
  hoodieBone: "/images/hoodie-bone.svg",
  hoodieBlack: "/images/hoodie-black-worn.svg",
  detail: "/images/detail-macro.svg",
  atelier: "/images/atelier.svg",
  hero: "/images/hero.svg",
} as const;
