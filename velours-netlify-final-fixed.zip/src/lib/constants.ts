export const CATEGORIES = [
  { slug: "t-shirts", label: "T-Shirts", blurb: "Comfort meets style" },
  { slug: "hoodies", label: "Hoodies", blurb: "Stay warm, stay real" },
] as const;

export const SIZES = ["XS", "S", "M", "L", "XL", "XXL"] as const;

export const COLORS: { name: string; hex: string }[] = [
  { name: "Jet Black", hex: "#0B0B0B" },
  { name: "Bone", hex: "#E9E3D6" },
  { name: "Stone", hex: "#A8A093" },
  { name: "Charcoal", hex: "#3A3A3A" },
  { name: "Vermilion", hex: "#C6422B" },
  { name: "Olive", hex: "#5A5B45" },
];

export const PROVINCES = [
  "Sindh",
  "Punjab",
  "Khyber Pakhtunkhwa",
  "Balochistan",
  "Islamabad Capital Territory",
  "Gilgit-Baltistan",
  "Azad Jammu & Kashmir",
] as const;

export const SHIPPING_FLAT = 250;
export const FREE_SHIPPING_OVER = 8000;

export const ORDER_STATUSES = [
  "pending",
  "confirmed",
  "processing",
  "packed",
  "shipped",
  "out_for_delivery",
  "delivered",
  "cancelled",
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const STATUS_META: Record<
  OrderStatus,
  { label: string; short: string; step: number; description: string }
> = {
  pending: {
    label: "Order Placed",
    short: "Placed",
    step: 0,
    description: "We have received your order and it is waiting for confirmation.",
  },
  confirmed: {
    label: "Order Confirmed",
    short: "Confirmed",
    step: 1,
    description: "Your order has been verified by the VELOURS team.",
  },
  processing: {
    label: "Processing",
    short: "Processing",
    step: 2,
    description: "Your pieces are being picked, checked and prepared.",
  },
  packed: {
    label: "Packed",
    short: "Packed",
    step: 3,
    description: "Your order is packed and ready to leave the studio.",
  },
  shipped: {
    label: "Shipped",
    short: "Shipped",
    step: 4,
    description: "Your parcel has been handed to our delivery partner.",
  },
  out_for_delivery: {
    label: "Out for Delivery",
    short: "Out for Delivery",
    step: 5,
    description: "Your rider is on the way to your address.",
  },
  delivered: {
    label: "Delivered",
    short: "Delivered",
    step: 6,
    description: "Your order has been delivered. Enjoy your VELOURS piece.",
  },
  cancelled: {
    label: "Cancelled",
    short: "Cancelled",
    step: -1,
    description: "This order was cancelled. Any payment has been reversed.",
  },
};

export const TRACKING_STEPS: OrderStatus[] = [
  "pending",
  "confirmed",
  "processing",
  "packed",
  "shipped",
  "out_for_delivery",
  "delivered",
];

export function formatPKR(amount: number): string {
  return "Rs. " + amount.toLocaleString("en-PK");
}

export function formatDate(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleDateString("en-PK", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function formatDateTime(d: Date | string): string {
  const date = typeof d === "string" ? new Date(d) : d;
  return date.toLocaleString("en-PK", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
