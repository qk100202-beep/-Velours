import "server-only";
import { db } from "@/db";
import { orderItems, orders, productImages, products, productVariants, users } from "@/db/schema";
import { and, asc, desc, eq, gte, inArray, lte, or, sql, count, ne } from "drizzle-orm";

export type ProductImageDTO = {
  id: number;
  url: string;
  alt: string | null;
  position: number;
  isMain: boolean;
};

export type ProductVariantDTO = {
  id: number;
  size: string;
  color: string;
  colorHex: string | null;
  stock: number;
};

export type ProductDTO = {
  id: number;
  name: string;
  slug: string;
  category: string;
  description: string;
  fabric: string | null;
  price: number;
  salePrice: number | null;
  sku: string;
  featured: boolean;
  newArrival: boolean;
  published: boolean;
  createdAt: string;
  images: ProductImageDTO[];
  variants: ProductVariantDTO[];
  totalStock: number;
  colors: { name: string; hex: string | null; stock: number }[];
  sizes: string[];
  minPrice: number;
};

function serialize(
  p: typeof products.$inferSelect,
  images: ProductImageDTO[],
  variants: ProductVariantDTO[]
): ProductDTO {
  const sorted = [...images].sort((a, b) => a.position - b.position);
  const main = sorted.find((i) => i.isMain) ?? sorted[0];
  const ordered = main ? [main, ...sorted.filter((i) => i.id !== main.id)] : sorted;
  const totalStock = variants.reduce((s, v) => s + v.stock, 0);
  const colorMap = new Map<string, { name: string; hex: string | null; stock: number }>();
  for (const v of variants) {
    const existing = colorMap.get(v.color);
    if (existing) existing.stock += v.stock;
    else colorMap.set(v.color, { name: v.color, hex: v.colorHex, stock: v.stock });
  }
  const sizeSet = new Set<string>();
  for (const v of variants) if (v.stock > 0) sizeSet.add(v.size);
  return {
    id: p.id,
    name: p.name,
    slug: p.slug,
    category: p.category,
    description: p.description,
    fabric: p.fabric,
    price: p.price,
    salePrice: p.salePrice,
    sku: p.sku,
    featured: p.featured,
    newArrival: p.newArrival,
    published: p.published,
    createdAt: p.createdAt.toISOString(),
    images: ordered,
    variants,
    totalStock,
    colors: [...colorMap.values()],
    sizes: [...sizeSet],
    minPrice: p.salePrice ?? p.price,
  };
}

async function loadBundle(rows: (typeof products.$inferSelect)[]): Promise<ProductDTO[]> {
  if (rows.length === 0) return [];
  const ids = rows.map((r) => r.id);
  const imgs = await db.select().from(productImages).where(inArray(productImages.productId, ids));
  const vars = await db.select().from(productVariants).where(inArray(productVariants.productId, ids));
  return rows.map((r) =>
    serialize(
      r,
      imgs
        .filter((i) => i.productId === r.id)
        .map((i) => ({ id: i.id, url: i.url, alt: i.alt, position: i.position, isMain: i.isMain })),
      vars
        .filter((v) => v.productId === r.id)
        .map((v) => ({
          id: v.id,
          size: v.size,
          color: v.color,
          colorHex: v.colorHex,
          stock: v.stock,
        }))
    )
  );
}

export async function getProductBySlug(slug: string, opts?: { includeUnpublished?: boolean }) {
  const rows = await db
    .select()
    .from(products)
    .where(
      opts?.includeUnpublished
        ? eq(products.slug, slug)
        : and(eq(products.slug, slug), eq(products.published, true))
    )
    .limit(1);
  if (!rows[0]) return null;
  const [dto] = await loadBundle(rows);
  return dto;
}

export async function getProductById(id: number) {
  const rows = await db.select().from(products).where(eq(products.id, id)).limit(1);
  if (!rows[0]) return null;
  const [dto] = await loadBundle(rows);
  return dto;
}

export type ProductQuery = {
  category?: string;
  search?: string;
  size?: string;
  color?: string;
  minPrice?: number;
  maxPrice?: number;
  newArrival?: boolean;
  featured?: boolean;
  sort?: "newest" | "price-asc" | "price-desc" | "name" | "popular";
  limit?: number;
  includeUnpublished?: boolean;
};

export async function listProducts(q: ProductQuery = {}): Promise<ProductDTO[]> {
  const filters = [q.includeUnpublished ? undefined : eq(products.published, true)];
  if (q.category) filters.push(eq(products.category, q.category));
  if (q.newArrival) filters.push(eq(products.newArrival, true));
  if (q.featured) filters.push(eq(products.featured, true));
  if (q.search) {
    const term = `%${q.search.trim().toLowerCase()}%`;
    filters.push(
      or(
        sql`lower(${products.name}) like ${term}`,
        sql`lower(${products.description}) like ${term}`,
        sql`lower(${products.sku}) like ${term}`,
        sql`lower(${products.category}) like ${term}`
      )
    );
  }
  if (typeof q.minPrice === "number") filters.push(gte(products.price, q.minPrice));
  if (typeof q.maxPrice === "number") filters.push(lte(products.price, q.maxPrice));

  let rows = await db
    .select()
    .from(products)
    .where(and(...filters));

  let list = await loadBundle(rows);

  if (q.size) list = list.filter((p) => p.variants.some((v) => v.size === q.size && v.stock > 0));
  if (q.color) list = list.filter((p) => p.colors.some((c) => c.name === q.color && c.stock > 0));

  switch (q.sort) {
    case "price-asc":
      list.sort((a, b) => a.minPrice - b.minPrice);
      break;
    case "price-desc":
      list.sort((a, b) => b.minPrice - a.minPrice);
      break;
    case "name":
      list.sort((a, b) => a.name.localeCompare(b.name));
      break;
    case "popular":
      list.sort((a, b) => Number(b.featured) - Number(a.featured) || b.totalStock - a.totalStock);
      break;
    default:
      list.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
  }
  return q.limit ? list.slice(0, q.limit) : list;
}

/* ------------------------------ wishlist --------------------------- */

export async function getWishlistIds(userId: number): Promise<number[]> {
  const { wishlistItems } = await import("@/db/schema");
  const rows = await db
    .select({ id: wishlistItems.productId })
    .from(wishlistItems)
    .where(eq(wishlistItems.userId, userId));
  return rows.map((r) => r.id);
}

/* ------------------------------- stats ----------------------------- */

export async function getDashboardStats() {
  const [orderAgg] = await db
    .select({
      total: count(),
      revenue: sql<number>`coalesce(sum(case when ${orders.status} <> 'cancelled' then ${orders.total} else 0 end), 0)`,
      pending: sql<number>`coalesce(sum(case when ${orders.status} = 'pending' then 1 else 0 end), 0)`,
      delivered: sql<number>`coalesce(sum(case when ${orders.status} = 'delivered' then 1 else 0 end), 0)`,
      open: sql<number>`coalesce(sum(case when ${orders.status} not in ('delivered','cancelled') then 1 else 0 end), 0)`,
    })
    .from(orders);

  const [customerCount] = await db
    .select({ total: count() })
    .from(users)
    .where(eq(users.role, "customer"));

  const [productCount] = await db.select({ total: count() }).from(products);

  const variantRows = await db
    .select({
      productId: productVariants.productId,
      stock: sql<number>`sum(${productVariants.stock})`,
    })
    .from(productVariants)
    .groupBy(productVariants.productId);

  const lowStock = variantRows.filter((v) => (v.stock ?? 0) > 0 && (v.stock ?? 0) <= 8).length;
  const outOfStock = variantRows.filter((v) => (v.stock ?? 0) === 0).length;

  const recent = await db
    .select()
    .from(orders)
    .orderBy(desc(orders.createdAt))
    .limit(6);

  // 6 months of revenue for the chart
  const monthly = await db
    .select({
      month: sql<string>`to_char(date_trunc('month', ${orders.createdAt}), 'Mon')`,
      revenue: sql<number>`coalesce(sum(case when ${orders.status} <> 'cancelled' then ${orders.total} else 0 end), 0)`,
      orders: count(),
    })
    .from(orders)
    .where(gte(orders.createdAt, new Date(Date.now() - 180 * 24 * 60 * 60 * 1000)))
    .groupBy(sql`date_trunc('month', ${orders.createdAt})`)
    .orderBy(sql`date_trunc('month', ${orders.createdAt})`);

  const topProducts = await db
    .select({
      name: orderItems.productName,
      units: sql<number>`sum(${orderItems.quantity})`,
      revenue: sql<number>`sum(${orderItems.quantity} * ${orderItems.unitPrice})`,
    })
    .from(orderItems)
    .innerJoin(orders, eq(orderItems.orderId, orders.id))
    .where(ne(orders.status, "cancelled"))
    .groupBy(orderItems.productName)
    .orderBy(desc(sql`sum(${orderItems.quantity})`))
    .limit(5);

  return {
    totalOrders: orderAgg.total,
    revenue: Number(orderAgg.revenue ?? 0),
    pending: Number(orderAgg.pending ?? 0),
    delivered: Number(orderAgg.delivered ?? 0),
    open: Number(orderAgg.open ?? 0),
    customers: customerCount.total,
    products: productCount.total,
    lowStock,
    outOfStock,
    recent,
    monthly,
    topProducts,
  };
}
