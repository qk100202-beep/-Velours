import "server-only";
import { db } from "@/db";
import { products, productImages, productVariants, users, settings } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { count, eq } from "drizzle-orm";
import { STORE_IMAGES } from "@/lib/image-assets";

type SeedVariant = { size: string; color: string; hex: string; stock: number };

const IMG = STORE_IMAGES;

function variants(defs: [string, string, string][]): SeedVariant[] {
  // deterministic stock so the catalog is stable across restarts
  const out: SeedVariant[] = [];
  let n = 7;
  for (const [size, color, hex] of defs) {
    n = (n * 31 + 17) % 97;
    out.push({ size, color, hex, stock: n % 11 === 0 ? 0 : (n % 14) + 1 });
  }
  return out;
}

type SeedProduct = {
  name: string;
  slug: string;
  category: string;
  description: string;
  fabric: string;
  price: number;
  salePrice?: number;
  sku: string;
  featured?: boolean;
  newArrival?: boolean;
  images: string[];
  variants: SeedVariant[];
};

const BLACK = ["Jet Black", "#0B0B0B"] as const;
const BONE = ["Bone", "#E9E3D6"] as const;
const STONE = ["Stone", "#A8A093"] as const;
const CHARCOAL = ["Charcoal", "#3A3A3A"] as const;
const VERM = ["Vermilion", "#C6422B"] as const;

const sizeRun = ["S", "M", "L", "XL", "XXL"];

function fullRun(colors: (readonly [string, string])[]): [string, string, string][] {
  const out: [string, string, string][] = [];
  for (const [name, hex] of colors) for (const s of sizeRun) out.push([s, name, hex]);
  return out;
}

const SEED: SeedProduct[] = [
  {
    name: "Void Oversized Tee",
    slug: "void-oversized-tee",
    category: "t-shirts",
    description:
      "Our founding silhouette. A 240 GSM combed-cotton boxy tee with a dropped shoulder, ribbed neck band and a tonal chest hit. Pre-shrunk, garment-washed and cut to sit away from the body — the shape we built VELOURS around.",
    fabric: "240 GSM combed cotton, garment washed, bio-polished",
    price: 3490,
    sku: "VL-TEE-001",
    featured: true,
    newArrival: true,
    images: [IMG.teeBlack, IMG.detail, IMG.teeGraphic],
    variants: variants(fullRun([BLACK, BONE, CHARCOAL])),
  },
  {
    name: "Karachi Nights Hoodie",
    slug: "karachi-nights-hoodie",
    category: "hoodies",
    description:
      "A 480 GSM brushed-fleece hoodie built for the hours after midnight. Double-layered hood, flat woven drawcords, ribbed cuffs and hem, and a kangaroo pocket deep enough to actually use. Oversized through the body with a clean raglan line.",
    fabric: "480 GSM brushed cotton fleece, double-layer hood",
    price: 6990,
    sku: "VL-HOD-001",
    featured: true,
    newArrival: true,
    images: [IMG.hoodieBlack, IMG.hoodieBone, IMG.detail],
    variants: variants(fullRun([BLACK, CHARCOAL])),
  },
  {
    name: "Bone Standard Hoodie",
    slug: "bone-standard-hoodie",
    category: "hoodies",
    description:
      "The neutral that goes with everything. Bone-fleece hoodie with tonal stitching, a structured hood that holds its shape and a slightly cropped body so it layers cleanly over a long tee.",
    fabric: "440 GSM cotton-poly fleece, brushed interior",
    price: 7490,
    sku: "VL-HOD-002",
    featured: true,
    images: [IMG.hoodieBone, IMG.detail, IMG.atelier],
    variants: variants(fullRun([BONE, STONE])),
  },
  {
    name: "Better Days Ahead Graphic Tee",
    slug: "better-days-ahead-graphic-tee",
    category: "t-shirts",
    description:
      "Hand-drawn lettering screen printed in thick plastisol on a heavyweight black tee. Limited press run of 200 pieces — each one numbered on the inside care label.",
    fabric: "260 GSM cotton jersey, hand screen-printed",
    price: 3990,
    salePrice: 2990,
    sku: "VL-TEE-002",
    featured: true,
    newArrival: true,
    images: [IMG.teeGraphic, IMG.teeBlack, IMG.detail],
    variants: variants(fullRun([BLACK])),
  },
  {
    name: "Monolith Heavyweight Tee",
    slug: "monolith-heavyweight-tee",
    category: "t-shirts",
    description:
      "Our heaviest tee. 280 GSM slub cotton with a visible weave, side-seamed construction and a reinforced shoulder tape that keeps the neckline honest after fifty washes.",
    fabric: "280 GSM slub cotton, side-seamed, taped shoulders",
    price: 4290,
    sku: "VL-TEE-003",
    images: [IMG.teeBlack, IMG.detail, IMG.atelier],
    variants: variants(fullRun([BLACK, STONE])),
  },
  {
    name: "Atelier Fleece Hoodie",
    slug: "atelier-fleece-hoodie",
    category: "hoodies",
    description:
      "Made in the same room as our patterns. Loopback fleece, fully-fashioned seams and a woven VELOURS label stitched at the hem. The most technically complete piece we produce.",
    fabric: "500 GSM loopback fleece, fully fashioned",
    price: 8990,
    sku: "VL-HOD-003",
    featured: true,
    images: [IMG.atelier, IMG.hoodieBone, IMG.detail],
    variants: variants(fullRun([STONE, CHARCOAL, BLACK])),
  },
  {
    name: "Static Print Tee",
    slug: "static-print-tee",
    category: "t-shirts",
    description:
      "A distorted halftone print pulled across the full chest, printed wet-on-wet so the ink sits low and soft against the fabric. Boxy fit, elbow-length sleeves.",
    fabric: "240 GSM combed cotton, discharge print",
    price: 3790,
    sku: "VL-TEE-004",
    newArrival: true,
    images: [IMG.teeGraphic, IMG.detail],
    variants: variants(fullRun([BLACK, VERM])),
  },
  {
    name: "Ironside Zip Hoodie",
    slug: "ironside-zip-hoodie",
    category: "hoodies",
    description:
      "A full-zip heavyweight hoodie with a two-way YKK metal zip, storm flap and reinforced pockets. Built for cold northern roads and long nights at the studio.",
    fabric: "520 GSM bonded fleece, two-way YKK zip",
    price: 9490,
    salePrice: 7990,
    sku: "VL-HOD-004",
    images: [IMG.hoodieBlack, IMG.detail, IMG.atelier],
    variants: variants(fullRun([BLACK, CHARCOAL])),
  },
  {
    name: "Paper White Boxy Tee",
    slug: "paper-white-boxy-tee",
    category: "t-shirts",
    description:
      "Clean, sharp, and cut wide. A boxy tee in optic-white jersey with a heavy ribbed collar — designed to be worn under everything or on its own.",
    fabric: "220 GSM combed cotton, reactive dyed",
    price: 3290,
    sku: "VL-TEE-005",
    images: [IMG.teeBlack, IMG.detail],
    variants: variants(fullRun([BONE])),
  },
  {
    name: "Nightshift Heavy Hoodie",
    slug: "nightshift-heavy-hoodie",
    category: "hoodies",
    description:
      "The studio uniform. Deep black fleece with a tonal embroidered starburst on the sleeve and a hidden zip pocket inside the kangaroo for your keys and card.",
    fabric: "480 GSM brushed fleece, tonal embroidery",
    price: 7990,
    sku: "VL-HOD-005",
    featured: true,
    images: [IMG.hoodieBlack, IMG.detail, IMG.hoodieBone],
    variants: variants(fullRun([BLACK])),
  },
  {
    name: "Signal Long Sleeve Tee",
    slug: "signal-long-sleeve-tee",
    category: "t-shirts",
    description:
      "A long-sleeve layer in midweight jersey with contrast overlock stitching and a small woven tab at the cuff. Sits perfectly under a hoodie in winter.",
    fabric: "220 GSM cotton jersey, contrast overlock",
    price: 4690,
    sku: "VL-TEE-006",
    newArrival: true,
    images: [IMG.detail, IMG.teeBlack, IMG.teeGraphic],
    variants: variants(fullRun([CHARCOAL, BLACK])),
  },
  {
    name: "Concrete Grey Hoodie",
    slug: "concrete-grey-hoodie",
    category: "hoodies",
    description:
      "Dyed to the colour of board-formed concrete. A relaxed hoodie with a raw-edge hood lining, chunky drawcord tips and a washed finish that softens with every wear.",
    fabric: "460 GSM cotton fleece, pigment dyed",
    price: 8290,
    sku: "VL-HOD-006",
    images: [IMG.hoodieBone, IMG.atelier, IMG.detail],
    variants: variants(fullRun([STONE, BONE])),
  },
];

export async function ensureSeeded() {
  // The seed is idempotent and resumable: it can safely run more than once,
  // and it finishes the job if an earlier run was interrupted part-way.
  const [row] = await db.select({ n: count() }).from(products);
  if ((row?.n ?? 0) >= SEED.length) return false;

  /* ---- admin account: password comes ONLY from the environment ---- */
  const adminEmail = (process.env.ADMIN_EMAIL || "QATA@gmail.com").toLowerCase();
  const adminPassword = process.env.ADMIN_SEED_PASSWORD;
  if (!adminPassword) {
    console.warn(
      "[velours] ADMIN_SEED_PASSWORD is not set — admin account was not created. " +
        "Set it in your environment, then restart to create " +
        adminEmail
    );
  } else {
    await db
      .insert(users)
      .values({
        name: "VELOURS Admin",
        email: adminEmail,
        passwordHash: hashPassword(adminPassword),
        role: "admin",
        status: "active",
        phone: "+92 300 0000000",
        city: "Karachi",
        province: "Sindh",
        address: "Studio 4, Zamzama Lane, Clifton",
      })
      .onConflictDoNothing();
  }

  for (const p of SEED) {
    let pid: number | undefined;

    const existing = await db
      .select({ id: products.id })
      .from(products)
      .where(eq(products.slug, p.slug))
      .limit(1);

    if (existing[0]) {
      pid = existing[0].id;
    } else {
      const inserted = await db
        .insert(products)
        .values({
          name: p.name,
          slug: p.slug,
          category: p.category,
          description: p.description,
          fabric: p.fabric,
          price: p.price,
          salePrice: p.salePrice ?? null,
          sku: p.sku,
          featured: p.featured ?? false,
          newArrival: p.newArrival ?? false,
          published: true,
        })
        .onConflictDoNothing({ target: products.slug })
        .returning({ id: products.id });
      pid = inserted[0]?.id;
      if (!pid) {
        const again = await db
          .select({ id: products.id })
          .from(products)
          .where(eq(products.slug, p.slug))
          .limit(1);
        pid = again[0]?.id;
      }
    }
    if (!pid) continue;

    // Only fill children that are missing, so an interrupted run is repaired.
    const imgCount = await db
      .select({ n: count() })
      .from(productImages)
      .where(eq(productImages.productId, pid));
    if ((imgCount[0]?.n ?? 0) === 0) {
      await db.insert(productImages).values(
        p.images.map((url, i) => ({
          productId: pid!,
          url,
          alt: `${p.name} — view ${i + 1}`,
          position: i,
          isMain: i === 0,
        }))
      );
    }

    const varCount = await db
      .select({ n: count() })
      .from(productVariants)
      .where(eq(productVariants.productId, pid));
    if ((varCount[0]?.n ?? 0) === 0) {
      await db.insert(productVariants).values(
        p.variants.map((v) => ({
          productId: pid!,
          size: v.size,
          color: v.color,
          colorHex: v.hex,
          stock: v.stock,
        }))
      );
    }
  }

  await db
    .insert(settings)
    .values([
      { key: "site_tagline", value: "Wear your story." },
      { key: "shipping_flat", value: "250" },
      { key: "free_shipping_over", value: "8000" },
      { key: "support_email", value: "care@velours.pk" },
      { key: "support_phone", value: "+92 300 1234567" },
    ])
    .onConflictDoNothing();

  console.log(`[velours] seeded ${SEED.length} products`);
  return true;
}

let seedPromise: Promise<boolean> | null = null;
export function seedOnce() {
  // Never write to the database while Next.js is producing the build output —
  // seeding belongs to the running server, where it can complete atomically.
  if (process.env.NEXT_PHASE === "phase-production-build") return Promise.resolve(false);
  if (!seedPromise) seedPromise = ensureSeeded().catch((e) => {
    console.error("[velours] seed failed", e);
    return false;
  });
  return seedPromise;
}
