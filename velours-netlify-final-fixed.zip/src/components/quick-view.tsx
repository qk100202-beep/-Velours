"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { formatPKR } from "@/lib/constants";
import { useCart } from "@/components/cart-provider";
import { useToast } from "@/components/toast";
import type { CardProduct } from "@/components/product-card";

export function QuickView({ product, onClose }: { product: CardProduct; onClose: () => void }) {
  const cart = useCart();
  const toast = useToast();
  const colors = useMemo(() => product.colors.filter((c) => c.stock > 0), [product]);
  const [color, setColor] = useState(colors[0]?.name ?? "");
  const [size, setSize] = useState("");
  const [qty, setQty] = useState(1);

  const availableSizes = product.variants
    .filter((v) => v.color === color && v.stock > 0)
    .map((v) => v.size);
  const selected = product.variants.find((v) => v.color === color && v.size === size);
  const stock = selected?.stock ?? 0;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  function add() {
    if (!selected) {
      toast("Please choose an available size.", "error");
      return;
    }
    const res = cart.add({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      sku: product.sku,
      size: selected.size,
      color: selected.color,
      price: product.salePrice ?? product.price,
      image: product.images[0]?.url ?? "",
      quantity: qty,
      stock: selected.stock,
    });
    toast(res.message, res.ok ? "success" : "error");
    if (res.ok) onClose();
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[90] grid place-items-center bg-ink/60 p-4 backdrop-blur-[3px]"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.98 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          onClick={(e) => e.stopPropagation()}
          className="relative grid max-h-[90vh] w-full max-w-4xl grid-cols-1 overflow-y-auto bg-paper md:grid-cols-2"
        >
          <button
            onClick={onClose}
            aria-label="Close quick view"
            className="absolute right-3 top-3 z-10 grid h-9 w-9 place-items-center bg-paper text-ink transition hover:bg-ink hover:text-paper"
          >
            <X size={17} />
          </button>

          <div className="relative aspect-[4/5] bg-paper-2">
            <img
              src={product.images[0]?.url ?? "/images/tee-black.svg"}
              alt={product.name}
              className="h-full w-full object-cover"
            />
          </div>

          <div className="flex flex-col p-7">
            <p className="meta text-stone">{product.category}</p>
            <h2 className="display mt-2 text-[1.75rem]">{product.name}</h2>
            <div className="mt-2 flex items-baseline gap-3">
              {product.salePrice !== null ? (
                <>
                  <span className="tnum text-lg font-semibold text-verm">
                    {formatPKR(product.salePrice)}
                  </span>
                  <span className="tnum text-sm text-stone line-through">
                    {formatPKR(product.price)}
                  </span>
                </>
              ) : (
                <span className="tnum text-lg font-semibold">{formatPKR(product.price)}</span>
              )}
            </div>

            <p className="mt-4 line-clamp-4 text-sm leading-relaxed text-stone">{product.description}</p>

            {colors.length > 0 && (
              <div className="mt-6">
                <p className="label">Colour — {color}</p>
                <div className="flex flex-wrap gap-2">
                  {colors.map((c) => (
                    <button
                      key={c.name}
                      onClick={() => {
                        setColor(c.name);
                        setSize("");
                      }}
                      data-selected={color === c.name}
                      className="chip"
                      style={{ boxShadow: `inset 0 0 0 2px ${c.hex ?? "#0B0B0B"}` }}
                    >
                      {c.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-5">
              <p className="label">Size</p>
              <div className="flex flex-wrap gap-2">
                {["XS", "S", "M", "L", "XL", "XXL"].map((s) => {
                  const available = availableSizes.includes(s);
                  return (
                    <button
                      key={s}
                      disabled={!available}
                      data-selected={size === s}
                      onClick={() => setSize(s)}
                      className="chip"
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
            </div>

            <button onClick={add} disabled={!selected || stock === 0} className="btn btn-ink mt-7 w-full">
              {stock === 0 && selected ? "Out of stock" : "Add to bag"}
            </button>
            <Link
              href={`/product/${product.slug}`}
              onClick={onClose}
              className="btn btn-outline mt-2 w-full"
            >
              View full details
            </Link>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
