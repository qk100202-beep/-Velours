"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Heart, Minus, Plus, Truck, RotateCcw, ShieldCheck } from "lucide-react";
import { formatPKR } from "@/lib/constants";
import { useCart } from "@/components/cart-provider";
import { useToast } from "@/components/toast";

type Product = {
  id: number;
  name: string;
  slug: string;
  sku: string;
  price: number;
  salePrice: number | null;
  description: string;
  fabric: string | null;
  images: { id: number; url: string; alt: string | null; position: number; isMain: boolean }[];
  variants: { id: number; size: string; color: string; colorHex: string | null; stock: number }[];
  colors: { name: string; hex: string | null; stock: number }[];
  totalStock: number;
};

const SIZE_ORDER = ["XS", "S", "M", "L", "XL", "XXL"];

export function ProductBuy({ product }: { product: Product }) {
  const cart = useCart();
  const toast = useToast();
  const router = useRouter();

  const colors = useMemo(() => product.colors.filter((c) => c.stock > 0), [product]);
  const [color, setColor] = useState(colors[0]?.name ?? product.colors[0]?.name ?? "");
  const [size, setSize] = useState("");
  const [qty, setQty] = useState(1);
  const [wished, setWished] = useState(false);

  const sizesForColor = useMemo(() => {
    const map = new Map<string, number>();
    for (const v of product.variants) {
      if (v.color !== color) continue;
      map.set(v.size, (map.get(v.size) ?? 0) + v.stock);
    }
    return SIZE_ORDER.filter((s) => map.has(s)).map((s) => ({ size: s, stock: map.get(s) ?? 0 }));
  }, [product, color]);

  const selected = product.variants.find((v) => v.color === color && v.size === size);
  const stock = selected?.stock ?? 0;
  const price = product.salePrice ?? product.price;
  const onSale = product.salePrice !== null;

  function addToCart(thenCheckout = false) {
    if (!selected) {
      toast("Please select a size before adding to bag.", "error");
      return;
    }
    const res = cart.add({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      sku: product.sku,
      size: selected.size,
      color: selected.color,
      price,
      image: product.images[0]?.url ?? "",
      quantity: qty,
      stock: selected.stock,
    });
    toast(res.message, res.ok ? "success" : "error");
    if (res.ok && thenCheckout) router.push("/checkout");
  }

  return (
    <div className="flex flex-col">
      <div className="flex items-start justify-between gap-5">
        <div>
          <h1 className="display text-[clamp(2rem,5vw,3.4rem)]">{product.name}</h1>
          <p className="meta-sm tnum mt-2 text-stone">
            SKU {product.sku} · {product.totalStock > 0 ? `${product.totalStock} in stock` : "Out of stock"}
          </p>
        </div>
      </div>

      <div className="rule mt-5 flex items-baseline gap-4 pt-5">
        {onSale ? (
          <>
            <span className="tnum text-[1.85rem] font-semibold text-verm">{formatPKR(product.salePrice!)}</span>
            <span className="tnum text-lg text-stone line-through">{formatPKR(product.price)}</span>
            <span className="badge badge-sale">
              Save {Math.round(((product.price - product.salePrice!) / product.price) * 100)}%
            </span>
          </>
        ) : (
          <span className="tnum text-[1.85rem] font-semibold">{formatPKR(product.price)}</span>
        )}
      </div>

      <p className="mt-6 text-[0.98rem] leading-[1.75] text-ink/80">{product.description}</p>
      {product.fabric && <p className="meta-sm mt-3 text-stone">Fabric — {product.fabric}</p>}

      {/* colour */}
      <div className="mt-8">
        <div className="flex items-center justify-between">
          <p className="label">Colour</p>
          <p className="meta-sm text-ink">{color || "—"}</p>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {product.colors.map((c) => (
            <button
              key={c.name}
              disabled={c.stock === 0}
              data-selected={color === c.name}
              onClick={() => {
                setColor(c.name);
                setSize("");
                setQty(1);
              }}
              className="chip gap-2"
              title={c.stock === 0 ? "Out of stock" : `${c.stock} available`}
            >
              <span
                className="h-3 w-3 border border-ink/20"
                style={{ background: c.hex ?? "#0B0B0B" }}
              />
              {c.name}
            </button>
          ))}
        </div>
      </div>

      {/* size */}
      <div className="mt-7">
        <div className="flex items-center justify-between">
          <p className="label">Size</p>
          <a href="#size-guide" className="meta-sm link-underline text-stone hover:text-ink">
            Size guide
          </a>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {sizesForColor.map((s) => (
            <button
              key={s.size}
              disabled={s.stock === 0}
              data-selected={size === s.size}
              onClick={() => {
                setSize(s.size);
                setQty(1);
              }}
              className="chip"
              title={s.stock === 0 ? "Out of stock" : `${s.stock} available`}
            >
              {s.size}
            </button>
          ))}
          {sizesForColor.length === 0 && (
            <p className="text-sm text-stone">No sizes available in this colour.</p>
          )}
        </div>
        {selected && stock > 0 && stock <= 5 && (
          <p className="tnum meta-sm mt-3 text-verm">Only {stock} left — order soon</p>
        )}
        {selected && stock === 0 && <p className="meta-sm mt-3 text-stone">This size is sold out.</p>}
      </div>

      {/* quantity */}
      <div className="mt-7">
        <p className="label">Quantity</p>
        <div className="mt-3 inline-flex items-center border border-ink/20">
          <button
            onClick={() => setQty((q) => Math.max(1, q - 1))}
            className="grid h-11 w-11 place-items-center transition hover:bg-ink hover:text-paper"
            aria-label="Decrease quantity"
          >
            <Minus size={15} />
          </button>
          <span className="tnum w-12 text-center text-base">{qty}</span>
          <button
            onClick={() => setQty((q) => Math.min(stock || 1, q + 1))}
            disabled={qty >= stock}
            className="grid h-11 w-11 place-items-center transition hover:bg-ink hover:text-paper disabled:opacity-30"
            aria-label="Increase quantity"
          >
            <Plus size={15} />
          </button>
        </div>
      </div>

      {/* actions */}
      <div className="mt-8 flex flex-col gap-2.5 sm:flex-row">
        <button
          onClick={() => addToCart(false)}
          disabled={product.totalStock === 0}
          className="btn btn-outline flex-1"
        >
          Add to bag
        </button>
        <button
          onClick={() => addToCart(true)}
          disabled={product.totalStock === 0}
          className="btn btn-ink flex-1"
        >
          Buy now
        </button>
        <button
          onClick={() => {
            setWished((w) => !w);
            toast(wished ? "Removed from wishlist" : "Saved to wishlist", "success");
          }}
          aria-label="Add to wishlist"
          className="btn btn-outline px-4"
        >
          <Heart size={16} fill={wished ? "currentColor" : "none"} />
        </button>
      </div>

      {/* trust strip */}
      <div className="rule mt-8 grid gap-4 pt-6 sm:grid-cols-3">
        {[
          [Truck, "Free shipping", "On orders over Rs. 8,000"],
          [RotateCcw, "7-day returns", "Easy exchange & return"],
          [ShieldCheck, "Cash on delivery", "Available nationwide"],
        ].map(([Icon, title, sub]) => {
          const C = Icon as typeof Truck;
          return (
            <div key={title as string} className="flex items-start gap-3">
              <C size={17} className="mt-0.5 shrink-0 text-verm" />
              <div>
                <p className="meta-sm text-ink">{title as string}</p>
                <p className="mt-1 text-xs text-stone">{sub as string}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
