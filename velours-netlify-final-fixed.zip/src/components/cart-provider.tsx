"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";

export type CartLine = {
  key: string;
  productId: number;
  slug: string;
  name: string;
  sku: string;
  size: string;
  color: string;
  price: number;
  image: string;
  quantity: number;
  stock: number;
};

type CartContextValue = {
  lines: CartLine[];
  count: number;
  subtotal: number;
  shipping: number;
  total: number;
  open: boolean;
  setOpen: (v: boolean) => void;
  lastAdded: string | null;
  add: (line: Omit<CartLine, "key">) => { ok: boolean; message: string };
  update: (key: string, quantity: number) => void;
  remove: (key: string) => void;
  clear: () => void;
  hydrated: boolean;
};

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "velours_cart_v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [open, setOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [lastAdded, setLastAdded] = useState<string | null>(null);
  const first = useRef(true);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) setLines(parsed.filter((l) => l && typeof l.productId === "number"));
      }
    } catch {
      /* corrupted storage — start clean */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    if (first.current) {
      first.current = false;
    }
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      /* storage full / unavailable */
    }
  }, [lines, hydrated]);

  const add = useCallback((line: Omit<CartLine, "key">) => {
    const key = `${line.productId}-${line.size}-${line.color}`;
    let result = { ok: true, message: "Added to bag" };
    setLines((prev) => {
      const existing = prev.find((l) => l.key === key);
      const currentQty = existing?.quantity ?? 0;
      if (currentQty + line.quantity > line.stock) {
        result = {
          ok: false,
          message:
            line.stock === 0
              ? "This combination is out of stock."
              : `Only ${line.stock} left in this size & colour.`,
        };
        return prev;
      }
      if (existing) {
        return prev.map((l) => (l.key === key ? { ...l, quantity: l.quantity + line.quantity } : l));
      }
      return [...prev, { ...line, key }];
    });
    if (result.ok) {
      setLastAdded(key);
      window.setTimeout(() => setLastAdded(null), 1800);
      setOpen(true);
    }
    return result;
  }, []);

  const update = useCallback((key: string, quantity: number) => {
    setLines((prev) =>
      prev.flatMap((l) => {
        if (l.key !== key) return [l];
        if (quantity <= 0) return [];
        return [{ ...l, quantity: Math.min(quantity, l.stock) }];
      })
    );
  }, []);

  const remove = useCallback((key: string) => {
    setLines((prev) => prev.filter((l) => l.key !== key));
  }, []);

  const clear = useCallback(() => setLines([]), []);

  const value = useMemo<CartContextValue>(() => {
    const count = lines.reduce((s, l) => s + l.quantity, 0);
    const subtotal = lines.reduce((s, l) => s + l.price * l.quantity, 0);
    const shipping = subtotal === 0 || subtotal >= 8000 ? 0 : 250;
    return {
      lines,
      count,
      subtotal,
      shipping,
      total: subtotal + shipping,
      open,
      setOpen,
      lastAdded,
      add,
      update,
      remove,
      clear,
      hydrated,
    };
  }, [lines, open, lastAdded, add, update, remove, clear, hydrated]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside CartProvider");
  return ctx;
}
