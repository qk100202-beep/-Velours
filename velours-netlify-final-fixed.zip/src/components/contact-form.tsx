"use client";

import { useState, type FormEvent } from "react";
import { Loader2, Send } from "lucide-react";
import { Alert, Field } from "@/components/ui";
import { useToast } from "@/components/toast";

const SUBJECTS = [
  "Order enquiry",
  "Sizing & fit",
  "Returns & exchange",
  "Wholesale / stockist",
  "Press & collaborations",
  "Something else",
];

export function ContactForm() {
  const toast = useToast();
  const [form, setForm] = useState({ name: "", email: "", subject: SUBJECTS[0], message: "" });
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  function update(key: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Message could not be sent.");
      setSent(true);
      toast("Message sent — we will get back to you shortly", "success");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  if (sent) {
    return (
      <div className="border border-ink/18 bg-paper-2 p-8">
        <h3 className="display text-[1.65rem]">Message received</h3>
        <p className="mt-4 leading-relaxed text-stone">
          Thank you, {form.name.split(" ")[0]}. Our team reads every message and replies within 24
          hours on working days. For anything urgent, WhatsApp us on{" "}
          <span className="tnum text-ink">+92 300 1234567</span>.
        </p>
        <button
          onClick={() => {
            setSent(false);
            setForm({ name: "", email: "", subject: SUBJECTS[0], message: "" });
          }}
          className="btn btn-outline mt-7"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-7">
      {error && <Alert tone="error">{error}</Alert>}
      <div className="grid gap-7 sm:grid-cols-2">
        <Field label="Your name">
          <input
            required
            className="field"
            value={form.name}
            onChange={(e) => update("name", e.target.value)}
            placeholder="Ahmed Raza"
          />
        </Field>
        <Field label="Email address">
          <input
            required
            type="email"
            className="field"
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
            placeholder="you@email.com"
          />
        </Field>
      </div>
      <Field label="Subject">
        <select className="field" value={form.subject} onChange={(e) => update("subject", e.target.value)}>
          {SUBJECTS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </Field>
      <Field label="Message">
        <textarea
          required
          rows={6}
          className="field resize-none"
          value={form.message}
          onChange={(e) => update("message", e.target.value)}
          placeholder="Tell us what you need — include your order number if you have one."
        />
      </Field>
      <button type="submit" disabled={loading} className="btn btn-ink">
        {loading ? (
          <>
            <Loader2 size={16} className="spin" /> Sending…
          </>
        ) : (
          <>
            Send message <Send size={15} />
          </>
        )}
      </button>
    </form>
  );
}
