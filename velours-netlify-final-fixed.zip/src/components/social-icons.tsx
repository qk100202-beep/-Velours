type IconProps = { size?: number; className?: string };

export function InstagramIcon({ size = 18, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className={className} aria-hidden="true">
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none" />
    </svg>
  );
}

export function TikTokIcon({ size = 18, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M16.5 2h-2.9v13.1a2.6 2.6 0 1 1-2.2-2.57V9.5a5.7 5.7 0 1 0 5.1 5.67V8.9a6.6 6.6 0 0 0 3.9 1.25V7.2a3.75 3.75 0 0 1-3.9-3.75V2z" />
    </svg>
  );
}

export function YoutubeIcon({ size = 18, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M22.2 7.2a2.75 2.75 0 0 0-1.93-1.95C18.55 4.8 12 4.8 12 4.8s-6.55 0-8.27.45A2.75 2.75 0 0 0 1.8 7.2 28.9 28.9 0 0 0 1.35 12c0 1.62.15 3.23.45 4.8a2.75 2.75 0 0 0 1.93 1.95c1.72.45 8.27.45 8.27.45s6.55 0 8.27-.45a2.75 2.75 0 0 0 1.93-1.95c.3-1.57.45-3.18.45-4.8 0-1.62-.15-3.23-.45-4.8zM9.9 15.3V8.7l5.5 3.3-5.5 3.3z" />
    </svg>
  );
}

export function FacebookIcon({ size = 18, className = "" }: IconProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M13.5 21v-8h2.7l.4-3.1h-3.1V7.9c0-.9.25-1.5 1.55-1.5h1.65V3.63A22 22 0 0 0 14.27 3.5c-2.4 0-4.03 1.46-4.03 4.14V9.9H7.5V13h2.74v8h3.26z" />
    </svg>
  );
}

export function SocialRow({ className = "" }: { className?: string }) {
  const items = [
    [InstagramIcon, "Instagram"],
    [TikTokIcon, "TikTok"],
    [YoutubeIcon, "YouTube"],
    [FacebookIcon, "Facebook"],
  ] as const;
  return (
    <div className={`flex items-center gap-4 ${className}`}>
      {items.map(([Icon, label]) => (
        <a
          key={label}
          href="#"
          aria-label={label}
          className="grid h-9 w-9 place-items-center border border-current/20 transition-colors hover:border-verm hover:bg-verm hover:text-paper"
        >
          <Icon size={16} />
        </a>
      ))}
    </div>
  );
}
