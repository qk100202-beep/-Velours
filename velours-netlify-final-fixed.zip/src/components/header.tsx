"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Search, User, ShoppingBag, Menu, X } from "lucide-react";
import { InstagramIcon, TikTokIcon, YoutubeIcon, FacebookIcon } from "@/components/social-icons";
import { useCart } from "@/components/cart-provider";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/shop", label: "Shop" },
  { href: "/shop?category=t-shirts", label: "T-Shirts", match: "/shop" },
  { href: "/shop?category=hoodies", label: "Hoodies", match: "/shop" },
  { href: "/shop?new=1", label: "New Arrivals", match: "/shop" },
];

export function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const cart = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [user, setUser] = useState<{ name: string; role: string } | null>(null);

  useEffect(() => {
    let alive = true;
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (alive && d?.ok && d.user) setUser({ name: d.user.name, role: d.user.role });
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  function submitSearch(e: FormEvent) {
    e.preventDefault();
    const q = query.trim();
    router.push(q ? `/shop?search=${encodeURIComponent(q)}` : "/shop");
    setSearchOpen(false);
  }

  return (
    <>
      {/* marquee announcement bar */}
      <div className="overflow-hidden bg-ink text-paper">
        <div className="marquee-track py-2">
          {[0, 1].map((i) => (
            <div key={i} className="flex shrink-0 items-center">
              {[
                "Free shipping all over Pakistan",
                "Premium quality · 240–520 GSM",
                "Cash on delivery available",
                "New drop — Better Days Ahead",
                "Made in Karachi",
              ].map((t) => (
                <span key={t} className="meta-sm flex items-center gap-8 px-8 text-paper/80">
                  {t}
                  <span className="text-verm">◆</span>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      <header
        className={`sticky top-0 z-50 border-b transition-colors duration-500 ${
          scrolled ? "border-ink/12 bg-paper/95 backdrop-blur-md" : "border-transparent bg-paper"
        }`}
      >
        <div className="mx-auto flex h-[4.5rem] max-w-[1500px] items-center gap-6 px-5 md:px-9">
          <Link href="/" className="group flex items-baseline gap-2" aria-label="VELOURS home">
            <span className="display text-[1.65rem] leading-none tracking-[-0.05em] transition-colors group-hover:text-verm">
              VELOURS
            </span>
            <span className="meta-sm hidden text-stone lg:block">EST. 2021</span>
          </Link>

          <nav className="ml-4 hidden items-center gap-8 lg:flex">
            {NAV.map((item) => {
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`link-underline meta text-ink/75 transition-colors hover:text-ink ${
                    pathname === item.href ? "nav-active" : ""
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-1">
            <button
              onClick={() => setSearchOpen((v) => !v)}
              aria-label="Search products"
              className="grid h-10 w-10 place-items-center transition-colors hover:text-verm"
            >
              {searchOpen ? <X size={19} /> : <Search size={19} />}
            </button>
            <Link
              href={user ? (user.role === "admin" ? "/admin" : "/account") : "/login"}
              aria-label={user ? "Your account" : "Sign in"}
              className="grid h-10 w-10 place-items-center transition-colors hover:text-verm"
            >
              <User size={19} />
            </Link>
            <button
              onClick={() => cart.setOpen(true)}
              aria-label={`Open bag, ${cart.count} items`}
              className="relative grid h-10 w-10 place-items-center transition-colors hover:text-verm"
            >
              <ShoppingBag size={19} />
              <span className="tnum absolute right-0.5 top-0.5 grid h-[1.05rem] min-w-[1.05rem] place-items-center bg-ink px-1 text-[0.5625rem] font-semibold text-paper">
                {cart.count}
              </span>
            </button>
            <button
              onClick={() => setMobileOpen(true)}
              aria-label="Open menu"
              className="grid h-10 w-10 place-items-center lg:hidden"
            >
              <Menu size={20} />
            </button>
          </div>
        </div>

        <AnimatePresence>
          {searchOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
              className="overflow-hidden border-t border-ink/10 bg-paper-2"
            >
              <form onSubmit={submitSearch} className="mx-auto flex max-w-[1500px] items-center gap-4 px-5 py-5 md:px-9">
                <Search size={18} className="text-stone" />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search tees, hoodies, colours…"
                  className="flex-1 bg-transparent text-lg outline-none placeholder:text-stone-2"
                />
                <button type="submit" className="btn btn-ink">
                  Search
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileOpen(false)}
              className="fixed inset-0 z-[60] bg-ink/55 backdrop-blur-[2px]"
            />
            <motion.aside
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ duration: 0.42, ease: [0.22, 1, 0.36, 1] }}
              className="fixed right-0 top-0 z-[61] flex h-full w-[min(88vw,24rem)] flex-col bg-paper"
            >
              <div className="flex items-center justify-between border-b border-ink/12 px-6 py-5">
                <span className="display text-xl">VELOURS</span>
                <button onClick={() => setMobileOpen(false)} aria-label="Close menu">
                  <X size={22} />
                </button>
              </div>
              <nav className="flex flex-col px-6 py-2">
                {[
                  ["/", "Home"],
                  ["/shop", "Shop All"],
                  ["/shop?category=t-shirts", "T-Shirts"],
                  ["/shop?category=hoodies", "Hoodies"],
                  ["/shop?new=1", "New Arrivals"],
                  ["/about", "About"],
                  ["/contact", "Contact"],
                  [user ? "/account" : "/login", user ? "My Account" : "Sign In"],
                  ["/cart", "Bag"],
                ].map(([href, label], i) => (
                  <Link
                    key={href + label}
                    href={href}
                    onClick={() => setMobileOpen(false)}
                    className="display border-b border-ink/10 py-4 text-[1.6rem] transition-colors hover:text-verm"
                    style={{ transitionDelay: `${i * 15}ms` }}
                  >
                    {label}
                  </Link>
                ))}
              </nav>
              <div className="mt-auto flex items-center gap-5 border-t border-ink/12 px-6 py-6">
                {[InstagramIcon, TikTokIcon, YoutubeIcon, FacebookIcon].map((Icon, i) => (
                  <a key={i} href="#" aria-label="Social" className="text-stone transition hover:text-verm">
                    <Icon size={18} />
                  </a>
                ))}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

    </>
  );
}
