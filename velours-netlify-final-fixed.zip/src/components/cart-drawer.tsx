"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { X, Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useCart } from "@/components/cart-provider";
import { formatPKR } from "@/lib/constants";

export function CartDrawer() {
  const cart = useCart();

  return (
    <AnimatePresence>
      {cart.open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => cart.setOpen(false)}
            className="fixed inset-0 z-[80] bg-ink/55 backdrop-blur-[2px]"
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            className="fixed right-0 top-0 z-[81] flex h-full w-[min(92vw,26.5rem)] flex-col bg-paper shadow-[0_0_60px_rgba(11,11,11,0.3)]"
            aria-label="Shopping bag"
          >
            <div className="flex items-center justify-between border-b border-ink/12 px-6 py-5">
              <div>
                <h2 className="display text-xl">Your Bag</h2>
                <p className="meta-sm tnum mt-1 text-stone">
                  {cart.count} {cart.count === 1 ? "item" : "items"}
                </p>
              </div>
              <button onClick={() => cart.setOpen(false)} aria-label="Close bag" className="p-1">
                <X size={22} />
              </button>
            </div>

            {cart.lines.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-5 px-8 text-center">
                <ShoppingBag size={38} className="text-stone-2" />
                <p className="text-stone">Your bag is empty.</p>
                <Link href="/shop" onClick={() => cart.setOpen(false)} className="btn btn-ink">
                  Start shopping
                </Link>
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto px-6">
                  {cart.lines.map((line) => (
                    <div key={line.key} className="flex gap-4 border-b border-ink/10 py-5">
                      <Link href={`/product/${line.slug}`} onClick={() => cart.setOpen(false)}>
                        <img
                          src={line.image}
                          alt={line.name}
                          className="h-[6.25rem] w-[5rem] object-cover"
                          loading="lazy"
                        />
                      </Link>
                      <div className="flex min-w-0 flex-1 flex-col">
                        <div className="flex items-start justify-between gap-3">
                          <p className="truncate text-sm font-medium">{line.name}</p>
                          <button
                            onClick={() => cart.remove(line.key)}
                            aria-label={`Remove ${line.name}`}
                            className="text-stone transition hover:text-verm"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                        <p className="meta-sm mt-1 text-stone">
                          {line.size} / {line.color}
                        </p>
                        <div className="mt-auto flex items-center justify-between gap-3 pt-3">
                          <div className="flex items-center border border-ink/15">
                            <button
                              onClick={() => cart.update(line.key, line.quantity - 1)}
                              className="grid h-8 w-8 place-items-center transition hover:bg-ink hover:text-paper"
                              aria-label="Decrease quantity"
                            >
                              <Minus size={13} />
                            </button>
                            <span className="tnum w-8 text-center text-sm">{line.quantity}</span>
                            <button
                              onClick={() => cart.update(line.key, line.quantity + 1)}
                              disabled={line.quantity >= line.stock}
                              className="grid h-8 w-8 place-items-center transition hover:bg-ink hover:text-paper disabled:opacity-30"
                              aria-label="Increase quantity"
                            >
                              <Plus size={13} />
                            </button>
                          </div>
                          <p className="tnum text-sm font-semibold">
                            {formatPKR(line.price * line.quantity)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t border-ink/12 px-6 py-5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-stone">Subtotal</span>
                    <span className="tnum font-semibold">{formatPKR(cart.subtotal)}</span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-sm">
                    <span className="text-stone">Shipping</span>
                    <span className="tnum">
                      {cart.shipping === 0 ? "Free" : formatPKR(cart.shipping)}
                    </span>
                  </div>
                  <div className="rule mt-4 flex items-center justify-between pt-4">
                    <span className="meta">Total</span>
                    <span className="tnum text-lg font-semibold">{formatPKR(cart.total)}</span>
                  </div>
                  <Link
                    href="/checkout"
                    onClick={() => cart.setOpen(false)}
                    className="btn btn-ink mt-4 w-full"
                  >
                    Checkout
                  </Link>
                  <Link
                    href="/cart"
                    onClick={() => cart.setOpen(false)}
                    className="btn btn-outline mt-2 w-full"
                  >
                    View bag
                  </Link>
                </div>
              </>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
