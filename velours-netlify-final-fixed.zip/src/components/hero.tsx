"use client";

import Link from "next/link";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight } from "lucide-react";

const WORDS = ["WEAR", "YOUR", "STORY"];

export function Hero() {
  const reduce = useReducedMotion();

  return (
    <section className="relative overflow-hidden bg-ink text-paper">
      {/* photograph */}
      <div className="absolute inset-0">
        <motion.img
          src="/images/hero.svg"
          alt="VELOURS campaign — oversized black hoodie against board-formed concrete"
          initial={reduce ? {} : { scale: 1.12, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
          className="h-full w-full object-cover object-[62%_center]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/78 to-ink/10" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-ink/25" />
      </div>

      <div className="relative mx-auto flex min-h-[82vh] max-w-[1500px] flex-col justify-center px-5 py-20 md:px-9 lg:min-h-[88vh]">
        <motion.p
          initial={reduce ? {} : { opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15 }}
          className="meta text-paper/70"
        >
          VELOURS <span className="mx-2 text-verm">◆</span> Premium Streetwear Pakistan
        </motion.p>

        <h1 className="display mt-6 max-w-[16ch] text-[clamp(3.15rem,11.5vw,9.25rem)]">
          {WORDS.map((word, i) => (
            <span key={word} className="block overflow-hidden">
              <motion.span
                className="block"
                initial={reduce ? {} : { y: "108%" }}
                animate={{ y: 0 }}
                transition={{ duration: 0.95, delay: 0.22 + i * 0.13, ease: [0.22, 1, 0.36, 1] }}
              >
                {i === 2 ? <span className="text-stone-2">{word}</span> : word}
              </motion.span>
            </span>
          ))}
        </h1>

        <motion.p
          initial={reduce ? {} : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.72 }}
          className="mt-7 max-w-md text-[1.02rem] leading-relaxed text-paper/78"
        >
          Premium T-shirts &amp; hoodies for the next generation. Heavyweight fabric, honest
          construction, cut and sewn in Karachi — streetwear built for dreamers, creators and
          go-getters.
        </motion.p>

        <motion.div
          initial={reduce ? {} : { opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.86 }}
          className="mt-9 flex flex-wrap items-center gap-3"
        >
          <Link href="/shop" className="btn btn-paper">
            Shop now <ArrowRight size={15} />
          </Link>
          <Link href="/shop?new=1" className="btn btn-outline-paper">
            Explore collection
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.05 }}
          className="mt-14 flex items-center gap-3"
        >
          <span className="h-px w-16 bg-paper/60" />
          <span className="h-px w-6 bg-paper/35" />
          <span className="h-px w-6 bg-paper/35" />
        </motion.div>
      </div>

      {/* pinned index mark on the right edge */}
      <div className="pointer-events-none absolute right-6 top-1/2 hidden -translate-y-1/2 items-center gap-5 lg:flex">
        <div className="flex flex-col items-center gap-4">
          <span className="meta-sm rail-vertical tracking-[0.32em] text-paper/70">
            Premium Streetwear Pakistan
          </span>
          <span className="h-16 w-px bg-paper/40" />
          <span className="text-verm text-xs">★</span>
        </div>
      </div>
    </section>
  );
}

export function MarqueeBand({ items }: { items: string[] }) {
  return (
    <div className="overflow-hidden border-y border-ink/12 bg-paper-2 py-4">
      <div className="marquee-track">
        {[0, 1].map((k) => (
          <div key={k} className="flex shrink-0 items-center">
            {items.map((t) => (
              <span key={t} className="display flex items-center gap-8 px-8 text-[1.55rem] text-ink/80">
                {t}
                <span className="text-verm text-sm">◆</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
