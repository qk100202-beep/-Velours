import Link from "next/link";
import { SocialRow } from "@/components/social-icons";

const COLUMNS: { title: string; links: [string, string][] }[] = [
  {
    title: "Shop",
    links: [
      ["/shop", "All Products"],
      ["/shop?category=t-shirts", "T-Shirts"],
      ["/shop?category=hoodies", "Hoodies"],
      ["/shop?new=1", "New Arrivals"],
      ["/shop?sort=popular", "Best Sellers"],
    ],
  },
  {
    title: "Company",
    links: [
      ["/about", "About VELOURS"],
      ["/contact", "Contact"],
      ["/track", "Track Order"],
      ["/account", "My Account"],
      ["/account/orders", "Order History"],
    ],
  },
  {
    title: "Support",
    links: [
      ["/p/shipping", "Shipping Policy"],
      ["/p/returns", "Return Policy"],
      ["/p/privacy", "Privacy Policy"],
      ["/p/terms", "Terms & Conditions"],
      ["/login", "Sign In"],
    ],
  },
];

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-ink text-paper">
      <div className="mx-auto max-w-[1500px] px-5 md:px-9">
        <div className="grid gap-12 py-16 lg:grid-cols-[1.4fr_1fr_1fr_1fr] lg:py-20">
          <div>
            <Link href="/" className="display inline-block text-[2.6rem] leading-none">
              VELOURS
            </Link>
            <p className="serif-voice mt-5 max-w-xs text-[1.35rem] leading-snug text-paper/85">
              Wear your story.
            </p>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-stone-2">
              Premium heavyweight T-shirts and hoodies, cut and sewn in Karachi for the next
              generation. Free shipping all over Pakistan.
            </p>
            <form
              className="mt-8 max-w-sm"
              action="/api/subscribe"
              method="post"
            >
              <label className="label text-stone-2" htmlFor="footer-email">
                Join the drop list
              </label>
              <div className="flex items-center gap-3 border-b border-paper/25">
                <input
                  id="footer-email"
                  name="email"
                  type="email"
                  required
                  placeholder="you@email.com"
                  className="field field-dark flex-1"
                />
                <button type="submit" className="btn btn-outline-paper mb-1 px-4 py-2">
                  Join
                </button>
              </div>
            </form>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h3 className="meta text-stone-2">{col.title}</h3>
              <ul className="mt-5 space-y-3">
                {col.links.map(([href, label]) => (
                  <li key={href + label}>
                    <Link
                      href={href}
                      className="link-underline text-[0.95rem] text-paper/80 transition-colors hover:text-paper"
                    >
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="rule-light flex flex-col gap-6 py-8 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap items-center gap-x-8 gap-y-3 text-[0.78rem] text-stone-2">
            <span className="tnum">© {new Date().getFullYear()} VELOURS (Pvt) Ltd.</span>
            <span>Karachi · Lahore · Islamabad</span>
            <a href="mailto:care@velours.pk" className="link-underline hover:text-paper">
              care@velours.pk
            </a>
            <a href="tel:+923001234567" className="tnum link-underline hover:text-paper">
              +92 300 1234567
            </a>
          </div>
          <SocialRow className="text-paper/70" />
        </div>

        <div className="pb-10">
          <p className="display select-none text-[clamp(2.5rem,13vw,11rem)] leading-[0.8] text-paper/8">
            VELOURS
          </p>
        </div>
      </div>
    </footer>
  );
}
