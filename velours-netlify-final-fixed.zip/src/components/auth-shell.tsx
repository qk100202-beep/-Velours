"use client";

import Link from "next/link";
import type { ReactNode } from "react";

export function AuthShell({
  eyebrow,
  title,
  subtitle,
  children,
  footer,
  image = "/images/hoodie-black-worn.svg",
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  children: ReactNode;
  footer?: ReactNode;
  image?: string;
}) {
  return (
    <div className="grid min-h-[calc(100vh-4.5rem)] lg:grid-cols-2">
      {/* form side */}
      <div className="flex flex-col justify-center px-5 py-14 md:px-12 lg:px-16">
        <div className="mx-auto w-full max-w-md">
          <p className="meta text-stone">{eyebrow}</p>
          <h1 className="display mt-4 text-[clamp(2.35rem,6vw,3.65rem)]">{title}</h1>
          <p className="serif-voice mt-3 text-[1.2rem] text-stone">{subtitle}</p>
          <div className="mt-9">{children}</div>
          {footer && <div className="mt-8 border-t border-ink/12 pt-6">{footer}</div>}
        </div>
      </div>

      {/* image side */}
      <div className="relative hidden overflow-hidden bg-ink lg:block">
        <img src={image} alt="" aria-hidden="true" className="h-full w-full object-cover opacity-75" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-12">
          <p className="display text-[clamp(2rem,3.6vw,3.35rem)] text-paper leading-[0.92]">
            Wear your
            <br />
            story.
          </p>
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-paper/70">
            Premium heavyweight T-shirts and hoodies, cut and sewn in Karachi for the next
            generation.
          </p>
          <div className="mt-8 flex items-center gap-3">
            <span className="h-px w-14 bg-paper/60" />
            <Link href="/shop" className="meta link-underline text-paper hover:text-verm">
              Browse the collection →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
