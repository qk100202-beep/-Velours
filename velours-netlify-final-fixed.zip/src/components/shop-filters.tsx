"use client";

import { useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { SlidersHorizontal, X } from "lucide-react";
import { COLORS, SIZES, formatPKR } from "@/lib/constants";

const SORTS = [
  ["newest", "Newest"],
  ["popular", "Best selling"],
  ["price-asc", "Price: low to high"],
  ["price-desc", "Price: high to low"],
  ["name", "Alphabetical"],
];

export function ShopFilters({ total }: { total: number }) {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const [open, setOpen] = useState(false);

  function set(key: string, value: string | null) {
    const next = new URLSearchParams(params.toString());
    if (value === null || value === "" || next.get(key) === value) next.delete(key);
    else next.set(key, value);
    router.push(`${pathname}?${next.toString()}`, { scroll: false });
  }

  function clearAll() {
    router.push(pathname, { scroll: false });
  }

  const category = params.get("category");
  const size = params.get("size");
  const color = params.get("color");
  const sort = params.get("sort") ?? "newest";
  const min = params.get("min");
  const max = params.get("max");
  const activeCount =
    ["category", "size", "color", "min", "max", "new", "featured", "search"].filter((k) =>
      params.get(k)
    ).length;

  const panel = (
    <div className="flex flex-col gap-8">
      {/* category */}
      <div>
        <p className="label border-b border-ink/12 pb-2">Category</p>
        <div className="mt-3 flex flex-col gap-2.5">
          {[["", "All Products"], ["t-shirts", "T-Shirts"], ["hoodies", "Hoodies"]].map(
            ([value, label]) => (
              <button
                key={label}
                onClick={() => set("category", value || null)}
                className={`flex items-center gap-3 text-left text-sm transition-colors ${
                  (category ?? "") === value ? "text-verm" : "text-ink/80 hover:text-ink"
                }`}
              >
                <span
                  className={`h-2.5 w-2.5 border ${
                    (category ?? "") === value ? "border-verm bg-verm" : "border-ink/30"
                  }`}
                />
                {label}
              </button>
            )
          )}
        </div>
      </div>

      {/* price */}
      <div>
        <p className="label border-b border-ink/12 pb-2">Price (PKR)</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {[
            [null, null, "All"],
            [null, 4000, "Under 4,000"],
            [4000, 7000, "4,000 – 7,000"],
            [7000, null, "Above 7,000"],
          ].map(([lo, hi, label]) => {
            const selected = (min ?? null) === (lo ? String(lo) : null) && (max ?? null) === (hi ? String(hi) : null);
            return (
              <button
                key={label as string}
                onClick={() => {
                  const next = new URLSearchParams(params.toString());
                  if (lo) next.set("min", String(lo));
                  else next.delete("min");
                  if (hi) next.set("max", String(hi));
                  else next.delete("max");
                  router.push(`${pathname}?${next.toString()}`, { scroll: false });
                }}
                data-selected={selected}
                className="chip"
              >
                {label as string}
              </button>
            );
          })}
        </div>
        <div className="mt-3 flex items-center gap-2">
          <input
            type="number"
            inputMode="numeric"
            placeholder={min ?? "Min"}
            defaultValue={min ?? ""}
            onBlur={(e) => set("min", e.target.value || null)}
            className="field tnum py-1.5 text-sm"
          />
          <span className="text-stone">—</span>
          <input
            type="number"
            inputMode="numeric"
            placeholder={max ?? "Max"}
            defaultValue={max ?? ""}
            onBlur={(e) => set("max", e.target.value || null)}
            className="field tnum py-1.5 text-sm"
          />
        </div>
        {min && max && (
          <p className="meta-sm tnum mt-2 text-stone">
            {formatPKR(Number(min))} – {formatPKR(Number(max))}
          </p>
        )}
      </div>

      {/* size */}
      <div>
        <p className="label border-b border-ink/12 pb-2">Size</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {SIZES.map((s) => (
            <button key={s} onClick={() => set("size", s)} data-selected={size === s} className="chip">
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* colour */}
      <div>
        <p className="label border-b border-ink/12 pb-2">Colour</p>
        <div className="mt-3 flex flex-col gap-2.5">
          {COLORS.map((c) => (
            <button
              key={c.name}
              onClick={() => set("color", c.name)}
              className={`flex items-center gap-3 text-left text-sm transition-colors ${
                color === c.name ? "text-verm" : "text-ink/80 hover:text-ink"
              }`}
            >
              <span
                className="h-3.5 w-3.5 border border-ink/25"
                style={{ background: c.hex }}
              />
              {c.name}
            </button>
          ))}
        </div>
      </div>

      {/* badges */}
      <div>
        <p className="label border-b border-ink/12 pb-2">Collections</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            onClick={() => set("new", "1")}
            data-selected={params.get("new") === "1"}
            className="chip"
          >
            New arrivals
          </button>
          <button
            onClick={() => set("featured", "1")}
            data-selected={params.get("featured") === "1"}
            className="chip"
          >
            Featured
          </button>
        </div>
      </div>

      {activeCount > 0 && (
        <button onClick={clearAll} className="btn btn-outline w-full">
          Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <>
      {/* mobile trigger */}
      <div className="flex items-center justify-between gap-4 lg:hidden">
        <button onClick={() => setOpen(true)} className="btn btn-outline flex-1">
          <SlidersHorizontal size={15} /> Filters {activeCount > 0 && `(${activeCount})`}
        </button>
        <select
          value={sort}
          onChange={(e) => set("sort", e.target.value)}
          className="field w-auto flex-1 py-2.5"
          aria-label="Sort products"
        >
          {SORTS.map(([v, l]) => (
            <option key={v} value={v}>
              {l}
            </option>
          ))}
        </select>
      </div>

      {open && (
        <div className="fixed inset-0 z-[85] lg:hidden">
          <div className="absolute inset-0 bg-ink/55" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-[min(86vw,22rem)] overflow-y-auto bg-paper px-6 py-6">
            <div className="mb-7 flex items-center justify-between">
              <h2 className="display text-xl">Filters</h2>
              <button onClick={() => setOpen(false)} aria-label="Close filters">
                <X size={20} />
              </button>
            </div>
            {panel}
            <button onClick={() => setOpen(false)} className="btn btn-ink mt-8 w-full">
              Show {total} results
            </button>
          </div>
        </div>
      )}

      <aside className="hidden lg:block">{panel}</aside>
    </>
  );
}

export function SortSelect() {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();
  const sort = params.get("sort") ?? "newest";
  return (
    <select
      value={sort}
      onChange={(e) => {
        const next = new URLSearchParams(params.toString());
        if (e.target.value === "newest") next.delete("sort");
        else next.set("sort", e.target.value);
        router.push(`${pathname}?${next.toString()}`, { scroll: false });
      }}
      className="field w-auto py-2"
      aria-label="Sort products"
    >
      {SORTS.map(([v, l]) => (
        <option key={v} value={v}>
          {l}
        </option>
      ))}
    </select>
  );
}
