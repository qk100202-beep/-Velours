import Link from "next/link";
import { listProducts, type ProductQuery } from "@/lib/data";
import { ProductCard } from "@/components/product-card";
import { ShopFilters, SortSelect } from "@/components/shop-filters";
import { EmptyState, SectionHead } from "@/components/ui";
import { StaggerGroup, StaggerItem } from "@/components/reveal";
import { SearchX } from "lucide-react";

export type ShopQuery = {
  category?: string;
  search?: string;
  size?: string;
  color?: string;
  min?: string;
  max?: string;
  new?: string;
  featured?: string;
  sort?: string;
};

export async function ShopView({
  query,
  eyebrow,
  title,
  description,
}: {
  query: ShopQuery;
  eyebrow: string;
  title: string;
  description: string;
}) {
  const params: ProductQuery = {
    category: query.category || undefined,
    search: query.search || undefined,
    size: query.size || undefined,
    color: query.color || undefined,
    minPrice: query.min ? Number(query.min) : undefined,
    maxPrice: query.max ? Number(query.max) : undefined,
    newArrival: query.new === "1" ? true : query.category === undefined && title === "New Arrivals" ? true : undefined,
    featured: query.featured === "1" ? true : undefined,
    sort: (query.sort as ProductQuery["sort"]) ?? "newest",
  };

  const products = await listProducts(params);
  const activeFilters = [
    query.search && `“${query.search}”`,
    query.category,
    query.size && `Size ${query.size}`,
    query.color,
    query.min && `from Rs. ${query.min}`,
    query.max && `to Rs. ${query.max}`,
    query.new === "1" && "New arrivals",
    query.featured === "1" && "Featured",
  ].filter(Boolean) as string[];

  return (
    <>
      <header className="border-b border-ink/12">
        <div className="mx-auto max-w-[1500px] px-5 pb-10 pt-12 md:px-9 md:pb-14 md:pt-16">
          <p className="meta text-stone">{eyebrow}</p>
          <h1 className="display mt-4 text-[clamp(2.6rem,8vw,5.75rem)]">{title}</h1>
          <p className="mt-5 max-w-xl text-[1.02rem] leading-relaxed text-stone">{description}</p>
        </div>
      </header>

      <div className="mx-auto max-w-[1500px] gap-10 px-5 py-10 md:px-9 lg:flex lg:py-14">
        <div className="lg:w-[15.5rem] lg:shrink-0">
          <ShopFilters total={products.length} />
        </div>

        <div className="mt-8 min-w-0 flex-1 lg:mt-0">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-ink/12 pb-4">
            <div className="flex flex-wrap items-center gap-2">
              <p className="meta-sm tnum text-stone">
                {products.length} {products.length === 1 ? "piece" : "pieces"}
              </p>
              {activeFilters.map((f) => (
                <span key={f} className="meta-sm border border-ink/15 bg-paper-2 px-2.5 py-1 text-ink">
                  {f}
                </span>
              ))}
            </div>
            <div className="hidden lg:block">
              <SortSelect />
            </div>
          </div>

          {products.length === 0 ? (
            <EmptyState
              icon={<SearchX size={34} />}
              title="Nothing matches those filters"
              description="Try widening the price range, clearing the colour or size, or searching for something else."
              action={
                <Link href="/shop" className="btn btn-ink mt-2">
                  Reset filters
                </Link>
              }
            />
          ) : (
            <StaggerGroup className="mt-9 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 xl:grid-cols-4">
              {products.map((p, i) => (
                <StaggerItem key={p.id}>
                  <ProductCard product={p} priority={i < 4} />
                </StaggerItem>
              ))}
            </StaggerGroup>
          )}

          {products.length > 0 && (
            <div className="rule mt-16 flex flex-col items-center gap-4 pt-10 text-center">
              <SectionHead title="Complete the Look" count="Pair it" />
              <p className="serif-voice max-w-lg text-[1.25rem] text-stone">
                Every VELOURS piece is cut to layer — a heavyweight tee under a fleece hoodie is the
                whole idea.
              </p>
              <div className="mt-2 flex flex-wrap justify-center gap-3">
                <Link href="/shop?category=t-shirts" className="btn btn-outline">
                  Shop T-Shirts
                </Link>
                <Link href="/shop?category=hoodies" className="btn btn-outline">
                  Shop Hoodies
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
