"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, X, ZoomIn, Expand } from "lucide-react";

type Image = { id: number; url: string; alt: string | null; position: number; isMain: boolean };

export function ProductGallery({ images, name }: { images: Image[]; name: string }) {
  const [index, setIndex] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [zoom, setZoom] = useState<{ x: number; y: number } | null>(null);
  const touchStart = useRef<number | null>(null);

  const list = images.length ? images : [{ id: 0, url: "/images/tee-black.svg", alt: name, position: 0, isMain: true }];
  const current = list[Math.min(index, list.length - 1)];

  const go = useCallback(
    (dir: number) => setIndex((i) => (i + dir + list.length) % list.length),
    [list.length]
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
      if (e.key === "Escape") setFullscreen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go]);

  function onMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    const rect = e.currentTarget.getBoundingClientRect();
    setZoom({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  }

  return (
    <div>
      {/* main stage */}
      <div
        className="zoom-lens relative aspect-[4/5] overflow-hidden bg-paper-2"
        onMouseMove={onMouseMove}
        onMouseLeave={() => setZoom(null)}
        onTouchStart={(e) => (touchStart.current = e.touches[0].clientX)}
        onTouchEnd={(e) => {
          if (touchStart.current === null) return;
          const delta = e.changedTouches[0].clientX - touchStart.current;
          if (Math.abs(delta) > 45) go(delta < 0 ? 1 : -1);
          touchStart.current = null;
        }}
      >
        <AnimatePresence mode="wait">
          <motion.img
            key={current.url + index}
            src={current.url}
            alt={current.alt ?? name}
            initial={{ opacity: 0, scale: 1.03 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="h-full w-full object-cover"
            style={
              zoom
                ? { transform: "scale(1.9)", transformOrigin: `${zoom.x}% ${zoom.y}%` }
                : undefined
            }
          />
        </AnimatePresence>

        {list.length > 1 && (
          <>
            <button
              onClick={() => go(-1)}
              aria-label="Previous image"
              className="absolute left-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center bg-paper/85 text-ink transition hover:bg-ink hover:text-paper"
            >
              <ChevronLeft size={19} />
            </button>
            <button
              onClick={() => go(1)}
              aria-label="Next image"
              className="absolute right-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center bg-paper/85 text-ink transition hover:bg-ink hover:text-paper"
            >
              <ChevronRight size={19} />
            </button>
          </>
        )}

        <button
          onClick={() => setFullscreen(true)}
          aria-label="View fullscreen"
          className="absolute bottom-3 right-3 flex items-center gap-2 bg-paper/85 px-3 py-2 text-ink transition hover:bg-ink hover:text-paper"
        >
          <Expand size={14} />
          <span className="meta-sm">Full view</span>
        </button>

        <div className="pointer-events-none absolute bottom-3 left-3 flex items-center gap-2 bg-paper/85 px-3 py-2">
          <ZoomIn size={13} />
          <span className="meta-sm tnum">
            {String(index + 1).padStart(2, "0")} / {String(list.length).padStart(2, "0")}
          </span>
        </div>
      </div>

      {/* thumbnails */}
      {list.length > 1 && (
        <div className="hide-scrollbar mt-3 flex gap-2 overflow-x-auto">
          {list.map((img, i) => (
            <button
              key={img.id + i}
              onClick={() => setIndex(i)}
              aria-label={`View image ${i + 1}`}
              className={`relative h-[5.5rem] w-[4.4rem] shrink-0 overflow-hidden border transition-all duration-300 ${
                i === index ? "border-ink opacity-100" : "border-ink/12 opacity-60 hover:opacity-100"
              }`}
            >
              <img src={img.url} alt="" className="h-full w-full object-cover" loading="lazy" />
            </button>
          ))}
        </div>
      )}

      {/* fullscreen viewer */}
      <AnimatePresence>
        {fullscreen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[95] flex flex-col bg-ink"
          >
            <div className="flex items-center justify-between px-5 py-4 text-paper">
              <span className="meta-sm tnum">
                {String(index + 1).padStart(2, "0")} / {String(list.length).padStart(2, "0")}
              </span>
              <button onClick={() => setFullscreen(false)} aria-label="Close fullscreen" className="p-1">
                <X size={24} />
              </button>
            </div>
            <div className="relative flex flex-1 items-center justify-center px-4 pb-8">
              <button
                onClick={() => go(-1)}
                aria-label="Previous"
                className="absolute left-3 grid h-12 w-12 place-items-center text-paper transition hover:text-verm"
              >
                <ChevronLeft size={28} />
              </button>
              <motion.img
                key={current.url}
                src={current.url}
                alt={current.alt ?? name}
                initial={{ opacity: 0, scale: 1.02 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="max-h-full max-w-full object-contain"
              />
              <button
                onClick={() => go(1)}
                aria-label="Next"
                className="absolute right-3 grid h-12 w-12 place-items-center text-paper transition hover:text-verm"
              >
                <ChevronRight size={28} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
