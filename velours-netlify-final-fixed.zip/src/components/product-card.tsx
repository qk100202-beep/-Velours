"use client";

import Link from "next/link";
import { useState } from "react";
import { Heart, Eye, Plus } from "lucide-react";
import { formatPKR } from "@/lib/constants";
import { useCart } from "@/components/cart-provider";
import { useToast } from "@/components/toast";
import { QuickView } from "@/components/quick-view";

export type CardProduct = {
  id: number;
  name: string;
  slug: string;
  category: string;
  price: number;
  salePrice: number | null;
  sku: string;
  featured: boolean;
  newArrival: boolean;
  images: { id: number; url: string; alt: string | null; position: number; isMain: boolean }[];
  variants: { id: number; size: string; color: string; colorHex: string | null; stock: number }[];
  totalStock: number;
  colors: { name: string; hex: string | null; stock: number }[];
  sizes: string[];
  minPrice: number;
  description: string;
};

export function ProductCard({ product, priority }: { product: CardProduct; priority?: boolean }) {
  const cart = useCart();
  const toast = useToast();
  const [wished, setWished] = useState(false);
  const [quick, setQuick] = useState(false);
  const [hover, setHover] = useState(false);

  const front = product.images[0]?.url ?? "/images/tee-black.svg";
  const back = product.images[1]?.url ?? front;
  const onSale = product.salePrice !== null;
  const out = product.totalStock === 0;

  function quickAdd() {
    const variant = product.variants.find((v) => v.stock > 0);
    if (!variant) {
      toast("This piece is currently out of stock.", "error");
      return;
    }
    const res = cart.add({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      sku: product.sku,
      size: variant.size,
      color: variant.color,
      price: product.salePrice ?? product.price,
      image: front,
      quantity: 1,
      stock: variant.stock,
    });
    toast(res.message, res.ok ? "success" : "error");
  }

  return (
    <>
      <article
        className="pcard group"
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      >
        <Link href={`/product/${product.slug}`} className="block">
          <div className="pcard-img">
            <img
              src={front}
              alt={product.images[0]?.alt ?? product.name}
              loading={priority ? "eager" : "lazy"}
              className="primary"
              width={720}
              height={900}
            />
            <img
              src={back}
              alt=""
              aria-hidden="true"
              loading="lazy"
              className="secondary"
              width={720}
              height={900}
            />

            <div className="absolute left-0 top-0 flex flex-col items-start gap-1.5 p-3">
              {product.newArrival && <span className="badge badge-new">New</span>}
              {onSale && <span className="badge badge-sale">Sale</span>}
              {product.featured && !onSale && <span className="badge badge-featured">Featured</span>}
              {out && <span className="badge badge-out">Sold out</span>}
            </div>

            <div
              className={`absolute right-3 top-3 flex flex-col gap-2 transition-all duration-300 ${
                hover ? "translate-x-0 opacity-100" : "translate-x-3 opacity-0"
              }`}
            >
              <button
                type="button"
                aria-label="Add to wishlist"
                onClick={(e) => {
                  e.preventDefault();
                  setWished((w) => !w);
                  toast(wished ? "Removed from wishlist" : "Saved to wishlist", "success");
                }}
                className="grid h-9 w-9 place-items-center bg-paper text-ink transition-colors hover:bg-ink hover:text-paper"
              >
                <Heart size={15} fill={wished ? "currentColor" : "none"} />
              </button>
              <button
                type="button"
                aria-label="Quick view"
                onClick={(e) => {
                  e.preventDefault();
                  setQuick(true);
                }}
                className="grid h-9 w-9 place-items-center bg-paper text-ink transition-colors hover:bg-ink hover:text-paper"
              >
                <Eye size={15} />
              </button>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                quickAdd();
              }}
              disabled={out}
              className={`absolute inset-x-0 bottom-0 flex items-center justify-center gap-2 bg-ink/92 py-3.5 text-paper transition-all duration-400 ${
                hover && !out ? "translate-y-0 opacity-100" : "translate-y-full opacity-0"
              }`}
            >
              <Plus size={14} />
              <span className="meta-sm">{out ? "Sold out" : "Add to bag"}</span>
            </button>
          </div>
        </Link>

        <div className="rule mt-3 flex items-start justify-between gap-4 pt-3">
          <div className="min-w-0">
            <Link href={`/product/${product.slug}`} className="block">
              <h3 className="truncate text-[0.95rem] font-medium leading-snug transition-colors group-hover:text-verm">
                {product.name}
              </h3>
            </Link>
            <div className="mt-1.5 flex items-center gap-1.5">
              {product.colors
                .filter((c) => c.stock > 0)
                .slice(0, 5)
                .map((c) => (
                  <span
                    key={c.name}
                    title={c.name}
                    className="h-2.5 w-2.5 border border-ink/15"
                    style={{ background: c.hex ?? "#0B0B0B" }}
                  />
                ))}
              <span className="meta-sm ml-2 text-stone">
                {product.sizes.length ? product.sizes.join(" · ") : "—"}
              </span>
            </div>
          </div>
          <div className="shrink-0 text-right">
            {onSale ? (
              <>
                <p className="tnum text-[0.95rem] font-semibold text-verm">{formatPKR(product.salePrice!)}</p>
                <p className="tnum text-[0.75rem] text-stone line-through">{formatPKR(product.price)}</p>
              </>
            ) : (
              <p className="tnum text-[0.95rem] font-semibold">{formatPKR(product.price)}</p>
            )}
          </div>
        </div>
      </article>

      {quick && <QuickView product={product} onClose={() => setQuick(false)} />}
    </>
  );
}
