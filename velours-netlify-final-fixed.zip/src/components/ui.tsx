import Link from "next/link";
import type { ReactNode } from "react";

export function SectionHead({
  eyebrow,
  title,
  count,
  href,
  hrefLabel = "View all",
  light = false,
}: {
  eyebrow?: string;
  title: string;
  count?: string;
  href?: string;
  hrefLabel?: string;
  light?: boolean;
}) {
  return (
    <div>
      {eyebrow && (
        <p className={`meta mb-2 ${light ? "text-stone-2" : "text-stone"}`}>{eyebrow}</p>
      )}
      <div className={`section-head ${light ? "rule-light" : "rule-heavy"}`}>
        <h2 className={`display text-[clamp(1.75rem,4.4vw,3.15rem)] ${light ? "text-paper" : "text-ink"}`}>
          {title}
        </h2>
        <div className="flex items-center gap-5 pb-1.5">
          {count && (
            <span className={`meta-sm tnum ${light ? "text-stone-2" : "text-stone"}`}>{count}</span>
          )}
          {href && (
            <Link
              href={href}
              className={`link-underline meta whitespace-nowrap ${
                light ? "text-paper hover:text-verm" : "text-ink hover:text-verm"
              }`}
            >
              {hrefLabel} →
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}

export function PageHero({
  eyebrow,
  title,
  description,
  image,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  image?: string;
}) {
  return (
    <section className="relative overflow-hidden bg-ink text-paper">
      {image && (
        <div className="absolute inset-0">
          <img src={image} alt="" aria-hidden="true" className="h-full w-full object-cover opacity-45" />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-ink/35" />
        </div>
      )}
      <div className="relative mx-auto max-w-[1500px] px-5 py-16 md:px-9 md:py-24">
        <p className="meta text-stone-2">{eyebrow}</p>
        <h1 className="display mt-4 max-w-4xl text-[clamp(2.6rem,8vw,6.5rem)]">{title}</h1>
        {description && (
          <p className="mt-6 max-w-xl text-[1.02rem] leading-relaxed text-paper/75">{description}</p>
        )}
      </div>
    </section>
  );
}

export function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav className="meta-sm flex flex-wrap items-center gap-2 text-stone">
      {items.map((item, i) => (
        <span key={item.label} className="flex items-center gap-2">
          {item.href ? (
            <Link href={item.href} className="link-underline transition hover:text-ink">
              {item.label}
            </Link>
          ) : (
            <span className="text-ink">{item.label}</span>
          )}
          {i < items.length - 1 && <span className="text-stone-2">/</span>}
        </span>
      ))}
    </nav>
  );
}

export function EmptyState({
  title,
  description,
  action,
  icon,
}: {
  title: string;
  description: string;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="rule flex flex-col items-center justify-center gap-4 py-20 text-center">
      {icon && <div className="text-stone-2">{icon}</div>}
      <h3 className="display text-2xl">{title}</h3>
      <p className="max-w-md text-stone">{description}</p>
      {action}
    </div>
  );
}

export function Spinner({ label = "Loading" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-16">
      <span className="spin inline-block h-4 w-4 border-2 border-ink/25 border-t-ink" />
      <span className="meta text-stone">{label}</span>
    </div>
  );
}

export function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="label">{label}</span>
      {children}
    </label>
  );
}

export function Alert({ tone = "error", children }: { tone?: "error" | "success" | "info"; children: ReactNode }) {
  const styles =
    tone === "error"
      ? "border-verm/40 bg-verm/8 text-verm-dark"
      : tone === "success"
        ? "border-ink/20 bg-ink/5 text-ink"
        : "border-ink/15 bg-paper-2 text-stone";
  return (
    <div className={`flex items-start gap-2.5 border px-4 py-3 text-sm leading-relaxed ${styles}`} role="alert">
      {children}
    </div>
  );
}
