export function IndexRail() {
  return (
    <aside className="index-rail flex flex-col items-center justify-between py-6" aria-hidden="true">
      <div className="flex flex-col items-center gap-3">
        <span className="block h-8 w-px bg-ink/25" />
        <span className="meta-sm rail-vertical text-stone">Premium Streetwear</span>
      </div>

      <div className="flex flex-col items-center gap-4">
        {["01", "02", "03", "04", "05", "06"].map((n) => (
          <span key={n} className="meta-sm tnum text-stone/70">
            {n}
          </span>
        ))}
        <span className="block h-16 w-px bg-ink/25" />
      </div>

      <div className="flex flex-col items-center gap-3">
        <span className="display rail-vertical text-[0.95rem] tracking-[0.18em] text-ink">
          VELOURS · PAKISTAN
        </span>
        <span className="block h-8 w-px bg-verm" />
      </div>
    </aside>
  );
}
