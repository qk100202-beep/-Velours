"use client";

import { useState } from "react";
import { Loader2, Check } from "lucide-react";
import { useToast } from "@/components/toast";

export type InventoryRow = {
  variantId: number;
  productId: number;
  productName: string;
  sku: string;
  category: string;
  size: string;
  color: string;
  colorHex: string | null;
  stock: number;
  image: string | null;
};

export function InventoryTable({ rows }: { rows: InventoryRow[] }) {
  const toast = useToast();
  const [state, setState] = useState(rows);
  const [dirty, setDirty] = useState<Record<number, number>>({});
  const [savingId, setSavingId] = useState<number | null>(null);
  const [filter, setFilter] = useState<"all" | "low" | "out">("all");

  const visible = state.filter((r) =>
    filter === "all" ? true : filter === "low" ? r.stock > 0 && r.stock <= 8 : r.stock === 0
  );

  async function save(row: InventoryRow) {
    const next = dirty[row.variantId];
    if (next === undefined) return;
    setSavingId(row.variantId);
    try {
      const res = await fetch("/api/admin/manage", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ variantId: row.variantId, stock: next }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Could not update stock.");
      setState((s) => s.map((r) => (r.variantId === row.variantId ? { ...r, stock: next } : r)));
      setDirty((d) => {
        const copy = { ...d };
        delete copy[row.variantId];
        return copy;
      });
      toast(`Stock updated — ${row.productName} ${row.size} / ${row.color}`, "success");
    } catch (err) {
      toast(err instanceof Error ? err.message : "Something went wrong.", "error");
    } finally {
      setSavingId(null);
    }
  }

  const lowCount = state.filter((r) => r.stock > 0 && r.stock <= 8).length;
  const outCount = state.filter((r) => r.stock === 0).length;

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap gap-2">
          {(
            [
              ["all", `All (${state.length})`],
              ["low", `Low stock (${lowCount})`],
              ["out", `Out of stock (${outCount})`],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              data-selected={filter === key}
              className="chip"
            >
              {label}
            </button>
          ))}
        </div>
        <p className="tnum meta-sm text-stone">
          {Object.keys(dirty).length} unsaved change{Object.keys(dirty).length === 1 ? "" : "s"}
        </p>
      </div>

      <div className="mt-6 overflow-x-auto border border-ink/15">
        <table className="dtable min-w-[54rem]">
          <thead>
            <tr>
              <th>Product</th>
              <th>SKU</th>
              <th>Category</th>
              <th>Size</th>
              <th>Colour</th>
              <th>Current stock</th>
              <th>Status</th>
              <th className="text-right">Update</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((row) => {
              const pending = dirty[row.variantId];
              const status =
                row.stock === 0 ? "Out of stock" : row.stock <= 8 ? "Low stock" : "In stock";
              return (
                <tr key={row.variantId}>
                  <td>
                    <div className="flex items-center gap-3">
                      {row.image && (
                        <img
                          src={row.image}
                          alt=""
                          className="h-11 w-9 shrink-0 object-cover"
                          loading="lazy"
                        />
                      )}
                      <span className="font-medium">{row.productName}</span>
                    </div>
                  </td>
                  <td className="tnum">{row.sku}</td>
                  <td className="capitalize">{row.category.replace("-", " ")}</td>
                  <td>{row.size}</td>
                  <td>
                    <span className="flex items-center gap-2">
                      <span
                        className="h-3 w-3 border border-ink/20"
                        style={{ background: row.colorHex ?? "#0B0B0B" }}
                      />
                      {row.color}
                    </span>
                  </td>
                  <td>
                    <input
                      type="number"
                      min={0}
                      value={pending ?? row.stock}
                      onChange={(e) =>
                        setDirty((d) => ({ ...d, [row.variantId]: Number(e.target.value) }))
                      }
                      className="field tnum w-24 py-1.5"
                    />
                  </td>
                  <td>
                    <span
                      className={`meta-sm ${
                        row.stock === 0 ? "text-verm" : row.stock <= 8 ? "text-verm" : "text-stone"
                      }`}
                    >
                      {status}
                    </span>
                  </td>
                  <td className="text-right">
                    <button
                      onClick={() => save(row)}
                      disabled={pending === undefined || savingId === row.variantId}
                      className="btn btn-ink px-3.5 py-2"
                    >
                      {savingId === row.variantId ? (
                        <Loader2 size={13} className="spin" />
                      ) : (
                        <>
                          <Check size={13} /> Save
                        </>
                      )}
                    </button>
                  </td>
                </tr>
              );
            })}
            {visible.length === 0 && (
              <tr>
                <td colSpan={8} className="py-12 text-center text-stone">
                  No inventory rows match this filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
