"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Save } from "lucide-react";
import { Field, Alert } from "@/components/ui";
import { useToast } from "@/components/toast";

export function SettingsForm({
  initial,
}: {
  initial: Record<string, string>;
}) {
  const router = useRouter();
  const toast = useToast();
  const [values, setValues] = useState({
    site_tagline: initial.site_tagline ?? "Wear your story.",
    support_email: initial.support_email ?? "care@velours.pk",
    support_phone: initial.support_phone ?? "+92 300 1234567",
    shipping_flat: initial.shipping_flat ?? "250",
    free_shipping_over: initial.free_shipping_over ?? "8000",
    announcement: initial.announcement ?? "FREE SHIPPING ALL OVER PAKISTAN",
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function update(key: keyof typeof values, value: string) {
    setValues((v) => ({ ...v, [key]: value }));
  }

  async function save() {
    setError(null);
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings: values }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Could not save settings.");
      toast("Settings saved", "success");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      {error && <Alert tone="error">{error}</Alert>}
      <div className="mt-6 grid gap-7 sm:grid-cols-2">
        <Field label="Brand tagline">
          <input className="field" value={values.site_tagline} onChange={(e) => update("site_tagline", e.target.value)} />
        </Field>
        <Field label="Announcement bar">
          <input className="field" value={values.announcement} onChange={(e) => update("announcement", e.target.value)} />
        </Field>
        <Field label="Support email">
          <input className="field" value={values.support_email} onChange={(e) => update("support_email", e.target.value)} />
        </Field>
        <Field label="Support phone">
          <input className="field tnum" value={values.support_phone} onChange={(e) => update("support_phone", e.target.value)} />
        </Field>
        <Field label="Flat shipping (PKR)">
          <input type="number" className="field tnum" value={values.shipping_flat} onChange={(e) => update("shipping_flat", e.target.value)} />
        </Field>
        <Field label="Free shipping above (PKR)">
          <input type="number" className="field tnum" value={values.free_shipping_over} onChange={(e) => update("free_shipping_over", e.target.value)} />
        </Field>
      </div>

      <button onClick={save} disabled={saving} className="btn btn-ink mt-8">
        {saving ? (
          <>
            <Loader2 size={16} className="spin" /> Saving…
          </>
        ) : (
          <>
            <Save size={15} /> Save settings
          </>
        )}
      </button>
    </div>
  );
}

export function CustomerStatusButton({
  customerId,
  status,
}: {
  customerId: number;
  status: string;
}) {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const next = status === "active" ? "suspended" : "active";

  async function toggle() {
    if (!confirm(`Change this account to “${next}”?`)) return;
    setBusy(true);
    try {
      const res = await fetch("/api/admin/manage", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: customerId, status: next }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Could not update the account.");
      toast(`Account marked as ${next}`, "success");
      router.refresh();
    } catch (err) {
      toast(err instanceof Error ? err.message : "Something went wrong.", "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <button onClick={toggle} disabled={busy} className="btn btn-outline px-4 py-2.5">
      {busy ? <Loader2 size={14} className="spin" /> : status === "active" ? "Suspend account" : "Reactivate account"}
    </button>
  );
}
