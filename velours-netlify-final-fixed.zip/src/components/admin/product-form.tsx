"use client";

import { useCallback, useRef, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import {
  UploadCloud,
  X,
  Star,
  ArrowUp,
  ArrowDown,
  Loader2,
  Plus,
  Trash2,
  ImageIcon,
} from "lucide-react";
import { Alert, Field } from "@/components/ui";
import { useToast } from "@/components/toast";
import { COLORS, SIZES } from "@/lib/constants";

type ImageItem = { url: string; alt: string; isMain: boolean; uploading?: boolean; progress?: number };
type VariantItem = { size: string; color: string; colorHex: string; stock: number };

export type ProductFormValues = {
  id?: number;
  name: string;
  slug: string;
  category: string;
  description: string;
  fabric: string;
  price: number;
  salePrice: number | "";
  sku: string;
  featured: boolean;
  newArrival: boolean;
  published: boolean;
  images: ImageItem[];
  variants: VariantItem[];
};

const EMPTY: ProductFormValues = {
  name: "",
  slug: "",
  category: "t-shirts",
  description: "",
  fabric: "",
  price: 0,
  salePrice: "",
  sku: "",
  featured: false,
  newArrival: false,
  published: true,
  images: [],
  variants: [],
};

export function ProductForm({ initial }: { initial?: Partial<ProductFormValues> }) {
  const router = useRouter();
  const toast = useToast();
  const [values, setValues] = useState<ProductFormValues>({ ...EMPTY, ...initial });
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const xhrs = useRef<Map<string, XMLHttpRequest>>(new Map());

  const set = useCallback(<K extends keyof ProductFormValues>(key: K, value: ProductFormValues[K]) => {
    setValues((v) => ({ ...v, [key]: value }));
  }, []);

  /* ------------------------------ images ----------------------------- */

  const handleFiles = useCallback(
    async (files: FileList | File[]) => {
      const list = Array.from(files);
      if (!list.length) return;

      const pending = list.map((f) => ({
        url: URL.createObjectURL(f),
        alt: f.name,
        isMain: false,
        uploading: true,
        progress: 0,
      }));
      setValues((v) => ({ ...v, images: [...v.images, ...pending] }));

      for (let i = 0; i < list.length; i++) {
        const file = list[i];
        const tempUrl = pending[i].url;
        const form = new FormData();
        form.append("files", file);

        const xhr = new XMLHttpRequest();
        xhrs.current.set(tempUrl, xhr);

        const updater = (progress: number) =>
          setValues((v) => ({
            ...v,
            images: v.images.map((img) => (img.url === tempUrl ? { ...img, progress } : img)),
          }));

        await new Promise<void>((resolve) => {
          xhr.open("POST", "/api/upload");
          xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) updater(Math.round((e.loaded / e.total) * 100));
          };
          xhr.onerror = () => {
            setValues((v) => ({
              ...v,
              images: v.images.map((img) =>
                img.url === tempUrl ? { ...img, uploading: false, progress: 0 } : img
              ),
            }));
            toast(`${file.name} failed to upload. Check your connection and try again.`, "error");
            resolve();
          };
          xhr.onload = () => {
            try {
              const data = JSON.parse(xhr.responseText);
              if (xhr.status >= 200 && xhr.status < 300 && data.ok && data.files?.[0]) {
                setValues((v) => ({
                  ...v,
                  images: v.images.map((img) =>
                    img.url === tempUrl
                      ? {
                          url: data.files[0].url,
                          alt: file.name,
                          isMain: false,
                          uploading: false,
                          progress: 100,
                        }
                      : img
                  ),
                }));
              } else {
                throw new Error(data?.error || "Upload failed");
              }
            } catch (err) {
              setValues((v) => ({
                ...v,
                images: v.images.map((img) =>
                  img.url === tempUrl ? { ...img, uploading: false, progress: 0 } : img
                ),
              }));
              toast(
                err instanceof Error ? err.message : `${file.name} could not be uploaded.`,
                "error"
              );
            }
            resolve();
          };
          xhr.send(form);
        });
        xhrs.current.delete(tempUrl);
      }

      setValues((v) => ({
        ...v,
        images: v.images.map((img, idx) => ({ ...img, isMain: idx === 0 ? true : img.isMain })),
      }));
      toast(`${list.length} image${list.length > 1 ? "s" : ""} uploaded`, "success");
    },
    [toast]
  );

  function removeImage(url: string) {
    const target = values.images.find((i) => i.url === url);
    const xhr = xhrs.current.get(url);
    if (xhr) {
      xhr.abort();
      xhrs.current.delete(url);
      toast("Upload cancelled", "info");
    } else if (target && target.url.startsWith("/api/files/")) {
      fetch("/api/upload", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: target.url }),
      }).catch(() => {});
    }
    setValues((v) => {
      const images = v.images.filter((i) => i.url !== url);
      if (images.length && !images.some((i) => i.isMain)) images[0].isMain = true;
      return { ...v, images };
    });
  }

  function moveImage(index: number, dir: number) {
    setValues((v) => {
      const images = [...v.images];
      const target = index + dir;
      if (target < 0 || target >= images.length) return v;
      [images[index], images[target]] = [images[target], images[index]];
      return { ...v, images };
    });
  }

  function makeMain(url: string) {
    setValues((v) => ({
      ...v,
      images: v.images.map((img) => ({ ...img, isMain: img.url === url })),
    }));
  }

  /* ----------------------------- variants ---------------------------- */

  function addVariantRow() {
    setValues((v) => ({
      ...v,
      variants: [...v.variants, { size: "M", color: "Jet Black", colorHex: "#0B0B0B", stock: 10 }],
    }));
  }

  function generateSizeRun() {
    const color = values.variants[0]?.color ?? "Jet Black";
    const hex = values.variants[0]?.colorHex ?? "#0B0B0B";
    const existing = new Set(values.variants.map((v) => `${v.size}|${v.color}`));
    const rows = SIZES.filter((s) => !existing.has(`${s}|${color}`)).map((size) => ({
      size,
      color,
      colorHex: hex,
      stock: 10,
    }));
    setValues((v) => ({ ...v, variants: [...v.variants, ...rows] }));
  }

  /* ------------------------------ submit ----------------------------- */

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (values.images.some((i) => i.uploading)) {
      setError("Wait for all image uploads to finish before saving.");
      return;
    }
    if (values.images.length === 0) {
      setError("Add at least one product image.");
      return;
    }
    if (values.variants.length === 0) {
      setError("Add at least one size & colour combination.");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: values.name,
        slug: values.slug,
        category: values.category,
        description: values.description,
        fabric: values.fabric,
        price: Number(values.price),
        salePrice: values.salePrice === "" ? null : Number(values.salePrice),
        sku: values.sku,
        featured: values.featured,
        newArrival: values.newArrival,
        published: values.published,
        images: values.images.map((img) => ({ url: img.url, alt: img.alt, isMain: img.isMain })),
        variants: values.variants.map((v) => ({
          size: v.size,
          color: v.color,
          colorHex: v.colorHex,
          stock: Number(v.stock),
        })),
      };

      const res = await fetch(
        values.id ? `/api/admin/products/${values.id}` : "/api/admin/products",
        {
          method: values.id ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Could not save the product.");

      toast(values.id ? "Product updated" : "Product created", "success");
      router.push("/admin/products");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setSaving(false);
    }
  }

  const totalStock = values.variants.reduce((s, v) => s + (Number(v.stock) || 0), 0);

  return (
    <form onSubmit={submit} className="grid gap-10 lg:grid-cols-[1.5fr_1fr]">
      <div className="space-y-10">
        {error && <Alert tone="error">{error}</Alert>}

        {/* basics */}
        <section>
          <h2 className="display border-b border-ink/12 pb-3 text-[1.55rem]">
            <span className="meta mr-3 align-middle text-stone">01</span> Product Details
          </h2>
          <div className="mt-7 grid gap-7 sm:grid-cols-2">
            <Field label="Product name" className="sm:col-span-2">
              <input
                required
                className="field"
                value={values.name}
                onChange={(e) => {
                  const name = e.target.value;
                  setValues((v) => ({
                    ...v,
                    name,
                    slug:
                      v.slug ||
                      name
                        .toLowerCase()
                        .replace(/[^a-z0-9]+/g, "-")
                        .replace(/^-+|-+$/g, ""),
                  }));
                }}
                placeholder="Void Oversized Tee"
              />
            </Field>
            <Field label="URL slug">
              <input
                required
                className="field"
                value={values.slug}
                onChange={(e) => set("slug", e.target.value)}
                placeholder="void-oversized-tee"
              />
            </Field>
            <Field label="SKU">
              <input
                required
                className="field tnum"
                value={values.sku}
                onChange={(e) => set("sku", e.target.value.toUpperCase())}
                placeholder="VL-TEE-001"
              />
            </Field>
            <Field label="Category">
              <select
                className="field"
                value={values.category}
                onChange={(e) => set("category", e.target.value)}
              >
                <option value="t-shirts">T-Shirts</option>
                <option value="hoodies">Hoodies</option>
              </select>
            </Field>
            <Field label="Fabric & construction">
              <input
                className="field"
                value={values.fabric}
                onChange={(e) => set("fabric", e.target.value)}
                placeholder="240 GSM combed cotton, garment washed"
              />
            </Field>
            <Field label="Price (PKR)">
              <input
                required
                type="number"
                min={1}
                className="field tnum"
                value={values.price || ""}
                onChange={(e) => set("price", Number(e.target.value))}
                placeholder="3490"
              />
            </Field>
            <Field label="Sale price (PKR, optional)">
              <input
                type="number"
                min={0}
                className="field tnum"
                value={values.salePrice}
                onChange={(e) =>
                  set("salePrice", e.target.value === "" ? "" : Number(e.target.value))
                }
                placeholder="2990"
              />
            </Field>
            <Field label="Description" className="sm:col-span-2">
              <textarea
                required
                rows={5}
                className="field resize-none"
                value={values.description}
                onChange={(e) => set("description", e.target.value)}
                placeholder="Describe the fit, the fabric and what makes this piece worth owning…"
              />
            </Field>
          </div>

          <div className="mt-7 flex flex-wrap gap-2.5">
            {[
              ["featured", "Mark as featured"],
              ["newArrival", "Mark as new arrival"],
              ["published", "Published (visible in store)"],
            ].map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => set(key as keyof ProductFormValues, !values[key as keyof ProductFormValues] as never)}
                data-selected={Boolean(values[key as keyof ProductFormValues])}
                className="chip"
              >
                {label}
              </button>
            ))}
          </div>
        </section>

        {/* images */}
        <section>
          <h2 className="display border-b border-ink/12 pb-3 text-[1.55rem]">
            <span className="meta mr-3 align-middle text-stone">02</span> Images
            <span className="meta-sm tnum ml-3 align-middle text-stone">
              {values.images.length} uploaded
            </span>
          </h2>

          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              handleFiles(e.dataTransfer.files);
            }}
            className={`mt-6 flex flex-col items-center justify-center gap-3 border-2 border-dashed px-6 py-12 text-center transition-colors ${
              dragOver ? "border-verm bg-verm/6" : "border-ink/20 bg-paper-2"
            }`}
          >
            <UploadCloud size={30} className="text-stone" />
            <p className="text-sm text-stone">
              Drag &amp; drop images here, or{" "}
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="link-underline font-medium text-verm"
              >
                browse your files
              </button>
            </p>
            <p className="meta-sm text-stone-2">JPG, PNG, WebP or AVIF · up to 8 MB each · max 12 at once</p>
            <input
              ref={fileRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,image/avif"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files) handleFiles(e.target.files);
                e.target.value = "";
              }}
            />
          </div>

          {values.images.length > 0 && (
            <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
              {values.images.map((img, i) => (
                <div key={img.url} className="group relative border border-ink/12 bg-paper-2">
                  <div className="relative aspect-[4/5] overflow-hidden">
                    {img.url.startsWith("blob:") ? (
                      <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-ink/5">
                        <ImageIcon size={22} className="text-stone" />
                        <span className="meta-sm tnum text-stone">{img.progress ?? 0}%</span>
                      </div>
                    ) : (
                      <img src={img.url} alt={img.alt} className="h-full w-full object-cover" />
                    )}

                    {img.uploading && (
                      <div className="absolute inset-x-0 bottom-0 h-1 bg-ink/15">
                        <div
                          className="h-full bg-verm transition-all duration-300"
                          style={{ width: `${img.progress ?? 0}%` }}
                        />
                      </div>
                    )}

                    {img.isMain && !img.uploading && (
                      <span className="badge badge-new absolute left-2 top-2">Main</span>
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-1 px-2 py-2">
                    <button
                      type="button"
                      onClick={() => makeMain(img.url)}
                      className="grid h-7 w-7 place-items-center text-stone transition hover:text-verm"
                      title="Set as main image"
                    >
                      <Star size={14} fill={img.isMain ? "currentColor" : "none"} />
                    </button>
                    <button
                      type="button"
                      onClick={() => moveImage(i, -1)}
                      className="grid h-7 w-7 place-items-center text-stone transition hover:text-ink"
                      title="Move earlier"
                    >
                      <ArrowUp size={14} />
                    </button>
                    <button
                      type="button"
                      onClick={() => moveImage(i, 1)}
                      className="grid h-7 w-7 place-items-center text-stone transition hover:text-ink"
                      title="Move later"
                    >
                      <ArrowDown size={14} />
                    </button>
                    <button
                      type="button"
                      onClick={() => removeImage(img.url)}
                      className="grid h-7 w-7 place-items-center text-stone transition hover:text-verm"
                      title={img.uploading ? "Cancel upload" : "Remove image"}
                    >
                      <X size={14} />
                    </button>
                  </div>
                  <p className="tnum truncate border-t border-ink/10 px-2 py-1.5 text-[0.625rem] text-stone">
                    {i + 1}. {img.alt || "Untitled"}
                  </p>
                </div>
              ))}
            </div>
          )}

          <p className="mt-4 text-xs leading-relaxed text-stone">
            The first image (marked <strong className="text-ink">Main</strong>) is used on product
            cards and in the bag. Every uploaded image automatically joins the customer gallery in
            the order shown here.
          </p>
        </section>

        {/* variants */}
        <section>
          <div className="flex flex-wrap items-end justify-between gap-4 border-b border-ink/12 pb-3">
            <h2 className="display text-[1.55rem]">
              <span className="meta mr-3 align-middle text-stone">03</span> Sizes, Colours &amp; Stock
            </h2>
            <div className="flex gap-2">
              <button type="button" onClick={generateSizeRun} className="btn btn-outline px-4 py-2.5">
                Generate size run
              </button>
              <button type="button" onClick={addVariantRow} className="btn btn-ink px-4 py-2.5">
                <Plus size={14} /> Add row
              </button>
            </div>
          </div>

          {values.variants.length === 0 ? (
            <p className="mt-6 border border-dashed border-ink/20 px-6 py-10 text-center text-sm text-stone">
              No size &amp; colour combinations yet. Generate a size run or add rows manually.
            </p>
          ) : (
            <div className="mt-6 overflow-x-auto">
              <table className="dtable min-w-[38rem]">
                <thead>
                  <tr>
                    <th>Size</th>
                    <th>Colour</th>
                    <th>Swatch</th>
                    <th>Stock</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {values.variants.map((v, i) => (
                    <tr key={i}>
                      <td>
                        <select
                          value={v.size}
                          onChange={(e) =>
                            setValues((val) => ({
                              ...val,
                              variants: val.variants.map((row, idx) =>
                                idx === i ? { ...row, size: e.target.value } : row
                              ),
                            }))
                          }
                          className="field w-24 py-1.5"
                        >
                          {SIZES.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td>
                        <select
                          value={v.color}
                          onChange={(e) => {
                            const found = COLORS.find((c) => c.name === e.target.value);
                            setValues((val) => ({
                              ...val,
                              variants: val.variants.map((row, idx) =>
                                idx === i
                                  ? { ...row, color: e.target.value, colorHex: found?.hex ?? row.colorHex }
                                  : row
                              ),
                            }));
                          }}
                          className="field w-40 py-1.5"
                        >
                          {COLORS.map((c) => (
                            <option key={c.name} value={c.name}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td>
                        <span
                          className="inline-block h-6 w-6 border border-ink/20"
                          style={{ background: v.colorHex }}
                        />
                      </td>
                      <td>
                        <input
                          type="number"
                          min={0}
                          value={v.stock}
                          onChange={(e) =>
                            setValues((val) => ({
                              ...val,
                              variants: val.variants.map((row, idx) =>
                                idx === i ? { ...row, stock: Number(e.target.value) } : row
                              ),
                            }))
                          }
                          className="field tnum w-24 py-1.5"
                        />
                      </td>
                      <td>
                        <button
                          type="button"
                          onClick={() =>
                            setValues((val) => ({
                              ...val,
                              variants: val.variants.filter((_, idx) => idx !== i),
                            }))
                          }
                          className="grid h-8 w-8 place-items-center text-stone transition hover:text-verm"
                          aria-label="Remove row"
                        >
                          <Trash2 size={15} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <p className="tnum meta-sm mt-4 text-stone">
            {values.variants.length} combinations · {totalStock} units in total
          </p>
        </section>
      </div>

      {/* sidebar */}
      <aside className="lg:sticky lg:top-8 lg:self-start">
        <div className="border border-ink/15 bg-paper-2 p-6">
          <h3 className="display text-[1.35rem]">Publish</h3>
          <div className="mt-5 space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-stone">Status</span>
              <span className="font-medium">{values.published ? "Published" : "Draft"}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone">Images</span>
              <span className="tnum font-medium">{values.images.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone">Variants</span>
              <span className="tnum font-medium">{values.variants.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone">Total stock</span>
              <span className="tnum font-medium">{totalStock}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone">Price</span>
              <span className="tnum font-medium">
                {values.salePrice !== "" && Number(values.salePrice) > 0
                  ? `Rs. ${Number(values.salePrice).toLocaleString("en-PK")} (sale)`
                  : `Rs. ${(Number(values.price) || 0).toLocaleString("en-PK")}`}
              </span>
            </div>
          </div>

          <button type="submit" disabled={saving} className="btn btn-ink mt-7 w-full">
            {saving ? (
              <>
                <Loader2 size={16} className="spin" /> Saving…
              </>
            ) : values.id ? (
              "Save changes"
            ) : (
              "Create product"
            )}
          </button>

          {values.id && (
            <button
              type="button"
              onClick={async () => {
                if (!confirm("Delete this product permanently? This cannot be undone.")) return;
                const res = await fetch(`/api/admin/products/${values.id}`, { method: "DELETE" });
                const data = await res.json();
                if (data.ok) {
                  toast("Product deleted", "success");
                  router.push("/admin/products");
                  router.refresh();
                } else {
                  toast(data?.error || "Could not delete the product.", "error");
                }
              }}
              className="btn btn-outline mt-2 w-full text-verm-dark"
            >
              <Trash2 size={15} /> Delete product
            </button>
          )}

          <p className="mt-6 text-xs leading-relaxed text-stone">
            Changes are saved to the database immediately and become visible in the store as soon as
            the product is published.
          </p>
        </div>
      </aside>
    </form>
  );
}
