"use client";

import { motion } from "framer-motion";

export function RevenueBars({
  data,
}: {
  data: { month: string; revenue: number; orders: number }[];
}) {
  const max = Math.max(1, ...data.map((d) => d.revenue));

  return (
    <div>
      {data.length === 0 ? (
        <p className="py-10 text-center text-sm text-stone">
          No revenue recorded yet. Charts appear once orders start coming in.
        </p>
      ) : (
        <>
          <div className="flex h-52 items-end gap-3">
            {data.map((d, i) => (
              <div key={d.month + i} className="flex flex-1 flex-col items-center gap-2">
                <span className="tnum text-[0.6875rem] text-stone">
                  {d.revenue >= 1000 ? `${Math.round(d.revenue / 1000)}k` : d.revenue}
                </span>
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: `${Math.max(4, (d.revenue / max) * 100)}%` }}
                  transition={{ duration: 0.75, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] }}
                  className="w-full bg-ink transition-colors hover:bg-verm"
                  title={`${d.month}: Rs. ${d.revenue.toLocaleString("en-PK")} from ${d.orders} orders`}
                />
              </div>
            ))}
          </div>
          <div className="mt-3 flex gap-3 border-t border-ink/12 pt-3">
            {data.map((d, i) => (
              <span key={d.month + i} className="meta-sm flex-1 text-center text-stone">
                {d.month}
              </span>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export function TopProductsBars({
  data,
}: {
  data: { name: string; units: number; revenue: number }[];
}) {
  const max = Math.max(1, ...data.map((d) => d.units));
  return (
    <div className="space-y-4">
      {data.length === 0 ? (
        <p className="py-8 text-center text-sm text-stone">No sales recorded yet.</p>
      ) : (
        data.map((d, i) => (
          <div key={d.name}>
            <div className="flex items-baseline justify-between gap-4">
              <p className="truncate text-sm">{d.name}</p>
              <p className="tnum text-xs text-stone">
                {d.units} units · Rs. {d.revenue.toLocaleString("en-PK")}
              </p>
            </div>
            <div className="mt-2 h-1.5 w-full bg-ink/10">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(d.units / max) * 100}%` }}
                transition={{ duration: 0.7, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                className="h-full bg-verm"
              />
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export function Donut({ parts }: { parts: { label: string; value: number; color: string }[] }) {
  const total = parts.reduce((s, p) => s + p.value, 0) || 1;
  let offset = 0;
  return (
    <div className="flex items-center gap-7">
      <svg viewBox="0 0 42 42" className="h-32 w-32 shrink-0 -rotate-90">
        {parts.map((p) => {
          const pct = (p.value / total) * 100;
          const el = (
            <circle
              key={p.label}
              cx="21"
              cy="21"
              r="15.9155"
              fill="none"
              stroke={p.color}
              strokeWidth="6"
              strokeDasharray={`${pct} ${100 - pct}`}
              strokeDashoffset={String(offset)}
            />
          );
          offset += pct;
          return el;
        })}
      </svg>
      <div className="space-y-2.5">
        {parts.map((p) => (
          <div key={p.label} className="flex items-center gap-2.5">
            <span className="h-2.5 w-2.5" style={{ background: p.color }} />
            <span className="text-sm text-stone">{p.label}</span>
            <span className="tnum text-sm font-medium">{p.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
