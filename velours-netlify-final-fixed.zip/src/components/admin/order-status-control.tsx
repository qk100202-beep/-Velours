"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, Ban, Truck, PackageCheck, StickyNote } from "lucide-react";
import { ORDER_STATUSES, STATUS_META, type OrderStatus } from "@/lib/constants";
import { useToast } from "@/components/toast";

export function OrderStatusControl({
  orderId,
  current,
  cancelled,
}: {
  orderId: number;
  current: string;
  cancelled: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [status, setStatus] = useState(current);
  const [saving, setSaving] = useState(false);
  const [note, setNote] = useState("");

  async function update(next: string) {
    if (next === current) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/orders/${orderId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: next, note: note.trim() || undefined }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Could not update the order.");
      setStatus(next);
      setNote("");
      toast(`Order marked as ${STATUS_META[next as OrderStatus]?.label ?? next}`, "success");
      router.refresh();
    } catch (err) {
      toast(err instanceof Error ? err.message : "Something went wrong.", "error");
      setStatus(current);
    } finally {
      setSaving(false);
    }
  }

  async function addNote() {
    if (!note.trim()) return;
    setSaving(true);
    try {
      const res = await fetch("/api/admin/manage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId, note: note.trim() }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Could not add the note.");
      setNote("");
      toast("Note added to the order", "success");
      router.refresh();
    } catch (err) {
      toast(err instanceof Error ? err.message : "Something went wrong.", "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="flex flex-wrap items-end gap-5">
        <label className="min-w-[16rem] flex-1">
          <span className="label">Order status</span>
          <select
            className="field"
            value={status}
            disabled={saving}
            onChange={(e) => update(e.target.value)}
          >
            {ORDER_STATUSES.map((s) => (
              <option key={s} value={s}>
                {STATUS_META[s].label}
              </option>
            ))}
          </select>
        </label>

        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => update("shipped")}
            disabled={saving || status === "shipped"}
            className="btn btn-outline px-4 py-2.5"
          >
            <Truck size={14} /> Mark shipped
          </button>
          <button
            onClick={() => update("delivered")}
            disabled={saving || status === "delivered"}
            className="btn btn-ink px-4 py-2.5"
          >
            <PackageCheck size={14} /> Mark delivered
          </button>
          <button
            onClick={() => {
              if (confirm("Cancel this order? Reserved stock will be returned to inventory.")) {
                update("cancelled");
              }
            }}
            disabled={saving || cancelled}
            className="btn btn-outline px-4 py-2.5 text-verm-dark"
          >
            <Ban size={14} /> Cancel order
          </button>
        </div>
      </div>

      <div className="mt-6">
        <label className="block">
          <span className="label">Add a note to this order</span>
          <textarea
            rows={2}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="e.g. Customer asked to deliver after 6 PM."
            className="field resize-none"
          />
        </label>
        <button
          onClick={addNote}
          disabled={saving || !note.trim()}
          className="btn btn-outline mt-3 px-4 py-2.5"
        >
          <StickyNote size={14} /> Save note
        </button>
      </div>

      {saving && (
        <p className="mt-4 flex items-center gap-2 text-sm text-stone">
          <Loader2 size={15} className="spin" /> Saving changes…
        </p>
      )}
    </div>
  );
}
