"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import {
  LayoutDashboard,
  Package,
  Boxes,
  ClipboardList,
  Users,
  Settings,
  LogOut,
  Plus,
  Menu,
  X,
  Store,
} from "lucide-react";

const NAV = [
  ["/admin", "Dashboard", LayoutDashboard],
  ["/admin/products", "Products", Package],
  ["/admin/products/new", "Add Product", Plus],
  ["/admin/inventory", "Inventory", Boxes],
  ["/admin/orders", "Orders", ClipboardList],
  ["/admin/customers", "Customers", Users],
  ["/admin/settings", "Settings", Settings],
] as const;

export function AdminSidebar({ name, email }: { name: string; email: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  async function signOut() {
    await fetch("/api/admin/auth", { method: "DELETE" });
    router.push("/admin/login");
    router.refresh();
  }

  const links = (
    <nav className="flex flex-col gap-1">
      {NAV.map(([href, label, Icon]) => {
        const active =
          href === "/admin" ? pathname === "/admin" : pathname === href || pathname.startsWith(href + "/");
        return (
          <Link
            key={href}
            href={href}
            onClick={() => setOpen(false)}
            className={`flex items-center gap-3 border-l-2 px-4 py-3 text-sm transition-colors ${
              active
                ? "border-verm bg-paper text-ink"
                : "border-transparent text-paper/65 hover:border-paper/30 hover:text-paper"
            }`}
          >
            <Icon size={16} />
            <span className="tracking-[0.04em]">{label}</span>
          </Link>
        );
      })}
    </nav>
  );

  return (
    <>
      {/* mobile top bar */}
      <div className="fixed inset-x-0 top-0 z-50 flex items-center justify-between border-b border-paper/12 bg-ink px-5 py-3.5 lg:hidden">
        <span className="display text-paper">VELOURS Admin</span>
        <button onClick={() => setOpen(true)} aria-label="Open admin menu" className="text-paper">
          <Menu size={21} />
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div className="absolute inset-0 bg-ink/60" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-[16rem] bg-ink pt-5">
            <div className="flex items-center justify-between px-5 pb-5">
              <span className="display text-paper text-lg">VELOURS</span>
              <button onClick={() => setOpen(false)} aria-label="Close menu" className="text-paper">
                <X size={20} />
              </button>
            </div>
            {links}
          </div>
        </div>
      )}

      {/* desktop rail */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[15.5rem] flex-col bg-ink lg:flex">
        <div className="border-b border-paper/12 px-5 py-6">
          <Link href="/" className="display block text-[1.55rem] text-paper">
            VELOURS
          </Link>
          <p className="meta-sm mt-1.5 text-stone-2">Admin control room</p>
        </div>

        <div className="flex-1 overflow-y-auto py-5">{links}</div>

        <div className="border-t border-paper/12 px-5 py-5">
          <p className="truncate text-sm font-medium text-paper">{name}</p>
          <p className="mt-1 truncate text-xs text-stone-2">{email}</p>
          <div className="mt-4 flex flex-col gap-2">
            <Link
              href="/"
              className="flex items-center gap-2.5 text-xs uppercase tracking-[0.18em] text-paper/65 transition-colors hover:text-paper"
            >
              <Store size={14} /> View store
            </Link>
            <button
              onClick={signOut}
              className="flex items-center gap-2.5 text-xs uppercase tracking-[0.18em] text-paper/65 transition-colors hover:text-verm"
            >
              <LogOut size={14} /> Sign out
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
