"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Loader2, LogOut, KeyRound } from "lucide-react";
import { Alert, Field } from "@/components/ui";
import { useToast } from "@/components/toast";
import { PROVINCES } from "@/lib/constants";

type Profile = {
  id: number;
  name: string;
  email: string;
  phone: string | null;
  address: string | null;
  city: string | null;
  province: string | null;
  postalCode: string | null;
};

export function AccountProfile({ user }: { user: Profile }) {
  const router = useRouter();
  const toast = useToast();

  const [form, setForm] = useState({
    name: user.name,
    email: user.email,
    phone: user.phone ?? "",
    address: user.address ?? "",
    city: user.city ?? "",
    province: user.province ?? "",
    postalCode: user.postalCode ?? "",
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [pw, setPw] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [pwSaving, setPwSaving] = useState(false);
  const [pwError, setPwError] = useState<string | null>(null);

  function update(key: keyof typeof form, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function saveProfile(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      const res = await fetch("/api/auth/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Could not save your profile.");
      toast("Profile updated", "success");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setSaving(false);
    }
  }

  async function changePassword(e: FormEvent) {
    e.preventDefault();
    setPwError(null);
    if (pw.newPassword !== pw.confirm) {
      setPwError("New passwords do not match.");
      return;
    }
    setPwSaving(true);
    try {
      const res = await fetch("/api/auth/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: pw.currentPassword, newPassword: pw.newPassword }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) throw new Error(data?.error || "Could not change your password.");
      setPw({ currentPassword: "", newPassword: "", confirm: "" });
      toast("Password changed", "success");
    } catch (err) {
      setPwError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setPwSaving(false);
    }
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    toast("Signed out", "success");
    router.push("/");
    router.refresh();
  }

  return (
    <div className="grid gap-12 lg:grid-cols-[1.35fr_1fr]">
      {/* profile */}
      <section>
        <h2 className="display text-[1.85rem]">
          <span className="meta mr-3 align-middle text-stone">01</span> Profile
        </h2>
        <form onSubmit={saveProfile} className="mt-8 space-y-7">
          {error && <Alert tone="error">{error}</Alert>}
          <div className="grid gap-7 sm:grid-cols-2">
            <Field label="Full name">
              <input required className="field" value={form.name} onChange={(e) => update("name", e.target.value)} />
            </Field>
            <Field label="Email address">
              <input
                required
                type="email"
                className="field"
                value={form.email}
                onChange={(e) => update("email", e.target.value)}
              />
            </Field>
            <Field label="Phone number">
              <input className="field tnum" value={form.phone} onChange={(e) => update("phone", e.target.value)} />
            </Field>
            <Field label="City">
              <input className="field" value={form.city} onChange={(e) => update("city", e.target.value)} />
            </Field>
            <Field label="Address" className="sm:col-span-2">
              <input className="field" value={form.address} onChange={(e) => update("address", e.target.value)} />
            </Field>
            <Field label="Province">
              <select className="field" value={form.province} onChange={(e) => update("province", e.target.value)}>
                <option value="">Select province</option>
                {PROVINCES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Postal code">
              <input
                className="field tnum"
                value={form.postalCode}
                onChange={(e) => update("postalCode", e.target.value)}
              />
            </Field>
          </div>
          <button type="submit" disabled={saving} className="btn btn-ink">
            {saving ? (
              <>
                <Loader2 size={16} className="spin" /> Saving…
              </>
            ) : (
              "Save changes"
            )}
          </button>
        </form>
      </section>

      {/* security */}
      <section>
        <h2 className="display text-[1.85rem]">
          <span className="meta mr-3 align-middle text-stone">02</span> Security
        </h2>
        <form onSubmit={changePassword} className="mt-8 space-y-7 border border-ink/15 bg-paper-2 p-7">
          {pwError && <Alert tone="error">{pwError}</Alert>}
          <Field label="Current password">
            <input
              required
              type="password"
              className="field"
              value={pw.currentPassword}
              onChange={(e) => setPw((p) => ({ ...p, currentPassword: e.target.value }))}
              autoComplete="current-password"
            />
          </Field>
          <Field label="New password">
            <input
              required
              type="password"
              className="field"
              value={pw.newPassword}
              onChange={(e) => setPw((p) => ({ ...p, newPassword: e.target.value }))}
              autoComplete="new-password"
            />
          </Field>
          <Field label="Confirm new password">
            <input
              required
              type="password"
              className="field"
              value={pw.confirm}
              onChange={(e) => setPw((p) => ({ ...p, confirm: e.target.value }))}
              autoComplete="new-password"
            />
          </Field>
          <button type="submit" disabled={pwSaving} className="btn btn-outline w-full">
            <KeyRound size={15} />
            {pwSaving ? "Updating…" : "Change password"}
          </button>
        </form>

        <button onClick={logout} className="btn btn-outline mt-6 w-full">
          <LogOut size={15} /> Sign out
        </button>
      </section>
    </div>
  );
}
