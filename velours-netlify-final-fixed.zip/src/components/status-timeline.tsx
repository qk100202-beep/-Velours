import { STATUS_META, TRACKING_STEPS, type OrderStatus, formatDateTime } from "@/lib/constants";

export function StatusTimeline({
  status,
  events,
}: {
  status: string;
  events?: { id: number; status: string; note: string | null; createdAt: string }[];
}) {
  const current = STATUS_META[status as OrderStatus];
  const cancelled = status === "cancelled";
  const currentStep = cancelled ? -1 : (current?.step ?? -1);
  const stepEvents = new Map<string, string>();
  for (const e of events ?? []) {
    if (!stepEvents.has(e.status)) stepEvents.set(e.status, e.createdAt);
  }

  return (
    <div>
      <div className="flex items-start gap-0">
        {TRACKING_STEPS.map((step, i) => {
          const meta = STATUS_META[step];
          const done = i <= currentStep;
          const isCurrent = i === currentStep;
          return (
            <div key={step} className="flex flex-1 flex-col items-center">
              <div className="flex w-full items-center">
                <span
                  className={`h-px flex-1 ${i === 0 ? "opacity-0" : done ? "bg-verm" : "bg-ink/15"}`}
                />
                <span
                  className={`grid h-8 w-8 shrink-0 place-items-center rounded-full border text-[0.625rem] font-semibold transition-colors ${
                    done
                      ? "border-verm bg-verm text-paper"
                      : "border-ink/20 bg-paper text-stone"
                  } ${isCurrent ? "ring-4 ring-verm/18" : ""}`}
                >
                  {done ? "✓" : String(i + 1).padStart(2, "0")}
                </span>
                <span
                  className={`h-px flex-1 ${
                    i === TRACKING_STEPS.length - 1 ? "opacity-0" : done && i < currentStep ? "bg-verm" : "bg-ink/15"
                  }`}
                />
              </div>
              <p
                className={`meta-sm mt-3 text-center ${
                  done ? "text-ink" : "text-stone"
                }`}
              >
                {meta.short}
              </p>
              {stepEvents.has(step) && (
                <p className="tnum mt-1 text-[0.625rem] text-stone">
                  {formatDateTime(stepEvents.get(step)!).split(",")[0]}
                </p>
              )}
            </div>
          );
        })}
      </div>

      {cancelled && (
        <div className="mt-8 border border-verm/35 bg-verm/8 px-5 py-4">
          <p className="meta text-verm-dark">Order cancelled</p>
          <p className="mt-2 text-sm leading-relaxed text-ink/80">
            This order was cancelled and any reserved stock has been returned to inventory.
          </p>
        </div>
      )}
    </div>
  );
}
