# VELOURS — Premium Pakistani Streetwear

A complete, production-ready e-commerce platform for **VELOURS**, a premium Gen-Z streetwear label
building heavyweight T-shirts and hoodies in Karachi. Built with **Next.js (App Router)**,
**PostgreSQL** and **Drizzle ORM**.

> Wear your story.

---

## What is included

### Customer storefront

| Area | Details |
| --- | --- |
| Home | Full-bleed hero, collections, featured products, new drops, best sellers, limited collection |
| Shop | `/shop`, `/t-shirts`, `/hoodies`, `/new-arrivals` with search, category, price, size, colour, new/featured filters and 5 sort modes |
| Product | Multi-image gallery (thumbnail strip, prev/next, hover zoom, fullscreen viewer, mobile swipe), size & colour selectors, live stock, quantity, add to bag, buy now, wishlist, size guide, shipping & returns info |
| Bag | Persistent cart (localStorage + server-validated at checkout), quantity steppers, free-shipping threshold |
| Checkout | Customer, shipping, province, delivery instructions, COD payment, live order summary, stock verification |
| Order confirmation | Real order number, items, sizes, colours, totals, delivery window, address, payment method |
| Tracking | `/track` — lookup by order number + email/phone, visual progress timeline built from the real order status history |
| Account | Profile editing, change password, order history, order detail, sign out |
| Auth | Real signup / login / logout / forgot-password / reset-password with salted **scrypt** hashes |

### Admin control room (`/admin`)

| Page | Details |
| --- | --- |
| Dashboard | Total sales, orders, pending, delivered, customers, products, low/out-of-stock, revenue chart, top products, fulfilment donut, recent orders |
| Products | Full catalogue table with search + filters |
| Add / Edit Product | Name, slug, SKU, category, fabric, price, sale price, description, featured, new-arrival, published flags |
| Images | Multi-file upload with progress bars, cancel, preview, remove, reorder, set main image |
| Inventory | Every size × colour line with inline stock editing, low-stock and out-of-stock filters |
| Orders | Search, filter by status, sort, open order, update status, cancel (restocks inventory), mark shipped/delivered, add notes |
| Customers | Search, lifetime spend, order history, profile, account status |
| Settings | Store settings + live environment status |

---

## Getting started

### 1. Install dependencies

```bash
npm install
```

### 2. Configure the environment

```bash
cp .env.example .env
```

Fill in at minimum:

```env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
ADMIN_EMAIL=QATA@gmail.com
ADMIN_SEED_PASSWORD=<your-private-admin-password>
```

### 3. Create the database schema

```bash
npx drizzle-kit push
```

### 4. Run

```bash
npm run dev
```

The database is seeded automatically on first request with 12 real products, full size/colour
inventory, and the administrator account.

---

## Admin initial setup & security

The administrator signs in at **`/admin/login`** using `ADMIN_EMAIL` and `ADMIN_SEED_PASSWORD`.

Security guarantees implemented in this codebase:

* **The admin password is never present in source code.** It is read from `ADMIN_SEED_PASSWORD`
  at runtime and stored only as a **salted scrypt hash**.
* It is never rendered into HTML, never shipped in the client bundle, and never returned by any API.
* The admin session is a **server-side session row** referenced by an `httpOnly`, `SameSite=Lax`
  cookie holding only a random token (stored hashed).
* **Every** admin route handler calls `requireAdmin()`, which verifies the session *and* the
  `role = 'admin'` / `status = 'active'` columns in the database.
* The admin layout is a **server component** that redirects non-admins, so a customer cannot reach
  admin pages by typing the URL.
* Failed admin sign-in returns a generic *"Incorrect admin credentials."* whether or not the
  account exists, so the admin email is not leaked.
* Customer passwords use the same scrypt hashing. Passwords are never exposed on any customer or
  admin page.
* Order, inventory and product writes are all role-checked server-side.

To rotate the admin password after setup: sign in and change it, or update `ADMIN_SEED_PASSWORD`
and clear the `users` row so it re-seeds — better still, create the account once and then unset the
variable.

---

## Local product images

All built-in storefront images are kept in one place: `public/images/`. The product seed uses the
central map in `src/lib/image-assets.ts`, so replacing the files there updates the storefront without
searching through multiple components. The ZIP includes working local image assets so the Netlify
site does not show broken `/images/*.jpg` links.

## Cloud image storage

Uploaded images are **never written into `src/`**.

* `IMAGE_STORAGE=local` (default) writes to `storage/uploads/` at the project root — git-ignored —
  and serves them through `/api/files/[name]` with long-lived cache headers.
* `IMAGE_STORAGE=cloudinary` uploads to your Cloudinary account instead and stores the returned
  CDN URL against the product. This is the recommended production setup (~15 GB plan).

```env
IMAGE_STORAGE=cloudinary
CLOUDINARY_CLOUD_NAME=...
CLOUDINARY_API_KEY=...
CLOUDINARY_API_SECRET=...
```

The admin UI is identical either way.

---

## Email

Set `RESEND_API_KEY`, `EMAIL_FROM` and `CONTACT_INBOX` to enable:

* Order confirmation emails
* Password reset links
* Contact-form delivery
* Newsletter signups

Without them the same flows still work — messages are written to the server log — so the app is
fully testable in a sandbox.

---

## Deploying to Netlify

1. Push this repository to GitHub.
2. In Netlify: **Add new site → Import an existing project**.
3. Netlify reads `netlify.toml`:
   * Build command: `npm run build`
   * Publish directory: `.next`
   * SPA/SSR redirect rules for direct navigation on any route
   * Security headers and immutable caching for uploaded files
4. Add the variables from `.env.example` under **Site settings → Environment variables**.
   Make sure `ADMIN_SEED_PASSWORD` is set there and **not** in the repository.
5. Deploy. On first request the database is created/migrated and seeded.

---

## Database schema

| Table | Purpose |
| --- | --- |
| `users` | id, name, email, password hash, phone, address, city, province, postal code, role, status, timestamps |
| `sessions` | hashed session token → user, role, expiry |
| `products` | name, slug, category, description, fabric, price, sale price, SKU, featured, new arrival, published, timestamps |
| `product_images` | url, alt, position, is-main — full customer gallery |
| `product_variants` | size × colour with its own stock level (the real stock unit) |
| `orders` | order number, customer snapshot, address, subtotal, shipping, total, payment method, status, timestamps |
| `order_items` | product snapshot, SKU, size, colour, quantity, unit price, image |
| `order_events` | status history — drives the tracking timeline |
| `cart_items`, `wishlist_items` | per-user persistence |
| `password_resets` | hashed reset tokens with expiry |
| `settings` | editable store settings |

---

## Scripts

```bash
npm run dev        # development server
npm run build      # production build
npm run start      # start the production server
npm run typecheck  # TypeScript, no emit
npm run lint       # ESLint
npx drizzle-kit push   # apply schema to the database
```

---

## Notes on scope

* **Cash on delivery** is live. The payment layer is structured so JazzCash / Easypaisa / card
  providers can be added as new `paymentMethod` values in `src/app/api/orders/route.ts` without
  touching the checkout UI.
* Order statuses are the real database values: `pending → confirmed → processing → packed →
  shipped → out_for_delivery → delivered`, plus `cancelled` (which restocks inventory).
